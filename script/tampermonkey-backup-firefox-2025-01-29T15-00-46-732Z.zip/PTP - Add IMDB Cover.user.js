// ==UserScript==
// @name         PTP - Add IMDB Cover
// @namespace    http://tampermonkey.net/
// @version      0.3
// @author       passthepopcorn_cc
// @match        https://passthepopcorn.me/upload.php?*
// @match        https://passthepopcorn.me/upload.php
// @match        https://passthepopcorn.me/requests.php*
// @icon         https://www.google.com/s2/favicons?domain=passthepopcorn.me
// @grant        GM_xmlhttpRequest
// ==/UserScript==


(function() {
    'use strict';

    // Your code here...

    const addListener = () => {


        if (window.location.href.includes("requests.php")) {

            document.querySelectorAll("#request_form > div").forEach((d) => {

                if (d.querySelector("label") != undefined && d.querySelector("label").textContent.includes("Image:")) {

                    d.querySelector("label").style.cursor = "pointer"

                    d.querySelector("label").addEventListener("click", () => {
                        window.open( document.querySelector("#image").value, '_blank').focus();
                    })


                }

            })

        }

        else {

            document.querySelectorAll("#upload_table > div").forEach((d) => {

                if (d.querySelector("label") != undefined && d.querySelector("label").textContent.includes("Cover art")) {
                    d.querySelector("label").style.cursor = "pointer"

                    d.querySelector("label").addEventListener("click", () => {
                       window.open( document.querySelector("#image").value, '_blank').focus();
                    })


                }

            })

        }

    }

    const scrapeAndSetCover = (cover_page, thumb_url) => {

        cover_page = cover_page.href.replace("https://passthepopcorn.me", "https://www.imdb.com")



        GM_xmlhttpRequest({
            url : cover_page,
            method : "GET",
            timeout: 10000,
            onload : function(response) {
                if (response.status == 200) {

                    const parser = new DOMParser();
                    const result = parser.parseFromString(response.responseText, "text/html");

                    let thumb_search = thumb_url.split("/images/M/")[1].split(".")[0]

                    let cover_url

                    result.querySelectorAll("img").forEach((img) => {

                        try {

                            if (thumb_search === img.src.split("/images/M/")[1].split(".")[0]) {
                                cover_url = img.src
                            }

                        } catch(e){}

                    })


                    document.querySelector("#image").value = cover_url

                    addListener()



                }
            }
        })
    }


    const checkImage = (anchor, thumb_url) => {

        //console.log(anchor.querySelector("img").src)
        //console.log(thumb_url)

        let anchor_search = anchor.querySelector("img").src.split("/images/M/")[1].split(".")[0]
        let thumb_search = thumb_url.split("/images/M/")[1].split(".")[0]


        //console.log(anchor_search)
        //console.log(thumb_search)

        if (anchor_search === thumb_search) return true

        return false
    }



    const insertCover = () => {

        let value = document.querySelector("#imdb").value
        imdb_id = value // just in case we need it for alternative version...

        let imdbID
        if (value.startsWith("http")) imdbID = "tt" + value.split("/tt")[1].split("/")[0]
        else imdbID = value


        let url = "https://www.imdb.com/title/" + imdbID + "/mediaindex?refine=poster"


        GM_xmlhttpRequest({
            url : url,
            method : "GET",
            timeout: 10000,
            onload : function(response) {
                if (response.status == 200) {

                    const parser = new DOMParser();
                    const result = parser.parseFromString(response.responseText, "text/html");

                    if (result.querySelector(".media_index_thumb_list") === null) {
                        insertCoverAlternative()
                        return false
                    }



                    let thumb_url = result.querySelector(".subpage_title_block").querySelector("img").src

                    let big_cover_found = false


                    for (let n=0; n<result.querySelector(".media_index_thumb_list").querySelectorAll("a").length; n++) {

                        let current_a = result.querySelector(".media_index_thumb_list").querySelectorAll("a")[n]

                        if (checkImage(current_a, thumb_url) === true ) {
                            scrapeAndSetCover(current_a, thumb_url)
                            big_cover_found = true
                            break
                        }
                    }

                    if (big_cover_found === false) {
                        document.querySelector("#image").value = thumb_url // if it doesnt find the big cover for some reason, it will use the small thumb as cover
                        addListener()
                    }

                }
            }
        })
    }


    let imdb_id = ""
    const insertCoverAlternative = () => {

        let value = document.querySelector("#imdb").value

        let imdbID = imdb_id


        let url = "https://www.imdb.com/title/" + imdbID + "/mediaindex"


        GM_xmlhttpRequest({
            url : url,
            method : "GET",
            timeout: 10000,
            onload : function(response) {
                if (response.status == 200) {

                    const parser = new DOMParser();
                    const result = parser.parseFromString(response.responseText, "text/html");


                    let thumb_url = result.querySelector(".subpage_title_block").querySelector("img").src

                    let big_cover_found = false

                    for (let n=0; n<result.querySelector(".media_index_thumb_list").querySelectorAll("a").length; n++) {

                        let current_a = result.querySelector(".media_index_thumb_list").querySelectorAll("a")[n]

                        if (checkImage(current_a, thumb_url) === true ) {
                            scrapeAndSetCover(current_a, thumb_url)
                            big_cover_found = true
                            break
                        }
                    }

                    if (big_cover_found === false) {
                        document.querySelector("#image").value = thumb_url // if it doesnt find the big cover for some reason, it will use the small thumb as cover
                        addListener()
                    }

                }
            }
        })


    }


    document.querySelector("#autofill").addEventListener("click", () => insertCover() )


})();