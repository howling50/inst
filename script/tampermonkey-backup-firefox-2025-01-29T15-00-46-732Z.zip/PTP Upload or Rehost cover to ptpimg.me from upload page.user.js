// ==UserScript==
// @name         PTP Upload or Rehost cover to ptpimg.me from upload page
// @version      0.1
// @description  Adds an Upload and a Rehost link next to the cover input on the upload page that allows (re)hosting an image on ptpimg.me
// @author       Chameleon
// @include      http*://*passthepopcorn.me/upload.php*
// @grant        GM_xmlhttpRequest
// ==/UserScript==

(function() {
  'use strict';

  var img=document.getElementById('image');
  if(!img)
    return;

  var message=document.createElement('span');
  var a=document.createElement('a');
  a.innerHTML='Rehost';
  a.href='javascript:void(0);';
  a.setAttribute('style', 'margin-right:5px;');
  img.parentNode.appendChild(a);
  a.addEventListener('click', rehost.bind(undefined, a, img, message));

  var a=document.createElement('a');
  a.innerHTML='Upload';
  a.href='javascript:void(0);';
  a.setAttribute('style', 'margin-right:5px;');
  img.parentNode.appendChild(a);
  a.addEventListener('click', upload.bind(undefined, a, img, message));

  img.parentNode.appendChild(message);
})();

function rehost(a, img, message)
{
  message.innerHTML='Rehosting';
  var apiKey = '23afcabb-5ee3-464b-aa7c-03e26fdbc2a1';
  if(!apiKey)
    return;

  if(img.value.indexOf("ptpimg.me") !== -1)
  {
    message.innerHTML='Image already rehosted on ptpimg.me';
    clear(message);
  }

  GM_xmlhttpRequest({
    method: "POST",
    url: 'https://ptpimg.me/upload.php',
    data: "link-upload="+encodeURIComponent(img.value)+'&api_key='+apiKey,
    headers: {
      "Content-Type": "application/x-www-form-urlencoded"
    },
    onload: function(response) { uploaded(a, img, message, response.responseText); }
  });
}

function upload(a, img, message)
{
  var file = document.getElementById('coverUpload');
  if(file)
  {
    file.parentNode.removeChild(file);
  }
  file=document.createElement('input');
  file.setAttribute('style', 'height:0px; width:0px; opacity:0;');
  file.type='file';
  img.parentNode.appendChild(file);
  file.addEventListener('change', uploadFile.bind(undefined, a, img, message), false);
  file.accept="image/*";
  file.click();
}

function uploadFile(a, img, message, event)
{
  var files=event.target.files;
  for(var i=0; i<files.length; i++)
  {
    var f=files[i];
    if(f.type.indexOf("image") != -1)
    {
      message.innerHTML = 'Uploading...';
      upload1(a, img, message, f);
      break;
    }
    else
    {
      message.innerHTML = 'Not an image';
    }
  }
}

function upload1(a, img, message, file)
{
   var apiKey = '23afcabb-5ee3-464b-aa7c-03e26fdbc2a1';
  if(!apiKey)
    return;
  var formData = new FormData();
  formData.append('file-upload[0]', file);
  formData.append('api_key', apiKey);
  GM_xmlhttpRequest({
    method: "POST",
    url: 'https://ptpimg.me/upload.php',
    //binary: true,
    data: formData,
    /* headers: {
        "Content-Type": "multipart/form-data"
      },*/
    onload: function(response) {
      if(response.status == 200)
      {
        uploaded(a, img, message, response.responseText);
      }
      else
      {
        console.log("Failed to upload: \n"+response.responseHeaders+' '+response.status+' '+response.statusText);
        message.innerHTML = "Failed to upload to ptpimg.me: "+response.status;
        return;
      }
    }
  });
}

function uploaded(a, img, message, response)
{
  var r=JSON.parse(response)[0];
  img.value="https://ptpimg.me/"+r.code+'.'+r.ext;

  message.innerHTML='Done';
  clear(message);
}

function clear(message)
{
  window.setTimeout(clear1.bind(undefined, message), 2000);
}
function clear1(message)
{
  message.innerHTML='';
}

function getApiKey(message, func)
{
   var apiKey = '23afcabb-5ee3-464b-aa7c-03e26fdbc2a1';
  if(!apiKey)
  {
    message.innerHTML="No api key found - loading";
    GM_xmlhttpRequest({
      method: "GET",
      url: 'https://ptpimg.me',
      onload: function(response) { if(response.status == 200) {gotAPIKey(message, func, response.responseText); } else { message.innerHTML = 'ptpimg.me error: '+response.status; } }
    });
    return false;
  }
  else
    return apiKey;
}

function gotAPIKey(message, func, response)
{
  var key=response.split("value='")[1].split("'")[0];
  if(key.length != 36)
  {
    message.innerHTML = "You aren't logged in to ptpimg.me";
    return;
  }
  window.localStorage.ptpimgmeApiKey=key;

  func();
}