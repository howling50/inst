// ==UserScript==
// @name       	    BIB :: OverDrive
// @version    	    0.68
// @description	    Search Bibliotik from Overdrive
// @grant   	    GM_deleteValue
// @grant           GM_getValue
// @grant           GM_setValue
// @grant           GM_xmlhttpRequest
// @grant           GM.getValue
// @grant           GM.setValue
// @grant           GM.xmlhttpRequest
// @connect         *
// @include	        http*://*.overdrive.com/*
// @include	        http*://*.overdrive.com/account/settings
// @include	        http*://*.overdrive.com/collection/*
// @include	        http*://*.overdrive.com/collections/*/*
// @include	        http*://*.overdrive.com/creators/*/*
// @include	        http*://*.overdrive.com/media/*/*
// @include	        http*://*.overdrive.com/search*
// @include	        http*://*.overdrive.com/subjects*
// @include	        http*://*.libraryreserve.com/*/*/MyAccount*
// @include	        http*://*.libraryreserve.com/*/*/*/MyAccount*
// @include	        http*://*.libraryreserve.com/*/*/*/MyCompleteWishList*
// @include	        http*://*.libraryreserve.com/*/*/*/WaitingListForm*
// @include	        http*://*.libraryreserve.com/*/*/*/*/ContentDetails*
// @include	        http*://*.libraryreserve.com/*/*/*/*/Default*
// @include	        http*://*.libraryreserve.com/*/*/*/*/SearchResults*
// @include	        http*://*.lib.overdrive.com/*/*/*/*/ContentDetails*
// @include	        http*://*.lib.overdrive.com/*/*/*/*/Default*
// @include	        http*://*.lib.overdrive.com/*/*/*/*/SearchResults*
// @include	        http*://*.live-brary.com/*/*/*/*/Default*
// @include	        http*://*.live-brary.com/*/*/*/*/SearchResults*
// @include	        http*://*.live-brary.com/*/*/*/*/ContentDetails*
// @include	        http*://*.*.org/*/*/*/*/ContentDetails*
// @include	        http*://*.*.org/*/*/*/*/Default*
// @include	        http*://*.*.org/*/*/*/*/SearchResults*
// @include	        http*://*.*.org/*/*/*/*/WaitingListForm*
// @require         https://ajax.googleapis.com/ajax/libs/jquery/2.2.2/jquery.min.js
// @require         https://cdnjs.cloudflare.com/ajax/libs/underscore.js/1.8.3/underscore-min.js
// @require         https://greasemonkey.github.io/gm4-polyfill/gm4-polyfill.js
// ==/UserScript==

const windowHostname = window.location.hostname;
const windowLocation = window.location.toString();

const debug = true;
const overDriveComSmall = false;

let axisLibraries = [];
let myOverDriveLibraries;

let authors = [],
    contributors = [],
    editors = [],
    translators = [],
    narrators = [];

let bookLibraryLinks = [];

// MARK: Helper Functions

// http://james.padolsey.com/snippets/regex-selector-for-jquery/
jQuery.expr[":"].regex = function (elem, index, match) {
    var matchParams = match[3].split(","),
        validLabels = /^(data|css):/,
        attr = {
            method: matchParams[0].match(validLabels) ?
                matchParams[0].split(":")[0] : "attr",
            property: matchParams.shift().replace(validLabels, "")
        },
        regexFlags = "ig",
        regex = new RegExp(matchParams.join("").replace(/^\s+|\s+$/g, ""), regexFlags);
    return regex.test(jQuery(elem)[attr.method](attr.property));
};

/**
 * @return {boolean}
 */
function ContainsAny(str, items) {
    for (var i in items) {
        const item = items[i];
        if (str.indexOf(item) > -1) {
            return true;
        }
    }
    return false;
}

// https://stackoverflow.com/questions/5796718/html-entity-decode/27385169
var decodeEntities = (function () {
    // this prevents any overhead from creating the object each time
    var element = document.createElement("div");

    function decodeHTMLEntities(str) {
        if (str && typeof str === "string") {
            // strip script/html tags
            str = str.replace(/<script[^>]*>([\S\s]*?)<\/script>/gmi, "");
            str = str.replace(/<\/?\w(?:[^"'>]|"[^"]*"|'[^']*')*>/gmi, "");
            element.innerHTML = str;
            str = element.textContent;
            element.textContent = "";
        }

        return str;
    }

    return decodeHTMLEntities;
})();

function titleCase(str) {
    return str.toLowerCase().split(" ").map(function (word) {
        return word.replace(word[0], word[0].toUpperCase());
    }).join(" ");
}

String.prototype.isUpperCase = function () {
    return this.valueOf().toUpperCase() === this.valueOf();
};

// http://coursesweb.net/javascript/convert-bbcode-html-javascript_cs
// https://gist.github.com/soyuka/6183947

let htmlToBBCode = function (html) {

    html = html.replace(/<pre(.*?)>(.*?)<\/pre>/gmi, "[code]$2[/code]");
    html = html.replace(/<h[1-7](.*?)>(.*?)<\/h[1-7]>/, "\n[h]$2[/h]\n");

    //paragraph handling:
    //- if a paragraph opens on the same line as another one closes, insert an extra blank line
    //- opening tag becomes two line breaks
    //- closing tags are just removed
    // html += html.replace(/<\/p><p/<\/p>\n<p/gi;
    // html += html.replace(/<p[^>]*>/\n\n/gi;
    // html += html.replace(/<\/p>//gi;

    html = html.replace(/<\/p>\n\n<p>/gi, "\n\n\n");
    html = html.replace(/<br><br>/gi, "\n\n\n");
    html = html.replace(/\n\n\n/gi, "\n\n");
    html = html.replace(/<br(.*?)>/gi, "\n");
    html = html.replace(/<textarea(.*?)>(.*?)<\/textarea>/gmi, "\[code]$2\[\/code]");
    html = html.replace(/<b>/gi, "[b]");
    html = html.replace(/<i>/gi, "[i]");
    html = html.replace(/<u>/gi, "[u]");
    html = html.replace(/<\/b>/gi, "[/b]");
    html = html.replace(/<\/i>/gi, "[/i]");
    html = html.replace(/<\/u>/gi, "[/u]");
    html = html.replace(/<em>/gi, "[b]");
    html = html.replace(/<\/em>/gi, "[/b]");
    html = html.replace(/<strong>/gi, "[b]");
    html = html.replace(/<\/strong>/gi, "[/b]");
    html = html.replace(/<cite>/gi, "[i]");
    html = html.replace(/<\/cite>/gi, "[/i]");
    html = html.replace(/<font color="(.*?)">(.*?)<\/font>/gmi, "[color=$1]$2[/color]");
    html = html.replace(/<font color=(.*?)>(.*?)<\/font>/gmi, "[color=$1]$2[/color]");
    html = html.replace(/<link(.*?)>/gi, "");
    html = html.replace(/<li(.*?)>(.*?)<\/li>/gi, "\n[*] $2");
    html = html.replace(/<ul(.*?)>/gi, "[list]");
    html = html.replace(/<\/ul>/gi, "[/list]");
    html = html.replace(/<div>/gi, "\n");
    html = html.replace(/<\/div>/gi, "\n");
    html = html.replace(/<td(.*?)>/gi, " ");
    html = html.replace(/<tr(.*?)>/gi, "\n");

    html = html.replace(/<img(.*?)src="(.*?)"(.*?)>/gi, "[img]$2[/img]");
    html = html.replace(/<a(.*?)href="(.*?)"(.*?)>(.*?)<\/a>/gi, "[url=$2]$4[/url]");

    html = html.replace(/<head>(.*?)<\/head>/gmi, "");
    html = html.replace(/<object>(.*?)<\/object>/gmi, "");
    html = html.replace(/<script(.*?)>(.*?)<\/script>/gmi, "");
    html = html.replace(/<style(.*?)>(.*?)<\/style>/gmi, "");
    html = html.replace(/<title>(.*?)<\/title>/gmi, "");
    html = html.replace(/<!--(.*?)-->/gmi, "\n");

    html = html.replace(/\/\//gi, "/");
    html = html.replace(/http:\//gi, "http://");

    html = html.replace(/<(?:[^>'"]*|(['"]).*?\1)*>/gmi, "");
    html = html.replace(/\r\r/gi, "");
    html = html.replace(/\[img]\//gi, "[img]");
    html = html.replace(/\[url=\//gi, "[url=");

    // html = html.replace(/(\S)\n/gi, "$1 ");

    return html;
};

// MARK: Init

function init() {
    // load libraries
    if (GM_getValue("myLibraries", 0)) {
        myOverDriveLibraries = GM_getValue("myLibraries").split(",");
    }
    if (GM_getValue("axisLibraries", 0)) {
        axisLibraries = GM_getValue("axisLibraries").split(",");
    }

    // TEMP - move / try search field
    const searchIcon = $("ul.right.desktop.hide-for-small-only.Nav-bottomRightLinks");
    searchIcon.prepend("<li style=\"position:relative;bottom:8px\">" +
        "<form action=\"/search\"><input type=\"text\" size=\"10\" name=\"query\" data-search=\"nav-search\">" +
        "</form></li>");
}

// MARK: functions

function checkAxis(isbn) {
    if (isbn && axisLibraries.length) {
        console.log("Axis 360 search ISBN: " + isbn);
        axisLibraries.forEach(function (library) {
            const axisUrl = "http://" + library + ".axis360.baker-taylor.com/Title?itemId=";
            const url = "http://" + library + ".axis360.baker-taylor.com/Search/GetContent?term=" + isbn;
            GM_xmlhttpRequest({
                method: "GET",
                url: url,
                onload: function (response) {
                    const results = $.parseJSON(response.responseText);
                    if (results.TotalHits !== 0) {
                        console.log("Found in Axis: " + library);
                        const axisLink = " <a target=\"_blank\" href=\"" + axisUrl + results.Books[0].BookID + "\">" +
                            library.toUpperCase() + "</a>";
                        const axis = $("#axis");
                        axis.append(axisLink);
                        axis.css("display", "block");
                    }
                }
            });
        });
    }
}

function fixAuthor(author) {
    if (author.indexOf("Various") > -1) {
        author = "";
    } else {
        author = author.replace(/\s*\(\w+\)/g, "")
            .replace(/\s*\(Author\)/g, "")
            .replace(/, J\.D\./gi, "")
            .replace(/, M\.H\./gi, "")
            .replace(/, MBA/gi, "")
            .replace(/, Ph\.D\./gi, "")
            .replace(/ Ph\.D\./gi, "")
            .replace(/, Ph\.D/gi, "")
            .replace(/ Ph\.D/gi, "")
            .replace(/\s*\(\d+\)/g, "")
            .replace(/ [A-Z]\. /, "\ ")
            .replace(",\ C.N.C.", "")
            .replace(",\ O.B.E.", "")
            .replace(",\ M.S.", "")
            .replace(",\ D.C.", "")
            .replace(",\ D.O.", "")
            .replace(",\ M.D.", "")
            .replace(",\ MD", "")
            .replace(",\ N.D.", "")
            .replace(",\ ACC", "")
            .replace(",\ CHHC", "")
            .replace(",\ CPC", "")
            .replace("\ MA", "")
            .replace("\ MD", "")
            .replace(",\ NMD", "")
            .replace(",\ PhD", "")
            .replace(",\ Jr.", "\ Jr.")
            .replace("Dr.\ ", "")
            .replace("Mr.\ ", "")
            .replace("Rev.\ ", "")
            .trim();
    }
    return (author);
}

function getIsbn() {
    let isbnCom = $("li:contains(\"ISBN\") > a:last");
    if (isbnCom.length) {
        return isbnCom.text();
    }

    let isbnOld = $("div.six.mobile-two.columns.titleInfoLeft:contains(\"ISBN\"):first");
    if (isbnOld.length) {
        return isbnOld.next().text();
    }
}

function getIsbnBookPage() {
    let isbn = $("li:contains(\"ISBN\"):first");
    if (isbn.length) {
        return isbn.text().replace("ISBN: ", "").trim();
    } else {
        isbn = $("div.six.mobile-two.columns.titleInfoLeft:contains(\"ISBN\"):first").next().text().trim();
        return isbn;
    }
}

function getLanguageLink() {
    const language = $("b.TitleDetailsSidebar-sectionHeader.u-allCaps:contains(\"Languages\")").next().text().trim();

    switch (language) {
    case "English":
    case "Inglés":
        return "&lan%5B%5D=1";
    case "French":
        return "&lan%5B%5D=3";
    case "German":
    case "Alemán":
        return "&lan%5B%5D=2";
    case "Italian":
    case "Italiano":
        return "&lan%5B%5D=5";
    case "Spanish; Castilian":
        return "&lan%5B%5D=4";
    default:
        return "";
    }
}

function mainTitle(title) {
    if (title.indexOf("(") >= 0) {
        title = title.substr(0, title.indexOf(" ("));
    }
    if (title.indexOf("[") >= 0) {
        title = title.substr(0, title.indexOf(" ["));
    }
    if (title.indexOf(":") >= 0) {
        title = title.substr(0, title.indexOf(":"));
    }
    if (title.indexOf("/") >= 0) {
        title = title.substr(0, title.indexOf("/"));
    }
//    if (title.indexOf(". ") >= 0) {
//        title = title.substr(0, title.indexOf(". "));
//    }
    if (title.indexOf(" -") >= 0) {
        title = title.substr(0, title.indexOf(" -"));
    }
    if (title.indexOf("--") >= 0) {
        title = title.substr(0, title.indexOf("--"));
    }
    title = title.trim();
    return title;
}

function addLibraryLink(link) {
    bookLibraryLinks.push(link);
}

function libraryList(id) {
    let libraryProviders = [];

    $.post("https://www.overdrive.com/_Ajax/libraries-for-media?mediaId=" + location.pathname.split("/")[2] + "&q=")
        .done(function (libs) {
            libs = libs.aaData;
            //noinspection JSUndefinedPropertyAssignment
            unsafeWindow.libdata = libraryProviders;
            let all = {}, counts = {}, t;
            for (var i = 0; i < libs.length; i++) {
                all[t = libs[i].libraryUrl] = libs[i].consortium;
                counts[t] ? counts[t]++ : counts[t] = 1;
            }
            for (i in all)
                libraryProviders.push({
                    href: "http://" + i + "/ContentDetails.htm?id=" + id,
                    text: all[i]
                });

            // ** TODO new sort
            libraryProviders = _.sortBy(libraryProviders, "text");

            let libraries = $.map(libraryProviders, function (lib) {
                if ($.inArray(lib["text"], myOverDriveLibraries) !== -1) {
                    console.log("Available library: " + lib["text"]);
                    addLibraryLink(lib["href"]);
                    return "<a class=\"bib\" target=\"_blank\" href=\"" + lib["href"] + "\">" + lib["text"] + "</a>";
                }
            }).join(", ");

            const libsId = $("#lib");

            if (libraries.length) {
                // console.log("Result: " + libraries);
                libsId.append(libraries);
                libsId.css("display", "");
            } else {
                console.log("No libraries.");
                console.log(myOverDriveLibraries);
            }

            // add all libraries link
            libsId.append(", <a style=\"text-decoration:none\" id=\"allLibraries\" href=\"#\">Open all</a>");

            $("#allLibraries").on("click", function () { // .click(function () {
                console.log("Open all libraries.");

                window.top.close(); // close tab
                $.each(bookLibraryLinks, function (index, value) {
                    console.log("Opening link: " + value);
                    window.open(value);
                });
            });
        });
}

// MARK: OverDrive

function overDriveAccountPage() {
    // let formats = $('span.dwnld-span-bottom:contains("format")');
    // console.log("Formats: " + formats.length);
    //
    // if (formats.length) {
    //     formats.parent().click();
    //     $("a[value=410]")[0].click()
    //     $('a:contains("Confirmer")').click()
    // }

    // old od
    $(".bookshelf-format-button-contain").each(function () {
        // let formats =  $(this).find("div.button.radius.dropdown-bookshelf.bookshelf-format-button.dwnld-color");
        const formats = $(this).find("span.dwnld-span-bottom:contains(\"format\")");
        if (formats.length) {
            formats.parent().click();
            $(this).find("a[value=410]")[0].click();
        }
    });
}

function overDriveSettings() {
    // load libraries
    let inputFieldLibraries = "";

    if (GM_getValue("myLibraries", 0)) {
        myOverDriveLibraries = GM_getValue("myLibraries").split(",");
        inputFieldLibraries = myOverDriveLibraries.join(",");
    }
    else {
        inputFieldLibraries = "Case Sensitive,Library 1,Library 2";
        myOverDriveLibraries = inputFieldLibraries.split(",");
    }

    const cancelForm = $("div.form-save-cancel");
    if (cancelForm.length) {
        // .com
        cancelForm.append("<p>Libraries: <input id=\"overdriveLibraries\" type=\"text\" value=\"\" name=\"overdriveLibraries\" size=\"10\"> <button id=\"setOverDriveLibraries\" value=\"Set\" type=\"button\" role=\"button\">Set</button></p>");
        cancelForm.append("<p>Axis Libraries: <input id=\"axisLibraries\" type=\"text\" value=\"\" name=\"axisLibraries\" size=\"10\"> <button id=\"setAxisLibraries\" value=\"Set\" type=\"button\" role=\"button\">Set</button></p>");

    } else {
        // library
        let settingsConfig = $("div.large-9.columns.js-settingsConfiguration");
        settingsConfig.append("<h2 class='settings-header u-allCaps'>Bibliotik</h2><div class='panel settings-panel bib-panel'></div>");

        const bibPanel = $("div.bib-panel");
        bibPanel.append("<label class='SettingsPage-settingsLabel'>Axis Libraries</label><div style='width:100%'><div style='width:85%'><input class='form-control' id='axisLibraries' type='text' name='axisLibraries'> <label class='settings-select button radius' id='setAxisLibraries' style='float:right;clear:left'>Set</label></div></div>");
    }

    const axisLibrariesField = $("#axisLibraries");
    const overdriveLibrariesField = $("#overdriveLibraries");

    axisLibrariesField.val(axisLibraries);
    overdriveLibrariesField.val(inputFieldLibraries);

    $("#setOverDriveLibraries").click(function () {
        GM_setValue("myLibraries", overdriveLibrariesField.val());
        location.reload();
    });

    $("#setAxisLibraries").click(function () {
        GM_setValue("axisLibraries", axisLibrariesField.val());
        location.reload();
    });
}

function overDriveBookPage() {
    const formats = $("p.TitleDetailsSidebar-detailsContainer:first").text().trim();

    if (formats.indexOf("EPUB") > -1 || formats.indexOf("PDF") > -1 ||
        formats.indexOf("Kindle") > -1 || formats.indexOf("MP3") > -1) {
        // info
        let author = $("div.TitleDetailsHeading-creator").find("a.TitleDetailsHeading-creatorLink:first").text();
        author = fixAuthor(author);
        const title = $("h1.TitleDetailsHeading-title").text();
        const isbn = getIsbnBookPage();
        let languageSearch = getLanguageLink();

        const bibToolbar = overDriveBookPageToolbar(title, author, languageSearch, isbn, formats);
        $("div.TitleDetailsSidebar").prepend(bibToolbar);

        checkAxis(isbn);
        overDriveSearchPage();

        overDriveBookPageSidebarBookSize();
        overDriveBookPageSidebarPublisherLink();

        // expand description
        $("img.TitleDetailsDescription-descriptionArrow.js-description-arrow.is-unexpanded").click();
    }
}

function overDriveBookPageSidebarBookSize() {
    let formatsHeader = $("h2.TitleDetailsSidebar-sectionHeader.u-allCaps:contains('Formats'), h2.TitleDetailsSidebar-sectionHeader.u-allCaps:contains('Formatos')");
    let pdfContainer = $("h2:contains('PDF')").next().find("b:contains('size:'), b:contains('archivo:')");
    if (pdfContainer.length) {
        const pdfSize = pdfContainer.parent().text().split(": ")[1].trim();
        formatsHeader.next().find("span:contains('PDF')").append(" (" + pdfSize + ")");
    }
    let ePubContainer = $("h2:contains('EPUB')").next().find("b:contains('size:'), b:contains('archivo:')");
    if (ePubContainer.length) {
        const epubSize = ePubContainer.parent().text().split(": ")[1].trim();
        formatsHeader.next().find("span:contains('EPUB')").append(" (" + epubSize + ")");
    }
    let mp3Container = $("h2:contains('MP3')").next().find("b:contains('size:'), b:contains('archivo:')");
    if (mp3Container.length) {
        const mp3Size = mp3Container.parent().text().split(": ")[1].trim();
        formatsHeader.next().find("span:contains('MP3')").append(" (" + mp3Size + ")");
    }

}

function overDriveBookPageSidebarPublisherLink() {
    let publisherLinkLabel = $("b:contains('Publisher:'):first, b:contains('Editorial:'):first");
    if (publisherLinkLabel.length) {
        const publisherLink = publisherLinkLabel.next().clone();
        const publisherLinkString = "<div class='large-12 columns'><b class='TitleDetailsSidebar-sectionHeader u-allCaps'>" + publisherLinkLabel.text().replace(":", "") + "</b><p class='TitleDetailsSidebar-detailsContainer publisherLink'></p></div>";
        $(".TitleDetailsSidebar-sectionHeader.u-allCaps:contains('subjects'), .TitleDetailsSidebar-sectionHeader.u-allCaps:contains('temas')")
            .parent().before(publisherLinkString);
        $(".publisherLink").html(publisherLink);
    }
}

function overDriveBookPageToolbar(title, author, languageSearch, isbn, formats) {
    let bibToolbar = "<div class='large-12 columns'>" +
        "<p id='bibtoolbar' class='TitleDetailsSidebar-detailsContainer' style='font-size:small;margin-top:0;margin-bottom:0.35em'>" +
        "<b class='TitleDetailsSidebar-sectionHeader u-allCaps'>Bibliotik</b><br/>" +
        " <a target='_blank' href='" + searchBibliotik(title, author, languageSearch) + "'>Title" + "</a>" +
        " <a target='_blank' href='" + searchBibliotikAuthor(author, languageSearch) + "'>Author" + "</a>" +
        " <a target='_blank' href='" + searchBibliotikRequest(title, author) + "'>Requests" + "</a>";

    bibToolbar += "<br/><b class='TitleDetailsSidebar-sectionHeader u-allCaps'>Search</b><br/>" +
        "<a target='_blank' href='" + searchAmazon(title, author) + "'>Amazon</a>" +
        " <a target='_blank' href='" + searchAmazon(title, author, "de") + "'>.de</a>" +
        " <a target='_blank' href='" + searchAmazon(title, author, "es") + "'>.es</a>" +
        " <a target='_blank' href='" + searchAmazon(title, author, "fr") + "'>.fr</a>" +
        " <a target='_blank' href='" + searchAmazon(title, author, "it") + "'>.it</a>" +
        " <a target='_blank' href='" + searchAmazon(title, author, "com.mx") + "'>.mx</a>" +
        " <a target='_blank' href='" + searchAmazon(title, author, "co.uk") + "'>.uk</a>" +
        "<br/>" +
        " <a target='_blank' href='" + searchBN(title, author) + "'>B&N</a>" +
        " <a target='_blank' href='" + searchGoodReads(title, author) + "'>GoodReads</a>" +
        " <a target='_blank' href='" + searchOverDriveISBN(isbn) + "'>OverDrive</a>" +
        "<span id='axis' style='display:none'><b class='TitleDetailsSidebar-sectionHeader u-allCaps'>Axis</b><br/></span></p>" +
        "<br/></div></div>";
    return bibToolbar;
}

function overDriveSearchPage() {
    // carousel-item = home page top
    $("div.Carousel-item, div.title-container, div.title-container.title").each(function () {
        if ($(this).find("i.icon-periodicals").length === 1 || $(this).find("i.icon-video").length === 1) {
            return true;
        }

        const author = fixAuthor($(this).find("p.title-author").find("a.secondary-hover-underline").text());
        const title = mainTitle($(this).find("h3.title-name").text());

        console.log("Toolbar for: " + title);

        // over cover
        $(this).find("div.CoverImageContainer").append(overDriveSearchPageNewBookSearchString(title, author));
    });

    overDriveSearchPageCSS();

    // search page expand options
    const eBookFilter = $("div.u-hideMe[data-filter-content=\"eBook\"]");
    if (eBookFilter) {
        eBookFilter.css({"display": "block"});
    }
    const dateFilter = $("div.u-hideMe[data-filter-content=\"dateAdded\"]");
    if (dateFilter) {
        dateFilter.css({"display": "block"});
    }

    const languageFilter = $("div.u-hideMe[data-filter-content=\"languages\"]");
    if (languageFilter) {
        languageFilter.css({"display": "block"});
    }
}

function overDriveSearchPageNewBookSearchString(title, author) {
    return "<div style='width:100%;bottom:0;position:absolute'><div class='bibGrid' style='visibility:hidden'>" +
        "<a class='bibGridLink' href='" + searchBibliotik(title, author) + "'>Title</a>" +
        " <a class='bibGridLink' href='" + searchBibliotikAuthor(author) + "'>Author</a>" +
        " <a class='bibGridLink' href='" + searchBibliotikRequest(title, author) + "'> requests</a>" +
        "<br/><a class='bibGridLink' href='" + searchAmazon(title, author) + "'>Amazon</a>" +
        " <a class='bibGridLink' href='" + searchBN(title, author) + "'>B&N</a>" +
        " <a class='bibGridLink' href='" + searchGoodReads(title, author) + "'>GoodReads</a>" +
        "</div></div>";
}

function overDriveSearchPageCSS() {
    $("div.more-actions.dot-menu.secondary-background-hover.contrast").css("margin-top", "-348px");
    const bibGridLink = $("a.bibGridLink");
    bibGridLink.css({"color": "LightGray", "display": "inline", "font-weight": "bold"});
    bibGridLink.attr("target", "_blank");
    bibGridLink.mouseover(function () {
        $(this).css("color", "white");
    }).mouseout(function () {
        $(this).css("color", "LightGray");
    });
    $("div.bibGrid").css({
        "background-color": "rgba(0, 0, 0, 0.6)",
        "position": "relative",
        "bottom": "0px",
        "z-index": "1",
        "padding": "3px",
        "font-size": "8.5pt",
        "text-transform": "uppercase",
        "visibility": "visible"
    });
}

// Item detail page
function overDriveComBookPage() {
    const pageFormat = $("span.title-page__format");

    $(".title-page__info").css({"padding-top": "30px"});

    let title = $("h1.title-page__title").text();
    title = mainTitle(title);
    console.log("Title: " + title);

    const author = $(".title-page__creator > a:first").text();

    // publishers link
    const foldingPanel = $(".folding-panel__content");
    const publisherLink = foldingPanel.find("a[href*=publishers]").attr("href");
    const publisher = foldingPanel.find("a[href*=publishers]").text();

    // pageFormat.append(" <a style='font-size:medium' href='" + publisherLink + "'>" + publisher + "</a>");
    const sideBar = $("div.title-page__wrapper");
    sideBar.prepend("<div class='folding-panel__content'><a href='" + publisherLink + "'>" + publisher + "</a>");
    sideBar.prepend("<h3 class='folding-panel__label folding-panel__disabled' style='margin-top:-4em'>Publisher</h3>");

    // file size
    let fileSize = overDriveComBookPageFileSize();
    pageFormat.append(" - <span style='font-size:medium'>" + fileSize + "</span>");

    $("h4.title-page__creator").after(overDriveComBookPageToolbar(title, author));

    if (myOverDriveLibraries) {
        console.log("Adding library links");
        const id = $("meta[property='od:id']").attr("content").toUpperCase();
        libraryList(id);
        $("div.bibToolbar").append("<p class='bibToolbar' id='lib' style='display:none'>Libraries: " + "</p>");
    }

    $("div.bibToolbar").css({
        "font-family": "sans-serif",
        "font-size": "12px",
        "margin-top": "10px"
    });
    $("p.bibToolbar").css({
        "margin-bottom": "5px"
    });
    $("<style type='text/css'>p.bibToolbar > a {  text-decoration:none; font-weight:300 }</style>").appendTo("head");

    checkAxis(getIsbn());
    $("span.icon.icon-chevron:last").click(); // expand description
    overDriveComMainPage(); // related titles

    // uploaded toggle
    let uploaded = [];
    if (localStorage.getItem("uploaded") !== null) {
        uploaded = JSON.parse(localStorage["uploaded"]);
    }

    $(".icon").css({"border-radius": "3px", "width": "20px", "height": "20px"});
    let mediaId = location.pathname.split("/")[2];
    const iconEbook = $(".icon.icon-ebook");
    const uploadedEbook = $(".uploaded");

    if (_.indexOf(uploaded, mediaId) > -1) {
        iconEbook.toggleClass("uploaded");
        uploadedEbook.css({"background-color": "red", "border-color": "red"});
        console.log("Item uploaded: " + mediaId);
    }

    // uploaded icon
    iconEbook.click(function () {
        $(this).toggleClass("uploaded");
        if (_.indexOf(uploaded, mediaId) > -1) {
            uploaded = _.without(uploaded, mediaId);
        } else {
            uploaded.push(mediaId);
        }
        localStorage["uploaded"] = JSON.stringify(uploaded);
        iconEbook.css({"background-color": "#062340", "border-color": "#062340"});
        uploadedEbook.css({"background-color": "red", "border-color": "red"});
    });
}

function overDriveComBookPageFileSize() {
    let fileSize = "";
    const epub = $("li:contains(\"Adobe EPUB\")");
    const pdf = $("li:contains(\"PDF\")");
    const mp3 = $("li:contains(\"OverDrive MP3\")");
    if (epub.length) {
        fileSize += " ePub " + epub.text().match(".*? [A-Z]B");
    }
    if (pdf.length) {
        fileSize += " PDF " + pdf.text().match(".*? [A-Z]B");
    }
    if (mp3.length) {
        fileSize += " MP3 " + mp3.text().match(".*? [A-Z]B");
    }
    return fileSize;
}

function overDriveComBookPageToolbar(title, author) {
    return "<div class=\"bibToolbar\"><p class=\"bibToolbar\"><span style=\"text-transform:none\">Bibliotik: " +
        " <a class=\"bib\" target=\"_blank\" href=\"" + searchBibliotik(title, author) + "\">Title</a>" +
        " <a class=\"bib\" target=\"_blank\" href=\"" + searchBibliotikAuthor(author) + "\">Author</a>" +
        " <a class=\"bib\" target=\"_blank\" href=\"" + searchBibliotikRequest(title, author) + "\">Requests</a></p>" +
        "<p class=\"bibToolbar\">Search: " +
        " <a class=\"bib\" target=\"_blank\" href=\"" + searchAmazon(title, author) + "\">Amazon</a>" +
        " <a class=\"bib\" target=\"_blank\" href=\"" + searchAmazon(title, author, "de") + "\">.de</a>" +
        " <a class=\"bib\" target=\"_blank\" href=\"" + searchAmazon(title, author, "es") + "\">.es</a>" +
        " <a class=\"bib\" target=\"_blank\" href=\"" + searchAmazon(title, author, "fr") + "\">.fr</a>" +
        " <a class=\"bib\" target=\"_blank\" href=\"" + searchAmazon(title, author, "in") + "\">.in</a>" +
        " <a class=\"bib\" target=\"_blank\" href=\"" + searchAmazon(title, author, "it") + "\">.it</a>" +
        " <a class=\"bib\" target=\"_blank\" href=\"" + searchAmazon(title, author, "com.mx") + "\">.mx</a>" +
        " <a class=\"bib\" target=\"_blank\" href=\"" + searchAmazon(title, author, "co.uk") + "\">.uk</a>" +
        " <a class=\"bib\" target=\"_blank\" href=\"" + searchBN(title, author) + "\">Barnes & Noble</a>" +
        " <a class=\"bib\" target=\"_blank\" href=\"" + searchGoodReads(title, author) + "\">GoodReads</a>" +
        " <a class=\"bib\" target=\"_blank\" href=\"" + searchGoogleBooks(title, author) + "\">Google Books</a>" +
        " <a class=\"bib\" target=\"_blank\" href=\"" + searchLibGen(title, author) + "\">LibGen</a>" +
        " <a class=\"bib\" target=\"_blank\" href=\"" + searchWorldCat(title, author) + "\">WorldCat</a>" +
        "</span></p>" +
        "<p class=\"bibToolbar\"><span id=\"axis\" style=\"color:gray;font-size:small;display:none\">Axis 360: </span></p>";
}

function overDriveComMainPage() {

    let uploaded = [];
    if (localStorage.getItem("uploaded") !== null) {
        uploaded = JSON.parse(localStorage["uploaded"]);
    }

    $("div.title-result").each(function () {
        const title = $.trim($(this).find("h4.title-result__title > a").text());
        const author = $(this).find("h4.title-result__creator > span:first").text();

        let toolbarString = overDriveComSearchPageToolbar(title, author);
        $(this).find("div.title-result__cover").append(toolbarString);

        // uploaded icon
        let mediaid = $(this).find("h4.title-result__title > a").attr("href").match(/\d+/)[0];
        $(this).find(".type-icon").attr("mediaid", mediaid);
        if (_.indexOf(uploaded, mediaid) > -1) {
            $(this).find(".type-icon").toggleClass("uploaded");
            $(".uploaded").css({"background-color": "red", "border-color": "red"});
            console.log("Item uploaded: " + mediaid);
        }
    });

    const bibGridLink = $("a.bibGridLink");
    bibGridLink.css({"color": "#006595", "display": "inline", "font-family": "sans-serif"});
    bibGridLink.attr("target", "_blank");
    bibGridLink.mouseover(function () {
        $(this).css("color", "#002333");
    }).mouseout(function () {
        $(this).css("color", "#006595");
    });

    $("div.bibGridOuter").css({
        "background-color": "rgba(255, 255, 255, 0.7)",
        "width": "157.5px",
        "top": "165px",
        "position": "absolute",
        "line-height": "75%"
    });
    $("div.bibGrid").css({
        "display": "inline",
        "position": "relative",
        "z-index": "1",
        "margin": "0",
        "padding": "0px",
        "font-size": "8pt",
        "text-transform": "uppercase",
    });

    // uploaded icon
    const typeIcon = $(".type-icon");
    typeIcon.click(function () {
        let mediaid = $(this).attr("mediaid");
        $(this).toggleClass("uploaded");
        console.log("clicked: " + mediaid);
        if (_.indexOf(uploaded, mediaid) > -1) {
            uploaded = _.without(uploaded, mediaid);
        } else {
            uploaded.push(mediaid);
        }
        localStorage["uploaded"] = JSON.stringify(uploaded);
        typeIcon.css({"background-color": "#062340", "border-color": "#062340"});
        $(".uploaded").css({"background-color": "red", "border-color": "red"});
    });
}

function overDriveComSearchPage() {
    let uploaded = [];
    if (localStorage.getItem("uploaded") !== null) {
        uploaded = JSON.parse(localStorage["uploaded"]);
    }

    // links in new tab
    $("h3.title-result-row__title").find("a").attr("target", "_blank");

    // Expand search options
    $(".labelCase.closed").addClass("open"); // saved libraries
    const filterList = $("#filter-list");
    filterList.children().last().addClass("open"); // format
    filterList.find("span:contains(\"Language\")").parent().addClass("open");
    filterList.find("span:contains(\"Subjects\")").parent().addClass("open");

    // for each book
    $("div.title-result-row").each(function () {
        let title = $(this).find("h3.title-result-row__title").children("a").attr("data-title").trim();
        title = mainTitle(title);

        //var author = $(this).find("h3.title-result-row__creator").text().split("\n")[0].split("(")[0];
        let author = $(this).find("h3.title-result-row__creator").clone().children().remove().end().text().trim().split("\n")[0].trim();
        // $('h3:contains("AA. VV."):last').clone().children().remove().end().text().trim().split("\n")[1].trim()
        author = fixAuthor(author);

        const toolbarString = overDriveComSearchPageToolbar(title, author);
        $(this).find(".title-result-row__cover").append(toolbarString);

        // uploaded icon
        const link = $(this).find(".title-result-row__title > a").attr("href");
        const mediaid = link.match(/\d+/)[0];
        $(this).find(".type-icon").attr("mediaid", mediaid);
        if (_.indexOf(uploaded, mediaid) > -1) {
            $(this).find(".type-icon").toggleClass("uploaded");
            $(".uploaded").css({"background-color": "red", "border-color": "red"});
            console.log("Item uploaded: " + mediaid);
        }
    });
    overDriveComSearchPageCSS();

    // uploaded icon
    $(".type-icon").click(function () {
        const mediaid = $(this).attr("mediaid");
        $(this).toggleClass("uploaded");
        console.log("clicked: " + mediaid);
        if (_.indexOf(uploaded, mediaid) > -1) {
            uploaded = _.without(uploaded, mediaid);
        } else {
            uploaded.push(mediaid);
        }
        localStorage["uploaded"] = JSON.stringify(uploaded);
        $(".type-icon").css({"background-color": "#062340", "border-color": "#062340"});
        $(".uploaded").css({"background-color": "red", "border-color": "red"});
    });
}

function overDriveComSearchPageCSS() {
    // Reduce size

    if (overDriveComSmall) {
        const resultRow = $(".title-result-row");
        resultRow.css({"height": "160px"});
        resultRow.css({"margin-bottom": "0.6rem"});
        $(".title-result-row__cover-cell").css({"width": "140px"});
        $(".title-result-row__title").css({"font-size": "1.1rem"});
        $("h3.title-result-row__creator").css({"font-size": "1.0rem"});
        $("h3.title-result-row__series").css({"font-size": "0.8rem"});
    }

    const bibGridLink = $("a.bibGridLink");
    bibGridLink.css({"color": "#006595", "display": "inline", "font-family": "sans-serif"});
    bibGridLink.attr("target", "_blank");
    bibGridLink.mouseover(function () {
        $(this).css("color", "#002333");
    }).mouseout(function () {
        $(this).css("color", "#006595");
    });
    $("div.bibGridOuter").css({
        "background-color": "rgba(255, 255, 255, 0.7)",
        "width": "180px",
        "bottom": "15px",
        "position": "absolute",
        "line-height": "75%"
    });
    $("div.bibGrid").css({
        "display": "inline",
        "position": "relative",
        "z-index": "1",
        "margin": "0",
        "padding": "0px",
        "font-size": "7.5pt",
        "text-transform": "uppercase",
    });

    // hide help header
    $("div.results").find("h6").css({"display": "none"});
    // hide save search
    // $(".results__header").css({"display": "none"});
}

function overDriveComSearchPageToolbar(title, author) {
    return "<div class=\"bibGridOuter\"><div class=\"bibGrid\">" +
        "<a class=\"bibGridLink\" href=\"" + searchBibliotik(title, author) + "\">Title</a>" +
        " <a class=\"bibGridLink\" href=\"" + searchBibliotikAuthor(author) + "\">Author</a>" +
        " <a class=\"bibGridLink\"\" href=\"" + searchBibliotikRequest(title, author) + "\">Requests</a>" +
        "<br/><a class=\"bibGridLink\" href=\"" + searchAmazon(title, author) + "\">Amazon</a>" +
        " <a class=\"bibGridLink\" href=\"" + searchAmazon(title, author, "de") + "\">.de</a>" +
        " <a class=\"bibGridLink\" href=\"" + searchAmazon(title, author, "es") + "\">.es</a>" +
        " <a class=\"bibGridLink\" href=\"" + searchAmazon(title, author, "fr") + "\">.fr</a>" +
        " <a class=\"bibGridLink\" href=\"" + searchAmazon(title, author, "it") + "\">.it</a>" +
        " <a class=\"bibGridLink\" href=\"" + searchAmazon(title, author, "co.uk") + "\">.uk</a>" +
        "<br/><a class=\"bibGridLink\" href=\"" + searchBN(title, author) + "\"> B&N</a>" +
        " <a class=\"bibGridLink\" href=\"" + searchGoodReads(title, author) + "\"> GoodReads</a>" +
        " <a class=\"bibGridLink\" href=\"" + searchWorldCat(title, author) + "\"> WC</a>" +
        "</div></div>";
}

// MARK: Search


function quoteWords(word) {
    //return encodeURIComponent(word.replace(/((?=\S*[!'-])([a-zA-Z'!-]+))/g, '"$1"'));
    return encodeURIComponent(word).replace(/'/g, "%27");
}

function searchAmazon(title, author, domain) {
    let url1 = "https://www.amazon.";
    const url2 = "/s?ie=UTF8&index=blended&keywords=";
    if (!domain) {
        url1 += "com";
    } else {
        url1 += domain;
    }
    return url1 + url2 + quoteWords(title) + " " + quoteWords(author);
}

function searchBibliotik(title, author, languageSearch) {
    const searchUrl = "https://bibliotik.me/torrents/?search=";
    if (!languageSearch) {
        languageSearch = "";
    }

    if (author.match(/Insight Guides/)) {
        author = "";
        title.replace(":", "");
    }
    if (author.match(/DK/) || author.match(/Dorling Kindersley/)) {
        author = "";
        title += " @publishers DK";
    }

    if (author.length) {
        // author = fixAuthor(author); // TODO: do before
        author = author.replace(/ [A-Z]\. /, " ");
        author = " @creators " + author;
        return searchUrl + quoteWords(title) + quoteWords(author) + languageSearch;
    } else {
        return searchUrl + quoteWords(title);
    }
}

function searchBibliotikAuthor(author, languageSearch) {
    author = fixAuthor(author);

    const searchUrl = "https://bibliotik.me/torrents/?search=";
    if (!languageSearch) {
        languageSearch = "";
    }

    return searchUrl + "@creators " + quoteWords(author) + languageSearch;
}

function searchBibliotikRequest(title, author) {
    if (author.length) {
        author = fixAuthor(author);
        author = author.replace(/ [A-Z]\. /, " ");
        return "https://bibliotik.me/requests/?search=" +
            quoteWords(title) + " @creators " + quoteWords(author);
    } else {
        return "https://bibliotik.me/requests/?search=" + quoteWords(title);
    }
}

function searchBN(title, author) {
    return "http://www.barnesandnoble.com/s/" + quoteWords(title) + " " + quoteWords(author);
}

function searchGoodReads(title, author) {
    return "https://www.goodreads.com/search?utf8=%E2%9C%93&query=" +
        quoteWords(title) + " " + quoteWords(author);
}

function searchGoogleBooks(title, author) {
    return "https://www.google.com/search?tbm=bks&q=" +
        quoteWords(title) + " " + quoteWords(author);
}

function searchLibGen(title, author) {
    return "http://gen.lib.rus.ec/search.php?open=0&view=simple&column=def&req=" +
        quoteWords(title) + " " + quoteWords(author);
}

function searchOverDriveISBN(isbn) {
    return "https://www.overdrive.com/search?&autoLibrary=f&autoRegion=t&showAvailable=False&q=" + isbn;
}

function searchWorldCat(title, author) {
    return "https://www.worldcat.org/search?q=ti%3A" + quoteWords(title) +
        "+au%3A" + quoteWords(author) + "&qt=advanced";
}

// MARK: exec

init();

// Overdrive.com Main page
if (windowLocation.endsWith("www.overdrive.com/")) {
    window.onload = function () {
        overDriveComMainPage();
    };
}

if (windowLocation.indexOf("overdrive.com/account/settings") >= 0) {
    overDriveSettings();
}

// Overdrive Account page - old settings
if (windowLocation.indexOf("MyAccount.htm") >= 0) {
    overDriveAccountPage();
}

// www.overdrive.com Search pages
if (windowLocation.indexOf("www.overdrive.com/collections") >= 0 ||
    windowLocation.indexOf("www.overdrive.com/creators") >= 0 ||
    windowLocation.indexOf("www.overdrive.com/search") >= 0 ||
    windowLocation.indexOf("www.overdrive.com/series") >= 0 ||
    windowLocation.indexOf("www.overdrive.com/subjects") >= 0 ||
    windowLocation.indexOf("www.overdrive.com/publishers") >= 0) {
    overDriveComSearchPage();
    // overDriveComSort(); // was going to be TODO?
}

// Overdrive.com Detail page
if (windowLocation.indexOf("www.overdrive.com/media") >= 0) {
    overDriveComBookPage();
}

// Overdrive Search pages
if (windowLocation.indexOf("www.overdrive.com") < 0) {
    if ($("div.title-container, div.title-container.title").length > 0) {
        overDriveSearchPage();
    }
}

// Overdrive Detail page
if (windowLocation.indexOf("/media/") >= 0 || windowLocation.indexOf("ContentDetails") >= 0) {
    overDriveBookPage();
}