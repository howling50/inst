// ==UserScript==
// @name         PTP torrent highlighter
// @namespace    http://tampermonkey.net/
// @version      0.25
// @description  Highlight my torrents
// @icon         https://www.google.com/s2/favicons?sz=64&domain=passthepopcorn.me
// @match        https://passthepopcorn.me/torrents.php*
// @match        https://passthepopcorn.me/collages.php?*id=*
// @match        https://passthepopcorn.me/top10.php
// @match        https://passthepopcorn.me/top10.php*type=movies*
// @match        https://passthepopcorn.me/top10.php?type=torrents*
// @match        https://passthepopcorn.me/artist.php*
// @match        https://passthepopcorn.me/user.php?id=*
// @match        https://passthepopcorn.me/bookmarks.php*
// @exclude      https://passthepopcorn.me/bookmarks.php?type=*
// @grant        unsafeWindow
// @grant        GM_addStyle
// ==/UserScript==

(function () {
	'use strict'

	// settings
	const showHighlight = true;
	const showBadges = true;
	const showBadgeCounts = true;
	const badgesOnHugeCover = false;

	const boostStats = 0;

	GM_addStyle(`
    #content .seeding, #content .seeding td {
    background: #060;
    border-color: #008000;
    }

    #content .leeching, #content .leeching td  {
    background: #600;
    border-color: #800000;
    }

    #content .downloaded, #content .downloaded td  {
    background: #975;
    border-color: #b97;
    }

    #content .snatched, #content .snatched td  {
    background: #048;
    border-color: #06a;
    }

    #content .borders {
    border-width: 5px;
    border-style: solid;
    border-radius: 6px;
    }

    #content .borders-top {
    border-width: 5px;
    border-style: solid;
    border-top-left-radius: 6px;
    border-top-right-radius: 6px;
    }

    #content .badges {
    position: absolute;
    }

    #content .badges.top {
    top: 0;
    }

    #content .badges.right {
    right: 0;
    }

    #content .badges.bottom{
    bottom: 0;
    }

    #content .badges.left {
    left: 0;
    }

    #content .badge {
    display: inline-block;
    border-width: 4px;
    border-style: solid;
    /*margin: -8px -2px;*/
    /*font-size: 12px;*/
    /*border-color: #fff;*/
    width: 32px;
    height: 32px;
    border-radius: 999px;
    color: #fff;
    text-align: center;
    line-height: 23px;
    box-shadow: #0005 3px 3px 15px;
    }

    .cover-movie-list__movie, .huge-movie-list__movie, .basic-movie-list__details-row > td, .release-name-movie-list__details-row > td {
    position: relative;
    }

    .basic-movie-list__movie__bookmark {
    max-width: 50px;
    text-align: end;
    text-transform: capitalize;}
    `);


	let torrentsColorType;
	let coloredTorrentsCount;
	let grouping;
	let closedGroups;

	const getTorrentsColorType = () => {
		coloredTorrentsCount = 0;
		let movies;
		let data = unsafeWindow.PageData || unsafeWindow.coverViewJsonData;
		if (!data.length) {
			if (window.location.pathname === '/user.php') {
				grouping = true;
				movies = [];
				if (data.RecentRatings) {
					movies = movies.concat(data.RecentRatings);
				}
				if (data.RecentSnatches) {
					movies = movies.concat(data.RecentSnatches);
				}
				if (data.RecentUploads) {
					movies = movies.concat(data.RecentUploads);
				}
				if (data.PersonalCollection) {
					movies = movies.concat(data.PersonalCollection);
				}
			} else {
				movies = data.Movies;
				grouping = data.Grouping;
				if (grouping) {
					closedGroups = data.ClosedGroups;
				}
			}

		} else if (unsafeWindow.coverViewJsonData.length === 1) {
			movies = data[0].Movies;
			grouping = data[0].Grouping;
			if (grouping) {
				closedGroups = data[0].ClosedGroups;
			}
		} else {
			movies = [];
			data.forEach(m => {
				movies = movies.concat(m.Movies);
				grouping = m.Grouping;
				if (grouping) {
					closedGroups = m.ClosedGroups;
				}
			})
		}

		torrentsColorType = Array(movies.length);
		movies.forEach((group, i) => {
			let groupId = group.GroupId;
			torrentsColorType[i] = {
				"seeding": 0,
				"leeching": 0,
				"downloaded": 0,
				"snatched": 0,
				"count": 0
			}
			group.GroupingQualities.forEach(qualities => {
				qualities.Torrents.forEach(torrent => {
					if (!torrent.ColorType) {
						let rnd = Math.random();
						if (rnd >= boostStats) {
							return
						}
						let items = ["seeding", "leeching", "downloaded", "snatched"];
						torrent.ColorType = items[Math.floor(Math.random() * items.length)];
					}

					torrentsColorType[i][torrent.ColorType]++;
					torrentsColorType[i].count++;
					coloredTorrentsCount++;
				})
			})
		})
	}

	const highlightBackground = (e, i) => {
		if (!showHighlight) {
			return;
		}
		if (torrentsColorType[i].seeding) {
			e.forEach(t => {
				t.classList.add("seeding");
			});
		} else if (torrentsColorType[i].leeching) {
			e.forEach(t => {
				t.classList.add("leeching");
			});
		} else if (torrentsColorType[i].downloaded) {
			e.forEach(t => {
				t.classList.add("downloaded");
			});
		} else if (torrentsColorType[i].snatched) {
			e.forEach(t => {
				t.classList.add("snatched");
			});
		}
	}

	const addBadges = (e, torrentColors, target, position, margins) => {
		if (!showBadges) {
			return;
		}
		let div = document.createElement('div');
		div.className = `badges ${position}`;
		div.style.margin = margins;
		if (torrentColors.seeding && (!e.classList.contains("seeding") || torrentColors.seeding > 1)) {
			let s = document.createElement('span');
			s.textContent = torrentColors.seeding;
			grouping && showBadgeCounts ? s.textContent = torrentColors.seeding : s.innerHTML = "&nbsp;";
			s.className = "badge seeding";
			s.title = `Seeding ${torrentColors.seeding} torrent${torrentColors.seeding % 10 !==1 ? "s": ""}`;
			div.appendChild(s);
		}
		if (torrentColors.leeching && (!e.classList.contains("leeching") || torrentColors.leeching > 1)) {
			let s = document.createElement('span');
			s.textContent = torrentColors.leeching;
			grouping && showBadgeCounts ? s.textContent = torrentColors.leeching : s.innerHTML = "&nbsp;";
			s.title = `Leeching ${torrentColors.leeching} torrent${torrentColors.leeching % 10 !==1 ? "s": ""}`;
			s.className = "badge leeching";
			div.appendChild(s);
		}
		if (torrentColors.downloaded && (!e.classList.contains("downloaded") || torrentColors.downloaded > 1)) {
			let s = document.createElement('span');
			s.textContent = torrentColors.downloaded;
			grouping && showBadgeCounts ? s.textContent = torrentColors.downloaded : s.innerHTML = "&nbsp;";
			s.title = `Downloaded ${torrentColors.downloaded} torrent${torrentColors.downloaded % 10 !==1 ? "s": ""}`;
			s.className = "badge downloaded";
			div.appendChild(s);
		}
		if (torrentColors.snatched && (!e.classList.contains("snatched") || torrentColors.snatched > 1)) {
			let s = document.createElement('span');
			s.textContent = torrentColors.snatched;
			grouping && showBadgeCounts ? s.textContent = torrentColors.snatched : s.innerHTML = "&nbsp;";
			s.title = `Snatched ${torrentColors.snatched} torrent${torrentColors.snatched % 10 !==1 ? "s": ""}`;
			s.className = "badge snatched";
			div.appendChild(s);
		}

		target.appendChild(div);
	}

	const main = () => {
		getTorrentsColorType();
		if (!coloredTorrentsCount) {
			return;
		}

		let covers = '',
			smallCovers = '',
			huge = '',
			list = '',
			compactList = '',
			releaseName = '';
		if (window.location.pathname === '/torrents.php') {
			covers = document.querySelectorAll("div:not(.hidden) > div > div > .cover-movie-list__movie__cover-link")
			huge = document.querySelectorAll("div:not(.hidden) > .huge-movie-list__movie");
			list = document.querySelectorAll(".basic-movie-list:not(.hidden) .basic-movie-list__details-row:not(.compact-movie-list__details-row)");
			compactList = document.querySelectorAll(".basic-movie-list:not(.hidden) .basic-movie-list__details-row.compact-movie-list__details-row");
			releaseName = document.querySelectorAll(".basic-movie-list:not(.hidden) .release-name-movie-list__details-row");
		} else if (window.location.pathname === '/collages.php' || window.location.pathname === '/bookmarks.php' || window.location.pathname === '/user.php') {
			covers = document.querySelectorAll(".cover-movie-list__container:not(.hidden) .cover-movie-list__movie__cover-link");
			smallCovers = document.querySelectorAll(".small-cover-movie-list__container:not(.hidden) .small-cover-movie-list__movie__link");
			huge = document.querySelectorAll(".js-huge_view_container:not(.hidden) .huge-movie-list__movie");
			list = document.querySelectorAll(".basic-movie-list:not(.hidden) .basic-movie-list__details-row:not(.compact-movie-list__details-row)");
			compactList = document.querySelectorAll(".basic-movie-list:not(.hidden) .basic-movie-list__details-row.compact-movie-list__details-row");
		} else if (window.location.pathname === '/artist.php') {
			covers = document.querySelectorAll("[id^='role_']:not(.hidden) .cover-movie-list__container:not(.hidden) .cover-movie-list__movie__cover-link");
			smallCovers = document.querySelectorAll("[id^='role_']:not(.hidden) .small-cover-movie-list__container:not(.hidden) .small-cover-movie-list__movie__link");
			huge = document.querySelectorAll("[id^='role_']:not(.hidden) .js-huge_view_container:not(.hidden) .huge-movie-list__movie");
			list = document.querySelectorAll("[id^='role_']:not(.hidden) .basic-movie-list:not(.hidden) .basic-movie-list__details-row:not(.compact-movie-list__details-row)")
			compactList = document.querySelectorAll("[id^='role_']:not(.hidden) .basic-movie-list:not(.hidden) .basic-movie-list__details-row.compact-movie-list__details-row");
		} else if (window.location.pathname === '/top10.php') {
			covers = document.querySelectorAll(".cover-movie-list__container:not(.hidden) .cover-movie-list__movie__cover-link");
			huge = document.querySelectorAll(".js-huge_view_container:not(.hidden) .huge-movie-list__movie");
			list = document.querySelectorAll(".basic-movie-list:not(.hidden) .basic-movie-list__details-row:not(.compact-movie-list__details-row)")
			compactList = document.querySelectorAll(".basic-movie-list:not(.hidden) .basic-movie-list__details-row.compact-movie-list__details-row");
			releaseName = document.querySelectorAll(".release-name-movie-list__details-row");
		} else {
			console.log("nothing selected")
			return;
		}
		// console.log("covers:", covers.length, "small:", smallCovers.length, "huge:", huge.length, "list:", list.length, "compact:", compactList.length, "releases:", releaseName.length);

		if (covers.length) {
			for (let i = 0; i < torrentsColorType.length; i++) {
				if (torrentsColorType[i].count) {
					highlightBackground([covers[i], covers[i].nextElementSibling], i);
					showHighlight ? covers[i].classList.add("borders-top") : null;
					addBadges(covers[i], torrentsColorType[i], covers[i].parentElement, "top right", "4px 4px 0 0");
				}
			}
		} else if (smallCovers.length) {
			for (let i = 0; i < torrentsColorType.length; i++) {
				if (torrentsColorType[i].count) {
					highlightBackground([smallCovers[i]], i);
					showHighlight ? smallCovers[i].classList.add("borders") : null;
					addBadges(smallCovers[i], torrentsColorType[i], smallCovers[i].parentElement, "top right", "6px 6px 0 0");
				}
			}
		} else if (huge.length) {
			for (let i = 0; i < torrentsColorType.length; i++) {
				if (torrentsColorType[i].count) {
					highlightBackground([huge[i]], i);
					let target = badgesOnHugeCover ? huge[i].firstChild : huge[i];
					let position = badgesOnHugeCover ? "top left" : "top right";
					let margins = badgesOnHugeCover ? "4px" : "0";
					addBadges(huge[i], torrentsColorType[i], target, position, margins);
				}
			}
		} else if (list.length) {
			for (let i = 0; i < torrentsColorType.length; i++) {
				if (torrentsColorType[i].count) {
					highlightBackground([list[i]], i);

					if (window.location.pathname === '/artist.php' /*|| window.location.pathname === '/bookmarks.php'*/ ) {
						addBadges(list[i], torrentsColorType[i], list[i].children[1], "bottom right", "0 4px 6px 0");
					} else {
						addBadges(list[i], torrentsColorType[i], list[i].children[1], "top right", "5px 60px 0 0");
					}
				}
			}
		} else if (compactList.length) {
			for (let i = 0; i < torrentsColorType.length; i++) {
				if (torrentsColorType[i].count) {
					highlightBackground([compactList[i]], i);

					let margins = "5px 10px 0 0";
					let target = compactList[i].children[0];
					if (window.location.pathname === '/torrents.php') {
						!grouping ? margins = margins = "5px 35px 0 0" : null;
					}

					if (window.location.pathname === '/top10.php') {
						target = compactList[i].children[1];
					}

					addBadges(compactList[i], torrentsColorType[i], target, "top right", margins);
				}
			}
		} else if (releaseName.length) {
			for (let i = 0; i < torrentsColorType.length; i++) {
				if (torrentsColorType[i].count) {
					highlightBackground([releaseName[i]], i);
					addBadges(releaseName[i], torrentsColorType[i], releaseName[i].children[1], "top right", "5px 60px 0 0");
				}
			}
		}
	}

	let oldSetLocalStorageItem = unsafeWindow.SetLocalStorageItem;

	unsafeWindow.SetLocalStorageItem = (key, value) => {
		oldSetLocalStorageItem(key, value);
		main();
	}

	if (window.location.pathname === '/collages.php' || window.location.pathname === '/bookmarks.php') {
		let oldCollectionOrBookmarksPageSetViewMode = unsafeWindow.CollectionOrBookmarksPageSetViewMode;
		unsafeWindow.CollectionOrBookmarksPageSetViewMode = (movieViewManager, viewName) => {
			oldCollectionOrBookmarksPageSetViewMode(movieViewManager, viewName);
			main();
		}
	}

	if (window.location.pathname === '/top10.php' && window.location.search.match('type=movies_snatched_archive')) {
		let oldSetViewMode = unsafeWindow.SetViewMode;
		unsafeWindow.SetViewMode = (movieViewManager, viewName) => {
			oldSetViewMode(movieViewManager, viewName);
			main();
		}
	}

	main();
})()