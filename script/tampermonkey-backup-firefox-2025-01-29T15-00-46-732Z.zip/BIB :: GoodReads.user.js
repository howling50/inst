// ==UserScript==
// @name            BIB :: GoodReads
// @version         1.25
// @description     GoodReads Search, Request and Upload
// @grant           GM_deleteValue
// @grant           GM_getValue
// @grant           GM_setValue
// @grant           GM_xmlhttpRequest
// @grant           GM.deleteValue
// @grant           GM.getValue
// @grant           GM.setValue
// @grant           GM.xmlHttpRequest
// @include         http*://www.goodreads.com/book/show/*
// @include         http*://www.goodreads.com/list/show/*
// @include         http*://www.goodreads.com/search*
// @include         http*://www.goodreads.com/author/show/*
// @include         http*://www.goodreads.com/author/list/*
// @include         http*://www.goodreads.com/series/*
// @include         http*://bibliotik.me/requests/create/ebooks*
// @include         http*://bibliotik.me/upload/ebooks*
// @include         http*://redacted.ch/upload.php
// @include         http*://brokenstones.club/upload.php
// @require         https://greasemonkey.github.io/gm4-polyfill/gm4-polyfill.js
// @require         https://ajax.googleapis.com/ajax/libs/jquery/2.2.2/jquery.min.js
// ==/UserScript==
// @include         http*://www.goodreads.com/author/list/*

/********** Changelog **********
 *
 * Version 1.25
 *
 * - Update for new GoodReads
 *
 * Version 1.24
 *
 * - Fix a bug where not displaying links for some series books
 *
 * Version 1.23
 *
 * - Added functionality for Goodreads Series page
 * - Fixed ISBN display when undefined
 *
 * Version 1.22
 *
 * - Added functionality for Author's page books
 * - Added functionality for all Author's books
 *
 * Version 1.21
 *
 * - Added fuzzy search for BiB Search and Request
 * - Added functionality for book series list
 *
 * Version 1.2
 *
 * - Updated book-info finding functions to work for new Beta UI
 * - Added bib search for Goodreads lists
 * - Added &retail=retail for bib search
 * - Fixed a bug where the extension was not working on some pages
 * - Fixed compatibility for both TamperMonkey and ViolentMonkey
 * - Added functionality for Goodreads search page
 * - Refactored some functions with improved comments
 *
******************************/

// this.$ = this.jQuery = jQuery.noConflict(true);

const uploadRED = false;
const uploadBS = false;
const simpleToolbar = false;

let authors = [];
let contributors = [];
let editors = [];
let translators = [];

const debug = false;

const windowHostname = window.location.hostname;
const windowLocation = window.location.toString();

let decodeEntities = (function () {
    // this prevents any overhead from creating the object each time
    let element = document.createElement("div");

    // regular expression matching HTML entities
    let entity = /&(?:#x[a-f0-9]+|#\d+|[a-z0-9]+);?/ig;

    return function decodeHTMLEntities(str) {
        // find and replace all the html entities
        str = str.replace(entity, function (m) {
            element.innerHTML = m;
            return element.textContent;
        });

        // reset the value
        element.textContent = "";

        return str;
    };
}());

function addToolbar() {
    let title = getMainTitle();

    let mainAuthor = $(".ContributorLink:first").text();
    console.log("Main Author: " + mainAuthor);

    let isbnString;
    let isbn = $("div.DescListItem:contains('ISBN')");

    // TODO, no ISBN or ASIN
    if (isbn.length) {
        isbn = isbn.text().match(/\d{13}/)[0];
        isbnString = "ISBN";
    } else {
        isbn = $("div.infoBoxRowTitle:contains(\"ASIN\")");
        if (isbn.length) {
            isbn = isbn.next().text();
            isbnString = "ASIN";
        }
    }

    let toolbar = "<span id=\"bibtoolbar\" style=\"color:#aaaaaa\"> ";
    if (simpleToolbar === false) {
        toolbar += "<br/>Bibliotik:" +
            " <a class=\"bib\" href=\"" + "https://bibliotik.me/requests/create/ebooks\" target=\"_blank\">Request</a>" +
            " <a class=\"bib\" href=\"https://bibliotik.me/upload/ebooks\" target=\"_blank\">Upload" + "</a>" +
            "<br/>Search:" +
            " <a id=\"toolbar_searchtitle\" href=\"" + searchBibliotik(title, mainAuthor) + "\" target=\"_blank\">Title</a>" +
            " <a href=\"" + searchBibliotikAuthor(mainAuthor) + "\" target=\"_blank\">Author</a>" +
            " <a href=\"" + searchBibliotikRequest(title, mainAuthor) + "\" target=\"_blank\">Requests</a>" +
            "<br/>" +
            "Amazon <a href=\"" + searchAmazon(title, mainAuthor) + "\" target=\"_blank\">Title</a> " +
            " <a href=\"" + searchAmazonAuthor(mainAuthor) + "\" target=\"_blank\">Author</a>";
        if (isbnString !== undefined) {
            toolbar += " <a href=\"" + searchAmazon(isbn) + "\" target=\"_blank\">" + isbnString + "</a>";
        }
        toolbar += "<br/><a href=\"" + searchBN(title, mainAuthor) + "\" target=\"_blank\">BN</a>" +
            " | <a href=\"" + searchOverDrive(title, mainAuthor) + "\" target=\"_blank\">OverDrive</a>" +
            " | <a href=\"" + searchWorldCat(title, mainAuthor) + "\" target=\"_blank\">WorldCat</a>";
        if (uploadBS) {
            toolbar += "<br/>BrokenStones: " +
                " <a target=\"_blank\" href=\"" + searchBS(mainAuthor, title) + "\">Title</a>" +
                " <a target=\"_blank\" href=\"" + searchBS(mainAuthor) + "\">Author</a>" +
                " | <a target=\"_blank\" class=\"bs\" href=\"https://brokenstones.club/upload.php\">Upload</a><br/>";
        }
        if (uploadRED) {
            toolbar += "<br/>redacted.ch: " +
                " <a target=\"_blank\" href=\"" + searchRED(mainAuthor, title) + "\">Title</a>" +
                " <a target=\"_blank\" href=\"" + searchRED(mainAuthor) + "\">Author</a>" +
                " | <a target=\"_blank\" class=\"red\" href=\"https://redacted.ch/upload.php\">Upload</a><br/>";
        }
    } else {
        toolbar += "<a href=\"" + searchAmazon(title, mainAuthor) + "\" target=\"_blank\">Amazon</a> " +
            " <a href=\"" + searchAmazon(isbn) + "\" target=\"_blank\">ISBN</a>" +
            " | <a href=\"" + searchOverDrive(title, mainAuthor) + "\" target=\"_blank\">OD</a>" +
            " | Bib: " +
            " <a class=\"bib\" href=\"" + "https://bibliotik.me/requests/create/ebooks\" target=\"_blank\">Request</a>" +
            " <a href=\"" + searchBibliotik(title, mainAuthor) + "\" target=\"_blank\">Search</a>" +
            " <a class=\"bib\" href=\"https://bibliotik.me/upload/ebooks\" target=\"_blank\">Upload" + "</a>";
    }
    toolbar += "</span>";
    $(".BookActions").prepend(toolbar);
}

function fixAuthor(author) {
    return author.replace("Dr. ", "")
        .replace("Dr ", "")
        .replace(", MD", "")
        .replace(", Ph.D.", "")
        .replace(", Phd.", "")
        .replace(" Ph.D.", "")
        .replace(" USA Inc.", "")
        .replace(" DDS", "")
        .replace(" MBA", "")
        .replace(" MD", "")
        .replace(" ODD", "")
        .replace(" PhD", "");
}

function fixAuthors(authors) {
    authors = $.map(authors, function (author) {
        return author.replace("Dr. ", "")
            .replace("Dr ", "")
            .replace(", MD", "")
            .replace(", Ph.D.", "")
            .replace(", Phd.", "")
            .replace(" Ph.D.", "")
            .replace(" USA Inc.", "")
            .replace(" DDS", "")
            .replace(" MBA", "")
            .replace(" MD", "")
            .replace(" ODD", "")
            .replace(" PhD", "");
    });
    return authors;
}

function fixDescription(description) {
    description = description
        .replace(/ style="user-select: auto;"/g, "")
        .replace(/<[^/>][^>]*>\s*<\/[^>]+>/g, "")
        .replace(/<div>\s*<p>/gi, "")
        .replace(/<\/div>/gi, "")
        .replace(/<p>(.*?)<\/p>/g, "\n\n$1")
        .replace(/<span class="h\d+">(.*?)<\/span>/g, "\n$1")
        .replace(/<ul>\s*<li>/gi, "\n\n• ")
        .replace(/<\/li>\s*<li>/gi, "\n• ")
        .replace(/<\/li>\s*<\/ul>/gi, "\n")
        .replace(/<ul>(.*?)<\/ul>/g, "\n$1")
        .replace(/<ul>\s*/g, "")
        .replace(/<li>/gi, "\n• ")
        .replace(/<\/p>\s*<p>/gi, "\n\n")
        .replace(/<\/p>/gi, "")
        .replace(/<p\/>/gi, "")
        .replace(/<\/p><br> <br><p>/gi, "\n\n")
        .replace(/<i>\s*<\/i>/gi, "")
        .replace(/<b><\/b>/gi, "")
        .replace(/<\/b>\s*<b>/gi, "")
        .replace(/<em>\s*<\/em>/gi, "")
        .replace(/<br>/gi, "\n")
        .replace(/<br style="-webkit-user-select: auto;">/gi, "\n")
        .replace(/<br\/>/gi, "\n")
        .replace(/<p>/gi, "\n")
        .replace(/<div>/gi, "")
        .replace(/<blockquote>/gi, "")
        .replace(/<\/blockquote>/gi, "")
        .replace(/<br\s\/>/gi, "\n")
        .replace(/<i> /gi, " [i]")
        .replace(/<i>/gi, "[i]")
        .replace(/,<\/i>/gi, "[/i],")
        .replace(/ <\/i>/gi, "[/i] ")
        .replace(/<\/i>/gi, "[/i]")
        .replace(/<b> /gi, " [b]")
        .replace(/<b>/gi, "[b]")
        .replace(/ <\/b>/gi, "[/b] ")
        .replace(/<\/b>/gi, "[/b]")
        .replace(/<strong>/gi, "[b]")
        .replace(/<\/strong>/gi, "[/b]")
        .replace(/<em>/gi, "[i]")
        .replace(/<\/em>/gi, "[/i]")
        .replace(/\n\s*\n/gim, "\n\n")
        .replace(/\n\s*\n\s*\n/gim, "\n\n")
        .trim();
    // empty tags
    description = decodeEntities(description);
    return description;
}

function getAuthors() {
    // reset arrays
    authors.length = 0;
    editors.length = 0;
    contributors.length = 0;
    translators.length = 0;

    $(".ContributorLinksList").find("a.ContributorLink").filter(function () {
        let currentAuthor = $(this).find("span.ContributorLink__name").text();
        let role = "";

        if ($(this).find("span.ContributorLink__role")) {
            role = $(this).find("span.ContributorLink__role").text();
            console.log("Author each: " + currentAuthor + " " + role);
        } else {
            console.log("Author each: " + currentAuthor);
        }

        if (role) {
            if (role.indexOf("ditor") >= 0) {
                editors.push(currentAuthor);
                return false;
            }
            if (role.toLowerCase().indexOf("trans") >= 0) {
                translators.push(currentAuthor);
                return false;
            }
            contributors.push(currentAuthor);
            return false;
        } else {
            authors.push(currentAuthor);
        }
    });

    authors = fixAuthors(authors);
    editors = fixAuthors(editors);
    contributors = fixAuthors(contributors);
    translators = fixAuthors(translators);
    console.log("Authors: " + authors.join(", "));
    console.log("Editors: " + editors.join(", "));
    console.log("Contributors: " + contributors.join(", "));
    console.log("Translators: " + translators.join(", "));
}

function getISBN13() {
    let isbns = [];
    let isbnsfound = $(".DescListItem").text().match(/ISBN (\d+)/g);
    if (isbnsfound) {
        isbns = isbnsfound.toString().replace(/ISBN/g, "").split(",");
    }

    let isbn = $(".greyText:contains(\"ISBN\")");

    if (isbn.length) {
        isbn = isbn.text().match(/\d{13}/);
        isbns.push(isbn.toString());
    } else {
        isbn = $("div.infoBoxRowTitle:contains(\"ISBN\")");
        if (isbn.length) {
            isbn = isbn.next().text();
            isbns.push(isbn.toString());
        }
    }
    console.log("ISBN13s found: " + isbns.length);
    return isbns;
}

function getMainTitle() {
    let title = $(".Text.Text__title1").text();
    if (title.indexOf("(") >= 0) {
        title = title.substr(0, title.indexOf("("));
    }
    if (title.indexOf(":") >= 0) {
        title = title.substr(0, title.indexOf(":"));
    }
    return $.trim(title);
}

function getPublisher() {
    let publisher = $("div.DescListItem:contains('Published'), div.row:contains('Expected publication:')").text();
    if (publisher.indexOf(" by ") >= 0) {
        publisher = publisher.split(" by ").pop();
        if (publisher.indexOf("(") >= 0) {
            publisher = publisher.split(" (")[0];
        }
        publisher = publisher
            .replace(", Inc.", "")
            .replace(", UK", "")
            .replace(", USA", "");
        publisher = $.trim(publisher);
        return publisher;
    } else {
        return "";
    }
}

function getBookInfo(save) {
    let title = $.trim($("h1.Text.Text__title1").text());
    title = title.replace(/\s\s+/g, " ").trim(); // trim multiple spaces

    let series = $(".BookPageTitleSection__title").find(".Text__subdued");
    if (series.length) {
        let seriesText = series.text().trim().replace(/ #(\d+)$/g, ", Book $1");
        title = title + " (" + seriesText + ")";
        title = title.trim();
    }

    console.log("Title: " + title);

    getAuthors();

    let description = $(".DetailsLayoutRightParagraph__widthConstrained").find(".Formatted").html(); // .readable.stacked
    if (description) {
        description = fixDescription(description);
    } else {
        description = "";
    }
    console.log(description);

    let isbn = $("div.DescListItem:contains('ISBN')");
    if (isbn.length) {
        isbn = isbn.text().match(/\d{13}/)[0];
    } else {
        isbn = "";
    }

    console.log("ISBN: " + isbn);

    let publisher = getPublisher();
    console.log("Publisher: " + publisher);

    let year = $("div.DescListItem:contains(\"Published\")");
    if (year.length) {
        year = year.text().match(/\d{4}/)[0];
    } else {
        year = "";
    }
    console.log("Year: " + year);

    let pages = $("p[data-testid*=pagesFormat]").text();
    if (pages) {
        pages = pages.match(/\d+/)[0];
    } else {
        pages = "";
    }
    console.log("Pages: " + pages);

    let imageURL = $(".BookCover__image").find(".ResponsiveImage");
    if (imageURL.length) {
        imageURL = imageURL.attr("src");
    } else {
        imageURL = "";
    }
    console.log("Image: " + imageURL);

    if (save) {
        if (authors.length > 0) {
            GM.setValue("grAuthors", authors.join(", "));
        } else {
            GM.setValue("grAuthors", "[none]");
        }

        GM.setValue("grEditors", editors.join(", "));
        GM.setValue("grContributors", contributors.join(", "));
        GM.setValue("grTranslators", translators.join(", "));
        GM.setValue("grTitle", title);
        GM.setValue("grPublisher", publisher);
        GM.setValue("grYear", year);
        GM.setValue("grPages", pages);
        GM.setValue("grISBN", isbn);
        GM.setValue("grImage", imageURL);
        GM.setValue("grDescription", description);
        GM.setValue("grLink", windowLocation.split("?")[0]);

        let tags = $("a.actionLinkLite:contains(\"Non Fiction\")").length;
        if (tags === "1") {
            GM.setValue("grTags", "nonfiction, ");
        } else {
            tags = $("a.actionLinkLite:contains(\"Fiction\")").length;
            if (tags === 1) {
                GM.setValue("grTags", "fiction, ");
            }
        }

    }
}

function kindleLink() {
    let kindle = $("span:contains(\"Kindle Edition\")");
    if (kindle.length < 1) {
        $(".otherEditionCovers").find("a").each(function () {
            $.get($(this).attr("href"), function (data) {
                let kindle = $("span:contains(\"Kindle Edition\")", data);
                if (kindle.length) {
                    let asin = $(".infoBoxRowTitle:contains(\"ASIN\")", data).next().text();
                    asin = "https://www.amazon.com/dp/" + asin;
                    $("#buyButton:contains(\"Amazon\")").parent()
                        .after("<li><a class=\"buttonBar\" href=\"" + asin + "\" target=\"_blank\">Kindle</a></li>");
                }
            });
        });
    }
}

function mainTitleText(title) {
    "use strict";
    let titleText = title.replace(new RegExp(", \\d+th Edition", ""), "").replace(new RegExp(" (\\d+th Edition)", ""), "");

    if (titleText.indexOf("(") >= 0) {
        titleText = titleText.substr(0, titleText.indexOf(" ("));
    }
    if (titleText.indexOf("[") >= 0) {
        titleText = titleText.substr(0, titleText.indexOf(" ["));
    }
    if (titleText.indexOf(":") >= 0) {
        titleText = titleText.substr(0, titleText.indexOf(":"));
    }
    if (titleText.indexOf(" - ") >= 0) {
        titleText = titleText.substr(0, titleText.indexOf(" - "));
    }
    titleText = titleText.replace(new RegExp(":", ""), " ");
    return titleText;
}

function printInfo() {
    if (debug) {
        let results = "";

        if (authors.length > 0) {
            results += "<br/>Authors: " + authors.join(", ");
        }
        if (editors.length > 0) {
            results += "<br/>Editors: " + editors.join(", ");
        }
        if (contributors.length > 0) {
            results += "<br/>Contributors: " + contributors.join(", ");
        }
        if (translators.length > 0) {
            results += "<br/>Translators: " + translators.join(", ");
        }
        results += "<br/>Time: " + String(infoTime.toPrecision(5));
        $("#bibtoolbar").append(results);
    }
}

function searchResults() {
    $("table.tableList").find("tr").each(function () {
        let title = mainTitleText($(this).find("a.bookTitle").text().trim());
        let author = $(this).find("a.authorName:first").text();

        let toolbar = $(this).find("td").eq(1);
        let toolbarText = searchToolbar(title, author);
        toolbar.append(toolbarText);
    });
}

function searchToolbar(title, author) {
    return "<div class='bibGrid'>" +
        "<br/>Bibliotik: " +
        "<a target='_blank' href='" + searchBibliotik(title, author) + "'>Title</a>" +
        " <a target='_blank' href='" + searchBibliotikAuthor(author) + "'>Author</a>" +
        " <a target='_blank' href='" + searchBibliotikRequest(title, author) + "'>Requests</a>" +
        " Search: " +
        "<a target='_blank' href='" + searchAmazon(title, author) + "'>Amazon</a>" +
        " <a target='_blank' href='" + searchBN(title, author) + "'>B&N</a>" +
        " <a target='_blank' href='" + searchWorldCat(title, author) + "'>WorldCat</a>" +
        "</div>";

}

function requestFormat(formatCode, value) {
    $("input[name=\"FormatsField[]\"][value=\"" + formatCode + "\"]")
        .prop("checked", value);
}

function createRequest() {
    Promise.all([
        GM.getValue("grTitle"),
        GM.getValue("grAuthors"),
        GM.getValue("grEditors"),
        GM.getValue("grContributors", false),
        GM.getValue("grTranslators", false),
        GM.getValue("grPublisher"),
        GM.getValue("grDescription"),
        GM.getValue("grTags")
    ]).then(function (vals) {
        if (typeof vals[0] !== "undefined") {
            console.log("GoodReads request.");

            $("#TitleField").val(vals[0]);
            if (vals[1] !== "[none]") {
                $("#AuthorsField").val(vals[1]);
            }
            $("#EditorsField").val(vals[2]);
            $("#ContributorsField").val(vals[3]);
            $("#TranslatorsField").val(vals[4]);
            $("#PublishersField").val(vals[5]);
            $("#NotesField").val(vals[6]);
            unsafeWindow.$("#NotesField").change();
            $("#TagsField").val(vals[7]);

            requestFormat(15, true); // EPUB
            // requestFormat(16, false); // MOBI
            // requestFormat(21, false); // AZW3

            if (vals[3] || vals[4]) {
                $("#toggle")[0].click();
            }

            //$("#TagsField").focus();
            $("#FormatsField1").focus();

            GM.deleteValue("grTitle");
            GM.deleteValue("grAuthors");
            GM.deleteValue("grContributors");
            GM.deleteValue("grEditors");
            GM.deleteValue("grTranslators");
            GM.deleteValue("grTags");
            GM.deleteValue("grPublisher");
            GM.deleteValue("grYear");
            GM.deleteValue("grPages");
            GM.deleteValue("grISBN");
            GM.deleteValue("grImage");
            GM.deleteValue("grDescription");
        }
    });
}

function createUpload() {
    Promise.all([
        GM.getValue("grTitle"),
        GM.getValue("grAuthors"),
        GM.getValue("grEditors"),
        GM.getValue("grContributors", false),
        GM.getValue("grTranslators", false),
        GM.getValue("grPublisher"),
        GM.getValue("grYear"),
        GM.getValue("grPages"),
        GM.getValue("grISBN"),
        GM.getValue("grImage", ""),
        GM.getValue("grDescription"),
        GM.getValue("grTags")
    ]).then(function (vals) {
        if (typeof vals[0] !== "undefined") {
            console.log("GoodReads upload.");
            if (debug) {
                $("fieldset").after("<br/>GoodReads upload.");
            }
            $("#TitleField").val(vals[0]);
            if (vals[1] !== "[none]") {
                $("#AuthorsField").val(vals[1]);
            }
            $("#EditorsField").val(vals[2]);
            $("#ContributorsField").val(vals[3]);
            $("#TranslatorsField").val(vals[4]);
            $("#PublishersField").val(vals[5]);
            $("#YearField").val(vals[6]);
            $("#PagesField").val(vals[7]);
            $("#IsbnField").val(vals[8]);
            $("#ImageField").val(vals[9]);
            $("#DescriptionField").val(vals[10]);
            unsafeWindow.$("#DescriptionField").change();
            $("#TagsField").val(vals[11]);

            if (vals[4] || vals[3]) {
                $("#toggle")[0].click();
            }

            $("#FormatField").focus();

            resetValues();
        }
    });
}

function createUploadBS() {
    "use strict";
    console.log("BrokenStones upload.");

    Promise.all([
        GM.getValue("grTitle"),
        GM.getValue("grAuthors", false),
        GM.getValue("grImage"),
        GM.getValue("grISBN"),
        GM.getValue("grPublisher"),
        GM.getValue("grDescription"),
        GM.getValue("grPages"),
        GM.getValue("grYear"),
        GM.getValue("grLink"),
    ]).then(function (vals) {
        if (GM_getValue("grAuthors", false)) {

            $("#categories").val(7);
            // unsafeWindow.Categories();

            let delay = 1000; //1 seconds

            setTimeout(function () {
                $("#title").val(GM_getValue("grTitle") + " - " + GM_getValue("grAuthors"));

                let description = "Author: " + GM_getValue("grAuthors") + "\n" +
                    "Year: " + GM_getValue("grYear") + "\n" +
                    "Edition: " + "\n" +
                    "ISBN: " + GM_getValue("grISBN") + "\n" +
                    "Pages: " + GM_getValue("grPages") + "\n" +
                    "Link: " + GM_getValue("grLink") + "\n" +
                    GM_getValue("grImage") + "\n\n" +
                    GM_getValue("grDescription");

                $("#desc").val(description);

                $("#tags").val("ebook");
                resetValues();
            }, delay);

            console.log("Amazon upload.");
        }
    });
}

function createUploadRED() {
    if (GM.getValue("grTitle", false)) {

        $("#categories").val(2);
        unsafeWindow.Categories();

        let delay = 1000; //1 seconds

        setTimeout(function () {
            $("#title").val(GM.getValue("grAuthors") + " - " + GM.getValue("grTitle"));
            $("#image").val(GM.getValue("grImage"));
            $("#desc").val(GM.getValue("grDescription"));

            GM.deleteValue("grTitle");
            GM.deleteValue("grAuthors");
        }, delay);

        console.log("GoodReads upload.");
    }
}

function resetValues() {
    GM.deleteValue("grTitle");
    GM.deleteValue("grAuthors");
    GM.deleteValue("grContributors");
    GM.deleteValue("grEditors");
    GM.deleteValue("grTranslators");
    GM.deleteValue("grPublisher");
    GM.deleteValue("grYear");
    GM.deleteValue("grTags");
    GM.deleteValue("grPages");
    GM.deleteValue("grISBN");
    GM.deleteValue("grImage");
    GM.deleteValue("grDescription");
    GM.deleteValue("grLink");
}

function quoteWords(word) {
    return encodeURIComponent(word.replace(/((?=\S*[!'-])([a-zA-Z'!-]+))/, "\"$1\""));
}

function searchAmazon(title, author) {
    if (author) {
        return "https://www.amazon.com/s?ie=UTF8&index=blended&keywords=" + encodeURIComponent(title) + " " + author;
    } else {
        if (/^B\d{2}\w{7}/.test(title)) {
            return "https://www.amazon.com/dp/" + encodeURIComponent(title);
        } else {
            return "https://www.amazon.com/s?ie=UTF8&index=blended&keywords=" + title;
        }
    }
}

function searchAmazonAuthor(author) {
    return "https://www.amazon.com/gp/search/ref=sr_adv_b/?search-alias=stripbooks&unfiltered=1&sort=relevanceexprank&Adv-Srch-Books-Submit.x=0&Adv-Srch-Books-Submit.y=0&field-author=" + author;
}

function searchBN(title, author) {
    return "https://www.barnesandnoble.com/s/" + encodeURIComponent(title) + " " + author;
}

function searchBibliotik(title, author) {
    if (author.length) {
        author = fixAuthor(author);
        author = author.replace(/ [A-Z]\. /, " ");
        return "https://bibliotik.me/torrents/?orderby=added&order=desc&search=" + quoteWords(title) +
            " @creators " + quoteWords(author);
    } else {
        return "https://bibliotik.me/torrents/?orderby=added&order=desc&search=" + quoteWords(title);
    }
}

function searchBibliotikAuthor(author) {
    author = fixAuthor(author);
    author = author.replace(/ [A-Z]\. /, " ");
    return "https://bibliotik.me/torrents/?orderby=added&order=desc&search=" + "@creators " + quoteWords(author);
}

function searchBibliotikRequest(title, author) {
    if (author.length) {
        author = fixAuthor(author);
        author = author.replace(/ [A-Z]\. /, " ");
        return "https://bibliotik.me/requests/?orderby=added&order=desc&search=" + quoteWords(title) +
            " @creators " + quoteWords(author);
    } else {
        return "https://bibliotik.me/requests/?orderby=added&order=desc&search=" + quoteWords(title);
    }
}

function searchBS(author, title) {
    if (typeof title !== "undefined") {
        return "https://brokenstones.is/torrents.php?order_by=weight&order_way=desc&filter_cat%5B8%5D=1&action=basic&searchsubmit=1&searchstr=" +
            quoteWords(author) + " " + quoteWords(title);
    } else {
        author = author.replace(/ [A-Z]\. /, " ");
        return "https://brokenstones.club/torrents.php?order_by=weight&order_way=desc&filter_cat%5B8%5D=1&action=basic&searchsubmit=1&searchstr=" +
            quoteWords(author);
    }
}

function searchOverDrive(title, author) {
    return "https://www.overdrive.com/search?&autoLibrary=f&autoRegion=t&showAvailable=False&q=" +
        encodeURIComponent(title) + " " + author;
}

function searchRED(author, title) {
    if (typeof title !== "undefined") {
        return "https://redacted.ch/torrents.php?order_by=time&order_way=desc&filter_cat%5B3%5D=1&action=basic&searchsubmit=1&searchstr=" +
            quoteWords(author) + " " + quoteWords(title);
    } else {
        author = author.replace(/ [A-Z]\. /, " ");
        return "https://redacted.ch/torrents.php?order_by=time&order_way=desc&filter_cat%5B3%5D=1&action=basic&searchsubmit=1&searchstr=" +
            quoteWords(author);
    }
}

function searchWorldCat(title, author) {
    return "https://www.worldcat.org/search?q=ti%3A" + encodeURIComponent(title) + "+au%3A" + author + "&qt=advanced";
}

if (windowLocation.indexOf("goodreads.com/book/show") > 0) {
    addToolbar();
    $(document.body).on("click", ".bib", {save: true}, getBookInfo);
    $(document.body).on("click", ".bs", {save: true}, getBookInfo);
    $(document.body).on("click", ".red", {save: true}, getBookInfo);

    if (debug) {
        getAuthors(); // for debug
        getBookInfo(false); // for debug
        //printInfo(); // for debug
    }
    kindleLink();
}

if (windowLocation.indexOf("goodreads.com/search") > 0) {
    searchResults();
}

if (windowLocation.indexOf("requests") > 0) {
    createRequest();
}

if (windowHostname === "bibliotik.me") {
    if (windowLocation.indexOf("upload") > 0) {
        createUpload();
    }
}

if (windowHostname === "brokenstones.club") {
    createUploadBS();
}

if (windowHostname === "redacted.ch") {
    createUploadRED();
}