// ==UserScript==
// @name         Subtitle Flags (BTN)
// @namespace    http://tampermonkey.net/
// @version      1.04
// @description  Adds subtitle flags to each torrent.
// @author       DrPepper
// @match        https://broadcasthe.net/torrents.php?id=*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    var languages = {
        'Albanian': 'albania',
        'Arabic': 'arableague',
        'Bengali': 'bangladesh',
        'Bulgarian': 'bulgaria',
        'Catalan': 'spain',
        'Czech': 'czechrep',
        'Chinese': 'china',
        'Croatian': 'croatia',
        'Danish': 'denmark',
        'Dutch': 'netherlands',
        'English': 'usa',
        'Estonian': 'estonia',
        'fil': 'philippines',
        'Finnish': 'finland',
        'French': 'france',
        'Galician': 'spain',
        'German': 'germany',
        'Greek': 'greece',
        'Hebrew': 'israel',
        'Hindi': 'india',
        'Hungarian': 'hungary',
        'Icelandic': 'iceland',
        'Indonesian': 'indonesia',
        'Italian': 'italy',
        'Japanese': 'japan',
        'Kannada': 'india',
        'Korean': 'southkorea',
        'Latvian': 'latvia',
        'Lithuanian': 'lithuania',
        'Malay': 'malaysia',
        'Malayalam': 'india',
        'Norwegian': 'norway',
        'Norwegian Bokmal': 'norway',
        'Persian': 'iran',
        'Polish': 'poland',
        'Portuguese': 'portugal',
        'Romanian': 'romania',
        'Russian': 'russia',
        'Serbian': 'serbia',
        'Slovak': 'slovakia',
        'Slovenian': 'slovenia',
        'Spanish': 'spain',
        'Swedish': 'sweden',
        'Tamil': 'srilanka',
        'Telugu': 'india',
        'Thai': 'thailand',
        'Turkish': 'turkey',
        'Ukrainian': 'ukraine',
        'Vietnamese': 'vietnam',
        'Welsh': 'wales'
    };

    var flagURL = 'https://cdn.broadcasthe.net/common/flag/';

    // Retrieve the table rows (tr) where the torrent info is displayed.
    let tInfoRows = document.querySelectorAll('tr.pad');

    for (let tInfoRow of tInfoRows) {
        // Retrieve the blockquote that contains the mediainfo.
        let bq = tInfoRow.querySelectorAll('blockquote')[1];

        // Split the mediainfo to where the subtitles' information begin.
        let subsInfo = bq.textContent.split(/\nText(?:\n| #1[^\d])/)[1];
        // console.log(subsInfo);

        // If no subtitles exist, then skip.
        if (!subsInfo) continue;

        // Get all lines that begin with 'Language'.
        let matchedLangs = subsInfo.match(/\nLanguage\s+:.*(\w+)/g);
        // console.log(matchedLangs);

        if (!matchedLangs) continue;

        // Create a set of all the languages found.
        let setOfLangs = new Set();
        for(let lang of matchedLangs) {
            setOfLangs.add(lang.split(':')[1].trim());
        }
        // console.log(setOfLangs);

        // Create HTML to display the flags.
        let tr = document.createElement('tr');
        let td = document.createElement('td');
        td.innerHTML = 'In Torrent: ';
        tr.appendChild(td);

        // Get the element where subtitles are displayed.
        let subsView = document.getElementById('subtitle_display_' + tInfoRow.id.split('_')[1]);

        // Insert the new table row.
        subsView.closest('tbody').insertBefore(tr, subsView.parentNode);
        subsView.innerHTML = 'External: ' + subsView.innerHTML;

        // Create img element and append it to the 'td' element along with some spacing.
        for (let lang of setOfLangs) {
            let img = document.createElement('img');
            img.title = lang;
            img.src = flagURL + languages[lang] + '.gif';
            td.appendChild(img);
            td.innerHTML += '&nbsp;';
        }
    }

})();