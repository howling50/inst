// ==UserScript==
// @name         Orpheus & Redacted: YAETS
// @author       commoner@orpheus.network
// @description  Yet Another External Tracker Searcher
// @version      v2023-07-23
// @match        https://orpheus.network/requests.php?id=*
// @match        https://orpheus.network/requests.php?*&id=*
// @match        https://orpheus.network/torrents.php?id=*
// @match        https://orpheus.network/torrents.php?*&id=*
// @match        https://orpheus.network/artist.php?id=*
// @match        https://orpheus.network/artist.php?*&id=*
// @match        https://*.orpheus.network/requests.php?id=*
// @match        https://*.orpheus.network/requests.php?*&id=*
// @match        https://*.orpheus.network/torrents.php?id=*
// @match        https://*.orpheus.network/torrents.php?*&id=*
// @match        https://*.orpheus.network/artist.php?id=*
// @match        https://*.orpheus.network/artist.php?*&id=*
// @match        https://redacted.sh/requests.php?id=*
// @match        https://redacted.sh/requests.php?*&id=*
// @match        https://redacted.sh/torrents.php?id=*
// @match        https://redacted.sh/torrents.php?*&id=*
// @match        https://redacted.sh/artist.php?id=*
// @match        https://redacted.sh/artist.php?*&id=*
// @match        https://www.deepbassnine.com/requests.php?id=*
// @match        https://www.deepbassnine.com/requests.php?*&id=*
// @match        https://www.deepbassnine.com/torrents.php?id=*
// @match        https://www.deepbassnine.com/torrents.php?*&id=*
// @match        https://www.deepbassnine.com/artist.php?id=*
// @match        https://www.deepbassnine.com/artist.php?*&id=*
// @match        https://animebytes.tv/artist.php?id=*
// @match        https://animebytes.tv/artist.php?*&id=*
// @match        https://animebytes.tv/torrents2.php?id=*
// @match        https://animebytes.tv/torrents2.php?*&id=*
// @match        https://animebytes.tv/requests.php?id=*
// @match        https://animebytes.tv/requests.php?*&id=*
// @grant        none
// @homepageURL  https://redacted.sh/forums.php?action=viewthread&threadid=61605
// @homepageURL  https://orpheus.network/forums.php?action=viewthread&threadid=16152
// ==/UserScript==

////////////////////////////////////////////////////////////////////////////////
// USER SETTINGS

// Uncomment site names to create links to search on.
const ENABLED = [
  'Redacted',
  'Orpheus',
  // 'DEEPBASSNiNE',
  // 'JPopsuki',
  // 'AnimeBytes',
  'RuTracker',
  // 'AppleMusic',
  // 'Bandcamp',
  // 'Deezer',
  // 'Qobuz',
  // 'Spotify (app)',
  // 'Spotify (web)',
  'MusicBrainz',
  'Discogs',
  'LastFM',
  // 'Wikipedia',
  // 'AllMusic',
  // 'Cover Search Engine',
  // 'YouTube',
  // 'Pitchfork',
  // 'Rate Your Music',
];

// When true, make text links show up in the linkbox underneat the page title.
// Default: false
const LINKBOX_ENABLED = false;

// If those text links make the header too wide to fit in your window and this
// is true, then the linkbox will flow onto multiple lines. Default: true
const REFLOW_LINKBOX = true;

// When true, show image links in the sidebar. Default: true
const SIDEBAR_ENABLED = true;

// Change this number to have a different number of icons per line in the
// sidebar. Default: 5
const SIDEBAR_ICONS_PER_LINE = 5;

// When true, go to the artist page when an artist name search yields an exact
// result on a Gazelle site. Default: true
const GAZELLE_STRAIGHT_TO_ARTIST_PAGE = true;

// When true, require exact artist name matches on Discogs (ie, no partial
// matches). Default: true
const DISCOGS_STRICT_ARTIST_SEARCH = true;



////////////////////////////////////////////////////////////////////////////////
// 'TO' SITES

// Note: this script has two types of 'sites'. One is the sites that searches
// can be done /from/, ie. the album, artist, and request pages on Gazelle
// sites. These are the sites that the buttons will be added to. The other type
// is sites that searches are done /on/ when you click those buttons, ie.
// metadata sites like Discogs, but also other torrent trackers and web stores.
//
// If you're browsing Orpheus, and click a button to perform a search on
// Redacted, then Orpheus is the 'from' site and Redacted is the 'to' site.

// Don't touch this, it's not a user setting! We need to set this variable here
// to support looking up artists by their Discogs ID from Orpheus.
const discogs_artist_id = (function() {
  return Array.from(document.querySelectorAll('.box_metadata_artist li')).map(function(li) {
    const match = li.textContent.match(/^Discogs ID: ([0-9]+)$/);
    return (match
            ? +match[1]
            : -1);
  }).find(function(number) {
    return number >= 0;
  });
}());

const ALBUM_PATHS = {
  ['GAZELLE']:       '/torrents.php?action=advanced&artistname={artist}&groupname={title}',
  ['JPOPSUKI']:       '/torrents.php?action=advanced&artistname={artist}&torrentname={title}',
  ['ANIMEBYTES']:    '/torrents2.php?action=advanced&artistnames={artist}&groupname={title}',
  ['TBDEV']:         '/browse.php?q={artist}+{title}',
  ['RUTRACKER']:     '/forum/tracker.php?nm={artist}+{title}',
  ['APPLEMUSIC']:    '/search?term={artist}+{title}',
  ['BANDCAMP']:      '/search?q={artist}+{title}&item_type=a',
  ['DEEZER']:        '/search/{artist}+{title}',
  ['QOBUZ']:         '/us-en/search?q={artist}+{title}',
  ['SPOTIFYAPP']:    ':{artist} {title}',
  ['SPOTIFYWEB']:    '/search/{artist} {title}/albums',
  ['MUSICBRAINZ']:   '/taglookup?tag-lookup.artist={artist}&tag-lookup.release={title}',
  ['DISCOGS']:       '/search/?type=all&title={title}&artist={artist}&advanced=1',
  ['LASTFM']:        '/music/{artist}/{title}',
  ['WIKIPEDIA']:     '/wikipedia/en/w/index.php?title=Special:Search&search={artist} {title}',
  ['ALLMUSIC']:      '/search/albums/{artist}+{title}',
  ['COVERSEARCHENGINE']: '/?artist={artist}&album={title}',
  ['YOUTUBE']:       '/results?search_query={artist}+{title}',
  ['PITCHFORK']:     '/search/?query={artist}+{title}',
  ['RATEYOURMUSIC']: '/search?searchterm={artist}+{title}&searchtype=',
};

const ARTIST_PATHS = {
  ['GAZELLE']:       `/${GAZELLE_STRAIGHT_TO_ARTIST_PAGE ? 'artist' : 'torrents'}.php?artistname={artist}`,
  ['JPOPSUKI']:      `/${GAZELLE_STRAIGHT_TO_ARTIST_PAGE ? 'artist' : 'torrents'}.php?artistname={artist}`,
  ['ANIMEBYTES']:    `/${GAZELLE_STRAIGHT_TO_ARTIST_PAGE ? 'artist' : 'torrents'}.php?name={artist}`,
  ['TBDEV']:         '/browse.php?q={artist}',
  ['RUTRACKER']:     '/forum/tracker.php?nm={artist}',
  ['APPLEMUSIC']:    '/search?term={artist}',
  ['BANDCAMP']:      '/search?q={artist}&item_type=b',
  ['DEEZER']:        '/search/{artist}',
  ['QOBUZ']:         '/us-en/search?q={artist}',
  ['SPOTIFYAPP']:    ':{artist}',
  ['SPOTIFYWEB']:    '/search/{artist}/artists',
  ['MUSICBRAINZ']:   '/taglookup?tag-lookup.artist={artist}',
  ['DISCOGS']: (discogs_artist_id >= 0
                ?    `/artist/{artist_id}`
                :    `/search/?type=artist${DISCOGS_STRICT_ARTIST_SEARCH ? '&strict=true' : ''}&q={artist}`),
  ['LASTFM']:        '/music/{artist}',
  ['WIKIPEDIA']:     '/wikipedia/en/w/index.php?title=Special:Search&search={artist}',
  ['ALLMUSIC']:      '/search/artists/{artist}',
  ['COVERSEARCHENGINE']: '/ARTIST_SEARCH_NOT_SUPPORTED_BY_YAETS',
  ['YOUTUBE']:       '/results?search_query={artist}',
  ['PITCHFORK']:     '/search/?query={artist}',
  ['RATEYOURMUSIC']: '/search?searchterm={artist}+&searchtype=',
};

const SEARCH_SITES = [
  {
    // The name is used in the ENABLED array above, as well as in the info text
    // displayed when you hover over an icon or link.
    name: 'Redacted',
    // The tag is used as the text in the link box at the top of the page. It is
    // recommended to make this an abbreviation of the name, to save on
    // horizontal space.
    tag: 'RED',
    // The prefix is used in combination with the site's entry in ALBUM_PATHS or
    // ARTIST_PATHS to create full search URLs.
    prefix: 'https://redacted.sh',
    // The icon is displayed in the sidebar. It may be a data URI or
    // (recommended) SVG source code.
    icon: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="2 0 85.6 85.6"><g transform="matrix(1 0 0 .95 2 0)"><ellipse cx="42.3" cy="36.2" rx="39.1" ry="32.9"/><path d="M4.2 46.4h22v39.8h-22zm55.6-.7H82v39.7H59.8zM7 42.2c-.3-.5 0-3.9.4-6.3a48.6 48.6 0 0 1 9-19.6A30 30 0 0 1 36 5.6a62.4 62.4 0 0 1 11.6-.3 32 32 0 0 1 26.6 17.4 49.5 49.5 0 0 1 5.2 17.6c0 2-.1 2.3-1.3 2.3-2.6 0-3.3-.9-4.4-5.5A43.3 43.3 0 0 0 70 26.6 29.1 29.1 0 0 0 53.8 12c-2-.6-4-1-7.6-1.2-14-.9-24 4.3-29.8 15.6-1.4 3-2.4 5.8-3.8 10.6-.8 3-1.4 4.4-2 5a6 6 0 0 1-2.8.7c-.5 0-.7 0-.9-.4Z"/><ellipse cx="43" cy="33.3" fill="#babde0" rx="38.7" ry="29.5"/><path fill="#babde0" d="M63.2 66.3V48h6c6.6.1 7.1.2 7.4 1 .3.7 1 1.3 2.4 2l1.2.5v12.2c0 6.7 0 13.4-.2 14.9-.1 3-.3 3.4-1.3 3.6-.8.1-1.4.5-1.4.9s-.6 1-1.5 1.3c-1.1.4-4 .6-8.5.6h-4V66.3ZM15.3 84.7a27 27 0 0 1-5.3-.8 6.2 6.2 0 0 1-1.3-.9 4.5 4.5 0 0 0-1.5-.9c-.8-.2-1-.6-1.1-5.3-.3-4.9-.1-23 .1-24.5.3-1.3.4-1.5 1-1.6.6-.1 1.2-.7 1.8-1.5 1-1.2 1.2-1.2 8-1.2h6v37h-2.7a124.5 124.5 0 0 1-5-.2Z"/><path d="M7 88.3c-2.3-1-4.3-2.7-5.3-4.3L0 81.5l.3-21.3C.6 40.2.8 38.4 2.5 32c1-3.7 3-9.2 4.4-12A39.5 39.5 0 0 1 23.2 3.4c11-5 32.3-4.4 42 1.2A43.7 43.7 0 0 1 84 32.4c1.4 6 1.6 8 1.6 28.3v21.9l-2 2.6c-2.5 3.4-7.2 4.8-15.4 4.8-5.4 0-6.3-.2-8.4-1.8-1.6-1.2-2.4-2.5-2.4-3.6 0-2.4-1-2.7-3.8-1.3a45.3 45.3 0 0 1-21.8 0c-2.4-1.2-2.4-1.2-3 .6-.4.8-.6 1.6-.8 2.4 0 .3-1 1.3-2 2.1-2 1.4-3.1 1.6-8.9 1.6-5.5 0-7.2-.3-10.2-1.7Zm16-21.9V47.8h-6.6c-5.9 0-6.7.2-7.5 1.4-.5.8-1.4 1.5-2 1.5-.9 0-1 2.2-1 15.7 0 12.9.1 15.7 1 15.7.5 0 1.3.5 1.8 1 1 1.2 3.2 1.6 9.9 1.8l4.4.1V66.4Zm52.2 18.2c1.2-.3 2.2-1 2.2-1.5s.6-1 1.4-1c1.4 0 1.5-.4 1.5-15.4V51.3l-1.8-.8c-1-.4-1.8-1.2-1.8-1.7 0-.8-1.6-.7-6.8-.8h-6.6L63 66.3V85h5c2.7 0 6-.2 7.2-.4ZM9.9 42.3c1.2-.3 1.8-1.4 2.8-5.3 4.5-18.5 15.4-27.2 33-26.2 4.9.2 7.4.7 10.4 2.1a33 33 0 0 1 17.4 23.7c1.2 5.4 1.8 6.1 5.1 6.2 2.3 0 0-11.2-3.8-19.3C68.5 10.5 55.9 4 39.3 5.2a30.9 30.9 0 0 0-24.2 12.3c-3.8 5-7.6 14.7-8.3 21-.5 4.5-.3 4.8 3.1 3.8Z"/><ellipse cx="43.1" cy="45.1" fill="#F30000" rx="8.6" ry="8.3" transform="matrix(1 0 0 -1 0 90.2)"/></g></svg>',
    // The type is used to decide which entry in the ALBUM_PATHS and
    // ARTISTS_PATHS is used for this site.
    type: 'GAZELLE',
  },
  {
    name: 'Orpheus',
    tag: 'OPS',
    prefix: 'https://orpheus.network',
    icon: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="-192 0 192 160"><linearGradient id="b" x1="0" x2="0" y1="130" y2="30" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#888"/><stop offset="1" stop-color="#222"/></linearGradient><linearGradient id="a" x1="0" x2="0" y1="30" y2="130" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#888"/><stop offset="1" stop-color="#222"/></linearGradient><path fill="url(#a)" d="M80 119c35 48 70-13 70-50 0-44-45-69-70-69C39 0 0 34 0 80c0 52 45 80 80 80-8-1-35-7-35-68 0-41 13-58 35-51 0 1 23 10 23 39 0 30-23 39-23 39z" transform="scale(-1.2 1)"/><path fill="url(#b)" d="M80 41c-24-8-52 12-52 50 0 63 47 69 52 69 41 0 80-34 80-80 0-51-45-80-80-80 10-1 53 11 53 69 0 38-32 59-53 50-1 0-24-9-24-39 0-29 24-39 24-39z" transform="scale(-1.2 1)"/></svg>',
    type: 'GAZELLE',
  },
  {
    name: 'DEEPBASSNiNE',
    tag: 'DB9',
    prefix: 'https://deepbassnine.com',
    icon: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="-174 114 574 574"><circle fill="#fff" cx="113" cy="401" r="287"/><circle fill="#222" cx="113" cy="401" r="264"/><path fill="#fff" d="m70 256-1 117c0 6-4 19-12 19H-55c-10 0-17-11-17-19s9-18 17-18H57v-39H-56c-31 0-56 27-57 57s31 58 57 58H62a49 49 0 0 0 47-46V256H70zm88 0h-38v129c1 22 18 45 46 46h134c0 7-9 26-29 26H-47c-40 0-64-33-68-43v37c0 30 30 53 68 53h316c37 0 72-30 72-60v-71a59 59 0 0 0-57-57H171v40h112c10 0 17 8 17 17 0 11-7 19-17 19H171c-8 0-12-13-12-19z"/></svg>',
    type: 'GAZELLE',
  },
  {
    name: 'JPopsuki',
    tag: 'JPS',
    prefix: 'https://jpopsuki.eu',
    // TODO: Placeholder icon.
    icon: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round" stroke="#CCCCCC" stroke-width="10.24"></g><g id="SVGRepo_iconCarrier"> <path style="fill:#FFFFFF;" d="M473.104,371.851c0.176-0.611,0.336-1.228,0.479-1.85c0.046-0.2,0.089-0.401,0.131-0.603 c0.113-0.54,0.213-1.085,0.3-1.634c0.037-0.236,0.076-0.473,0.11-0.711c0.075-0.545,0.131-1.092,0.18-1.643 c0.021-0.225,0.047-0.447,0.063-0.674c0.052-0.767,0.084-1.537,0.084-2.313l0,0l0,0v-0.006l-0.006-40.904v-0.002l-0.005-26.203 v-0.002v-4.213l-0.004-25.574l0,0l-0.008-48.824l-0.005-26.204l-0.006-40.984c0-2.995-0.407-5.931-1.16-8.75 c-0.405-1.517-0.915-2.997-1.521-4.435c-2.477-5.877-6.574-11.017-11.925-14.74c-0.784-0.545-1.584-1.071-2.419-1.553 l-22.874-13.202l-21.414-12.358l-17.239-9.949l-65.928-38.046L304.22,31.629l-19.288-11.132l-11.953-6.899 c-10.533-6.078-23.509-6.076-34.04,0.007l-11.872,6.857l-19.288,11.14l-25.717,14.854v-0.001l-65.915,38.072l-28.89,16.686 l-21.408,12.365l-11.282,6.517c-0.811,0.468-1.59,0.979-2.353,1.506c-3.272,2.268-6.073,5.068-8.333,8.235 c-1.517,2.129-2.781,4.424-3.773,6.843c-1.655,4.031-2.558,8.399-2.557,12.899l0.006,40.912l0.005,26.204l0.012,73.738v4.011v0.85 v0.001v0.013l0,0v0.005l0,0l0.005,26.2l0,0v1.864l0.002,12.617l0.004,26.497v0.006l0,0c0,0.773,0.033,1.539,0.084,2.305 c0.016,0.223,0.042,0.445,0.061,0.668c0.048,0.548,0.105,1.096,0.18,1.638c0.033,0.236,0.072,0.471,0.108,0.708 c0.087,0.544,0.186,1.086,0.298,1.625c0.042,0.201,0.086,0.403,0.131,0.603c0.14,0.615,0.298,1.222,0.471,1.825 c0.033,0.113,0.061,0.227,0.095,0.34c0.909,3.042,2.24,5.93,3.94,8.589l0.001,0.001l0.001,0.002 c1.172,1.832,2.517,3.551,4.025,5.137c0.051,0.052,0.099,0.106,0.148,0.158c0.709,0.735,1.454,1.439,2.231,2.113 c0.125,0.11,0.254,0.215,0.382,0.322c0.786,0.661,1.595,1.298,2.445,1.89c0.784,0.545,1.584,1.07,2.419,1.553l22.552,13.015 l21.414,12.36l17.561,10.134l91.644,52.89l19.288,11.132l11.953,6.899c10.533,6.078,23.509,6.076,34.04-0.007l11.872-6.857 l19.288-11.14l25.717-14.853l55.554-32.086l10.363-5.985l26.36-15.225l21.408-12.365l13.813-7.978 c0.811-0.468,1.59-0.979,2.353-1.506c0.851-0.588,1.659-1.226,2.446-1.884c0.128-0.107,0.258-0.212,0.385-0.322 c0.78-0.673,1.526-1.375,2.237-2.11c0.047-0.048,0.09-0.098,0.136-0.146c3.724-3.891,6.476-8.609,8.02-13.765 C473.045,372.067,473.072,371.958,473.104,371.851z"></path> <circle style="fill:#ED1F34;" cx="256.004" cy="256.004" r="90.414"></circle> <path d="M255.999,156.544c-54.84,0-99.455,44.616-99.455,99.455s44.615,99.455,99.455,99.455s99.455-44.616,99.455-99.455 S310.84,156.544,255.999,156.544z M255.999,337.372c-44.869,0-81.373-36.503-81.373-81.373s36.503-81.373,81.373-81.373 s81.373,36.503,81.373,81.373S300.869,337.372,255.999,337.372z M483.457,149.503c0-3.711-0.494-7.438-1.465-11.078 c-0.506-1.899-1.155-3.789-1.925-5.615c-3.179-7.544-8.398-13.991-15.096-18.652c-1.118-0.778-2.089-1.4-3.062-1.961L277.499,5.767 C270.96,1.994,263.513,0,255.964,0c-7.555,0-15.005,1.996-21.547,5.776L50.042,112.265c-0.95,0.549-1.896,1.152-2.978,1.902 c-4.086,2.831-7.635,6.335-10.547,10.421c-1.912,2.683-3.519,5.597-4.775,8.658c-2.147,5.23-3.234,10.724-3.234,16.334 l0.035,212.917c0,0.921,0.034,1.876,0.105,2.919c0.016,0.234,0.037,0.469,0.061,0.702l0.014,0.143 c0.061,0.693,0.134,1.385,0.231,2.095c0.034,0.24,0.071,0.477,0.108,0.716l0.025,0.16c0.11,0.69,0.235,1.378,0.38,2.075 c0.053,0.254,0.107,0.508,0.163,0.746c0.177,0.779,0.377,1.547,0.608,2.351l0.112,0.392c1.144,3.829,2.821,7.487,4.988,10.875 c1.484,2.322,3.198,4.509,5.089,6.494c0.04,0.042,0.153,0.164,0.195,0.206c0.896,0.929,1.847,1.83,2.81,2.663l0.498,0.42 c1.093,0.919,2.105,1.699,3.096,2.388c1.096,0.763,2.096,1.403,3.064,1.963l184.411,106.428c6.538,3.773,13.985,5.768,21.534,5.768 l0,0c7.554,0,15.005-1.998,21.547-5.776l184.372-106.49c0.945-0.545,1.89-1.149,2.982-1.905c0.986-0.682,1.999-1.461,3.181-2.448 c0.14-0.116,0.278-0.231,0.405-0.34c0.99-0.854,1.941-1.752,2.84-2.681l0.159-0.171c4.695-4.904,8.206-10.929,10.149-17.421 l0.116-0.406c0.224-0.775,0.427-1.556,0.605-2.34l0.169-0.773c0.143-0.684,0.27-1.374,0.398-2.177 c0.042-0.259,0.082-0.518,0.121-0.792c0.094-0.69,0.168-1.383,0.228-2.071l0.014-0.143c0.024-0.24,0.047-0.48,0.063-0.721 c0.071-1.043,0.105-1.999,0.105-2.931L483.457,149.503z M465.348,364.1l-0.051,0.52c-0.035,0.404-0.076,0.805-0.129,1.191 l-0.063,0.407c0,0.004-0.02,0.125-0.02,0.127c-0.064,0.404-0.137,0.804-0.231,1.251l-0.084,0.387 c-0.104,0.457-0.222,0.909-0.347,1.341l-0.071,0.254c-1.128,3.764-3.164,7.258-5.908,10.125l-0.083,0.09 c-0.512,0.529-1.066,1.051-1.649,1.555l-0.276,0.228c-0.684,0.573-1.255,1.014-1.791,1.384c-0.671,0.465-1.221,0.817-1.731,1.113 l-184.375,106.49c-3.796,2.192-8.119,3.351-12.502,3.351c-4.381,0-8.701-1.159-12.496-3.348L59.131,384.141 c-0.529-0.305-1.095-0.669-1.775-1.143c-0.538-0.375-1.126-0.829-1.787-1.385l-0.293-0.246c-0.568-0.489-1.119-1.011-1.589-1.498 c-0.027-0.029-0.129-0.137-0.157-0.168c-1.099-1.155-2.094-2.424-2.956-3.772c-0.016-0.025-0.031-0.049-0.047-0.074 c-1.237-1.948-2.195-4.047-2.849-6.239l-0.069-0.246c-0.127-0.442-0.244-0.888-0.351-1.354l-0.093-0.428 c-0.082-0.395-0.154-0.793-0.217-1.181l-0.082-0.524c-0.054-0.4-0.096-0.803-0.13-1.203l-0.048-0.493 c-0.039-0.561-0.064-1.125-0.064-1.7l-0.035-212.911c0-3.24,0.632-6.425,1.881-9.467c0.729-1.781,1.662-3.472,2.769-5.025 c1.696-2.378,3.755-4.415,6.119-6.053c0.668-0.463,1.216-0.815,1.725-1.109l184.377-106.49c3.795-2.193,8.119-3.351,12.504-3.351 c4.381,0,8.701,1.157,12.495,3.347l184.407,106.427c0.522,0.301,1.089,0.667,1.779,1.145c3.881,2.7,6.908,6.445,8.757,10.832 c0.448,1.062,0.825,2.157,1.116,3.252c0.565,2.121,0.854,4.281,0.854,6.418l0.035,212.916 C465.409,362.993,465.384,363.561,465.348,364.1z"></path> </g></svg>',
    type: 'JPOPSUKI',
  },
  {
    name: 'AnimeBytes',
    tag: 'AB',
    prefix: 'https://animebytes.tv',
    icon: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="1.47 0 254.33 256.03"><path fill="#eb1168" d="M97 6c3 4-4 11-6 14-9 14-18 28-25 43-9 21-13 45-7 67 9 31 39 53 72 55 31 1 50-25 55-53 1-17-3-34-16-46-11-9-24-15-35-23l-7-6a30 30 0 0 1-7-7 30 30 0 0 1-4-9c-4-13 2-25 10-34a24 24 0 0 1 3-3 20 20 0 0 1 3-2 21 21 0 0 1 7-2c41 2 79 24 99 62l2 5c10 21 13 45 14 68 2 27 0 115-4 118-3 2-8 2-10 2a56 56 0 0 1-13 0h-2l-3-1a26 26 0 0 1-7-3c-6-4-9-10-12-17-7 2-14 7-21 10a157 157 0 0 1-20 7 132 132 0 0 1-39 5c-43-1-85-29-106-65a124 124 0 0 1-6-13 130 130 0 0 1 3-109 129 129 0 0 1 37-44 131 131 0 0 1 25-15c3-1 14-8 18-6a6 6 0 0 1 2 2Zm5-4Z"/></svg>',
    type: 'ANIMEBYTES',
  },
  {
    name: 'RuTracker',
    tag: 'Ru',
    prefix: 'https://rutracker.org',
    icon: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 320"><path fill="#e22446" d="m209 12-13 16c-7 9-13 17-16 19-5 6-13 11-21 14a2166 2166 0 0 0-55 1c-4 0-7 3-7 6l13 19c11 16 16 26 18 33v23l-6 18c-5 11-6 14-5 16 2 5 5 5 22-1 29-10 34-15 44-46l7-22c3-7 10-11 17-10 7 0 10 3 26 28 7 10 17 20 19 20 0 0 2-1 2-3 4-5 12-12 28-22l18-13c2-2 1-6-1-8-1-1-10-5-21-8l-25-10c-7-4-16-14-20-21-3-5-7-20-12-38-1-6-3-9-5-11s-4-3-7-1z"/><path fill="#3a4ee7" d="M57 94c-4 1-4 4-3 17a513 513 0 0 1-2 46c-5 14-10 19-33 37L4 206v7c1 2 12 5 23 7 21 5 31 10 40 19 8 8 11 13 19 37 3 10 7 18 8 19 1 2 6 3 8 1l5-8c20-31 24-35 34-41 5-4 14-7 19-7l24-2c23 0 25-1 25-6 0-3-1-5-21-29-7-8-12-19-14-27l-1-6-4 3c-6 5-12 7-29 13-19 6-22 6-30 0-2-2-3-6-3-10-1-2 1-7 4-16l7-17v-18l-4-2c-10-1-15-3-39-20-14-10-15-10-18-9z"/><path fill="#05cc63" d="M205 108c-3 0-6 3-6 4a409 409 0 0 1-16 49v8c1 7 4 15 7 20a520 520 0 0 0 28 35c2 4 2 11 0 15-2 3-7 7-10 8l-22 2-21 1 1 5 1 29c0 23 0 25 2 26l4 2c2 0 9-4 17-10 19-14 21-16 28-19s13-4 21-3c7 0 12 0 17 2l19 7c18 6 21 6 23 2 1-3 0-5-5-23-8-22-9-27-8-37 0-13 4-20 20-42l14-19c0-1 0-3-2-4-3-3-3-3-26-3-28 0-34-1-47-10-6-5-10-9-23-27l-13-17-4-1z"/></svg>',
    type: 'RUTRACKER',
    torrents: true, // Set these to 'false' to hide them on the respective
    requests: true, // pages. You can use these settings for other sites as
    artist:   true, // well. If they're missing, they're assumed to be 'true'.
  },
  {
    name: 'AppleMusic',
    tag: 'APPL',
    prefix: 'https://music.apple.com',
    icon: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="-0.17 -0.17 512.28 512.32"><linearGradient id="a" x1="256" x2="256" y1="506.9" y2="10.2" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#ff5c3a"/><stop offset=".5" stop-color="#fa2e46"/><stop offset="1" stop-color="#ff2969"/></linearGradient><path fill="url(#a)" d="M512 256c-1 54 3 109-11 162-8 32-30 61-60 75-45 20-96 18-144 19-58-1-116 3-173-5-36-4-74-19-95-50C3 419 2 371 0 327c0-59-1-118 2-178 3-40 11-83 42-111C76 9 122 3 163 1c59-2 118-1 177 0 42 2 89 5 124 33 31 25 42 67 45 106 4 38 3 77 3 116z"/><path fill="#fff" d="M199 359V199q0-9 10-11l138-28q11-2 12 10v122q0 15-45 20c-57 9-48 105 30 79 30-11 35-40 35-69V88s0-20-17-15l-170 35s-13 2-13 18v203q0 15-45 20c-57 9-48 105 30 79 30-11 35-40 35-69"/></svg>',
    type: 'APPLEMUSIC',
  },
  {
    name: 'Bandcamp',
    tag: 'BC',
    prefix: 'https://bandcamp.com',
    icon: '<svg xmlns="http://www.w3.org/2000/svg" xml:space="preserve" viewBox="-70 -352.5 980 980"><circle cx="420" cy="137.5" r="490" fill="#17a0c4"/><path fill="#fff" d="M551 103c-35 0-53 28-53 69 0 40 20 69 53 69 38 0 52-35 52-69 0-35-17-69-52-69M458 0h42v100c12-19 36-31 57-31 59 0 88 47 88 104 0 53-25 102-81 102-26 0-53-6-66-32v27h-40V0m341 140c-4-24-20-37-43-37-22 0-52 12-52 71 0 33 14 67 50 67 24 0 41-16 45-44h41c-7 50-38 78-86 78-59 0-92-43-92-101 0-59 31-105 93-105 44 0 81 23 85 71h-41M312 269H0L146 0h312L312 269"/></svg>',
    type: 'BANDCAMP',
  },
  {
    name: 'Deezer',
    tag: 'Deez',
    prefix: 'https://deezer.com',
    icon: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 62 198 130"><g transform="translate(0 87)"><path fill="#40ab5d" d="M156-25h43V0h-43z"/><path fill="#34a065" d="M156 10h43v25h-43z"/><path fill="#2c5594" d="M156 45h43v25h-43z"/><path fill="#ff8d00" d="M0 79h43v25H0z"/><path fill="#e7542f" d="M52 79h43v25H52z"/><path fill="#84166c" d="M104 79h43v25h-43z"/><path fill="#2c439b" d="M156 79h43v25h-43z"/><path fill="#81166c" d="M104 45h43v25h-43z"/><path fill="#e77d1f" d="M52 45h43v25H52z"/><path fill="#fe9912" d="M52 10h43v25H52z"/></g></svg>',
    type: 'DEEZER',
  },
  {
    name: 'Qobuz',
    tag: 'Qob',
    prefix: 'https://qobuz.com',
    icon: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 4.5 31.1 31.1"><path d="M27.8 29.1a15.4 15.4 0 1 0-3.2 3.2l3.1 3.3 3.4-3.3-3.3-3.2z"/><circle cx="15.4" cy="19.9" r="14.3" fill="#FFF"/><path d="M15.4 8.4a11.5 11.5 0 1 0 0 23 11.5 11.5 0 0 0 0-23zm0 16a4.5 4.5 0 1 1 0-9 4.5 4.5 0 0 1 0 9z"/><circle cx="15.4" cy="19.9" r="1"/><path fill="#FFF" d="m29.5 32.4-7.7-7.7a1.2 1.2 0 1 0-1.8 1.6l7.8 7.7 1.7-1.6z"/></sv>g',
    type: 'QOBUZ',
  },
  {
    name: 'Spotify (app)',
    tag: 'SPOT',
    prefix: 'spotify:search',
    icon: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="-0.17 -0.17 512.28 512.32"><linearGradient id="a" x1="256" x2="256" y1="506.9" y2="10.2" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#ff5c3a"/><stop offset=".5" stop-color="#0f0"/><stop offset="1" stop-color="#ff2969"/></linearGradient><path fill="url(#a)" d="M512 256c-1 54 3 109-11 162-8 32-30 61-60 75-45 20-96 18-144 19-58-1-116 3-173-5-36-4-74-19-95-50C3 419 2 371 0 327c0-59-1-118 2-178 3-40 11-83 42-111C76 9 122 3 163 1c59-2 118-1 177 0 42 2 89 5 124 33 31 25 42 67 45 106 4 38 3 77 3 116z"/><path fill="#fff" d="M199 359V199q0-9 10-11l138-28q11-2 12 10v122q0 15-45 20c-57 9-48 105 30 79 30-11 35-40 35-69V88s0-20-17-15l-170 35s-13 2-13 18v203q0 15-45 20c-57 9-48 105 30 79 30-11 35-40 35-69"/></svg>',
    type: 'SPOTIFYAPP',
    // The raw artist and album name found on 'from' sites has to be URL-encoded
    // before we pass them to 'to' sites. If a 'to' site has additional
    // requirements, you can specify a custom transform_function to meet them.
    // Most sites only require a conversion of spaces to plus signs, so YAETS
    // does that by default even if no transform_function is given.
    //
    // For Spotify (both site and app), however, that should /not/ be done, so
    // we specify a do-nothing function.
    transform_function: function(data) {
      return data;
    },
  },
  {
    name: 'Spotify (web)',
    tag: 'SPOT',
    prefix: 'https://open.spotify.com',
    icon: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="-0.17 -0.17 512.28 512.32"><linearGradient id="a" x1="256" x2="256" y1="506.9" y2="10.2" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#ff5c3a"/><stop offset=".5" stop-color="#f00"/><stop offset="1" stop-color="#ff2969"/></linearGradient><path fill="url(#a)" d="M512 256c-1 54 3 109-11 162-8 32-30 61-60 75-45 20-96 18-144 19-58-1-116 3-173-5-36-4-74-19-95-50C3 419 2 371 0 327c0-59-1-118 2-178 3-40 11-83 42-111C76 9 122 3 163 1c59-2 118-1 177 0 42 2 89 5 124 33 31 25 42 67 45 106 4 38 3 77 3 116z"/><path fill="#fff" d="M199 359V199q0-9 10-11l138-28q11-2 12 10v122q0 15-45 20c-57 9-48 105 30 79 30-11 35-40 35-69V88s0-20-17-15l-170 35s-13 2-13 18v203q0 15-45 20c-57 9-48 105 30 79 30-11 35-40 35-69"/></svg>',
    type: 'SPOTIFYWEB',
    transform_function: function(data) {
      return data;
    },
  },
  {
    name: 'MusicBrainz',
    tag: 'MB',
    prefix: 'https://musicbrainz.org',
    icon: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="10 0 125.1 125.2"><path fill="#eb743b" d="M67 0v125l60-30.3V30.4z"/><path fill="#ba478f" d="m62 52.1-1-.9V47l1-.9V35.6h-1V17.4l1-.9V0L2 30.4v64.3L62 125z"/><path fill="#fffedb" d="M62 46 35.4 60V49.4L62 35.6v-20L30 33h-.1a2.7 2.4 0 0 0-.3.2l-.2.1a2.9 2.5 0 0 0-.2.2l-.1.2a2.5 2.2 0 0 0-.2.2 2.8 2.4 0 0 0-.1.2l-.1.3a2.7 2.4 0 0 0 0 .2 2.5 2.2 0 0 0 0 .2 3 2.6 0 0 0 0 .3v44a10.8 9.6 0 0 0-8 1.8c-4.7 2.8-6.3 8-3.9 11.3 2.4 3.2 8 3.4 12.8.6 2.7-1.6 5.3-3.6 6-5.8a10.4 9.2 0 0 0 0-1.8V66L62 52.1z"/></svg>',
    type: 'MUSICBRAINZ',
  },
  {
    name: 'Discogs',
    tag: 'Dis',
    prefix: 'https://discogs.com',
    icon: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="-0.23 -0.23 24.46 24.46"><path d="M1.74 11.98a10.29 10.29 0 0 1 15.3-8.96l.82-1.49A12.06 12.06 0 0 0 12.19 0H12A12.01 12.01 0 0 0 0 11.9v.1c0 3.44 1.46 6.54 3.77 8.72l1.19-1.28a10.25 10.25 0 0 1-3.22-7.46zm18.62-8.57-1.15 1.24A10.29 10.29 0 0 1 7.1 21l-.87 1.52A12 12 0 0 0 20.36 3.4zm-18.4 8.57c0 2.87 1.21 5.46 3.15 7.3L6.29 18a8.3 8.3 0 0 1 5.73-14.33 8.3 8.3 0 0 1 4.08 1.07l.84-1.52a10.06 10.06 0 0 0-14.97 8.77zm18.37 0A8.32 8.32 0 0 1 8.06 19.3l-.86 1.52a10.07 10.07 0 0 0 11.85-16l-1.18 1.27a8.28 8.28 0 0 1 2.46 5.9zm-1.95 0a6.37 6.37 0 0 1-6.36 6.37 6.33 6.33 0 0 1-3-.76l-.85 1.5a8.1 8.1 0 0 0 9.56-12.86l-1.18 1.28a6.36 6.36 0 0 1 1.83 4.47zm-14.45 0c0 2.3.96 4.38 2.51 5.86l1.17-1.27a6.34 6.34 0 0 1 4.4-10.95c1.15 0 2.22.3 3.15.83L16 4.94a8.1 8.1 0 0 0-12.07 7.05zm12.53 0a4.44 4.44 0 0 1-4.44 4.44 4.42 4.42 0 0 1-2.06-.51l-.84 1.49a6.11 6.11 0 0 0 2.9.73 6.15 6.15 0 0 0 4.37-10.46l-1.16 1.25c.76.8 1.23 1.88 1.23 3.06zm-10.59 0c0 1.74.73 3.3 1.9 4.43l1.15-1.25.01.01a4.42 4.42 0 0 1 3.09-7.62c.8 0 1.56.22 2.21.6l.82-1.5a6.1 6.1 0 0 0-3.03-.8 6.14 6.14 0 0 0-6.15 6.13zm6.69 0a.54.54 0 0 1-1.08 0 .54.54 0 1 1 1.08 0zm-3.94 0a3.4 3.4 0 1 1 6.8 0 3.4 3.4 0 0 1-6.8 0zm.14 0a3.26 3.26 0 1 0 6.52 0 3.26 3.26 0 0 0-6.52 0Z"/></svg>',
    type: 'DISCOGS',
  },
  {
    name: 'LastFM',
    tag: 'Last',
    prefix: 'https://last.fm',
    icon: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="-143 145 512 512"><circle fill="#FFFFFF" cx="112" cy="400" r="200"/><path fill="#b90000" d="M113 145a256 256 0 1 0 0 512 256 256 0 0 0 0-512zm74 334c-25-1-41-12-52-37l-3-6-24-55c-7-19-27-32-48-32a53 53 0 1 0 47 78l2-1 1 1 10 22v2a77 77 0 0 1-137-49c0-42 35-77 77-77 32 0 58 18 71 48l25 57c7 15 12 24 30 25 17 1 29-9 29-23 0-12-8-15-25-21-29-10-46-20-46-44 1-25 17-40 43-40 17 0 29 7 38 23v1l-1 1-16 8h-2c-6-8-12-11-20-11-11 0-19 7-19 17 0 12 10 15 26 20l6 2c25 9 40 18 40 45 0 26-22 46-52 46z"/></svg>',
    type: 'LASTFM',
    transform_function: function(data) {
      // On Last.FM, the '+' character should be encoded as '%252B'.
      // Test case: https://orpheus.network/torrents.php?id=4879
      return data.replace(/%2B/g,
                          '%252B').replace(/%20/g,
                                           '+');
    },
  },
  {
    name: 'Wikipedia',
    tag: 'Wiki',
    prefix: 'https://secure.wikimedia.org',
    icon: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48"><circle cx="24" cy="24" r="24" fill="#e7e6e6"/><path fill="#393939" d="m43 12.4-.1.3c-.1.2-.2.2-.3.2-.8 0-1.5.4-2 .8-.6.5-1.1 1.3-1.7 2.6l-8.6 19.5c0 .1-.2.2-.5.2-.2 0-.4 0-.5-.2l-4.8-10.2-5.6 10.2-.4.2c-.3 0-.5 0-.5-.2L9.5 16.3c-.5-1.2-1-2-1.7-2.5-.6-.5-1.4-.8-2.4-.9l-.3-.1-.1-.4c0-.3 0-.4.3-.4h2.3a23.8 23.8 0 0 0 4.6 0h2.6c.2 0 .3.1.3.4 0 .4 0 .5-.2.5-.7 0-1.3.3-1.7.6-.5.3-.7.7-.7 1.3l.3 1 7 15.8 4-7.5-3.7-7.8a10 10 0 0 0-1.7-2.7c-.4-.3-1-.6-2-.7l-.2-.1v-.4c0-.3 0-.4.2-.4h2a17 17 0 0 0 4.1 0h2.3c.2 0 .3.1.3.4 0 .4 0 .5-.2.5-1.5.1-2.2.5-2.2 1.3 0 .3.1.9.5 1.6l2.4 5 2.5-4.6c.3-.6.5-1.2.5-1.6 0-1-.8-1.6-2.3-1.7-.1 0-.2-.1-.2-.5l.1-.3.2-.1h2a20.9 20.9 0 0 0 5.6 0c.1 0 .2.1.2.4 0 .3-.2.5-.4.5a4 4 0 0 0-2.1.7c-.6.4-1.2 1.3-2 2.7l-3.3 6 4.4 9 6.5-15.1c.2-.6.4-1 .4-1.5 0-1.1-.8-1.7-2.3-1.8-.1 0-.2-.1-.2-.5 0-.3 0-.4.3-.4h2a18.2 18.2 0 0 0 3.4 0h1.9c.1 0 .2.1.2.4"/></svg>',
    type: 'WIKIPEDIA',
    // Wikipedia does not have clear search URLs for albums. By default, therefore,
    // the button for it is only displayed on artist pages. You can change that
    // here, if you wish.
    torrents: false,
    requests: false,
  },
  {
    name: 'AllMusic',
    tag: 'All',
    prefix: 'https://www.allmusic.com',
    icon: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="118.18 150.5 377.02 482.73"><path fill="#131313" d="M432.5 627.5 310.8 352.2a14.6 14.6 0 1 0-7.8 0l-124.2 281h67.4l14-40.2h92.4l14.3 40.1h67.7ZM276.9 544l30-82 29.3 82Z"/><path fill="#27aae1" d="M403.3 338.9a96.6 96.6 0 1 0-160 72.8l11.6-26.3a69.7 69.7 0 1 1 104-.4l11.5 26.4a96.5 96.5 0 0 0 32.9-72.5Z"/><path fill="#27aae1" d="M466 439.6A187.7 187.7 0 0 0 495.2 339c0-104-84.5-188.5-188.5-188.5S118.2 235 118.2 339a187.7 187.7 0 0 0 29.7 101.5 189.6 189.6 0 0 0 57.8 57.6l13-30a157.5 157.5 0 0 1-68.3-129c0-86.3 70-156.4 156.3-156.4S463 252.7 463 338.9a155.4 155.4 0 0 1-67.8 128.8l13 29.8a189.6 189.6 0 0 0 57.7-57.9Z"/></svg>',
    type: 'ALLMUSIC',
  },
  {
    name: 'Cover Search Engine',
    tag: 'COV',
    prefix: 'https://covers.musichoarders.xyz',
    icon: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path fill="#fff" stroke="#000" stroke-width="3" d="m509 255-1 4c0 36-33 59-69 59h-96a48 48 0 0 0-47 58l11 30c6 13 12 27 12 41 0 32-21 60-53 61l-10 1a252 252 0 1 1 253-253Z"/><path d="M384 191c18 0 32-13 32-32 0-17-14-32-32-32s-32 15-32 32c0 19 14 32 32 32zM256 63c-18 0-32 15-32 32 0 19 14 32 32 32s32-13 32-32c0-17-14-32-32-32zM128 191c18 0 32-13 32-32 0-17-14-32-32-32s-32 15-32 32c0 19 14 32 32 32zm-32 64c-18 0-32 15-32 32 0 19 14 32 32 32s32-13 32-32c0-17-14-32-32-32z"/></svg>',
    type: 'COVERSEARCHENGINE',
    // Artists don't have covers; only albums do.
    artist: false,
  },
  {
    name: 'YouTube',
    tag: 'YT',
    prefix: 'https://youtube.com',
    icon: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 461 461"><circle cx="230" cy="230" r="120" fill="#fff"/><path fill="#f61c0d" d="M365 67H96c-53 0-96 43-96 96v135c0 53 43 96 96 96h269c53 0 96-43 96-96V163c0-53-43-96-96-96zm-64 170-127 60c-3 2-7-1-7-4V169c0-4 4-7 8-5l126 64c3 2 3 7 0 9z"/></svg>',
    type: 'YOUTUBE',
  },
  {
    name: 'Pitchfork',
    tag: 'Pitch',
    prefix: 'https://pitchfork.com',
    icon: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="-1.5 -1.5 63 63"><circle cx="30" cy="30" r="25" fill="#ccc" opacity=".8"/><g fill="#333"><path fill-rule="evenodd" d="m19.2 13.8 2.9 2.9L9.9 28.8c-.1 2.5.3 5.3 1 7.4L26.3 21l2.8 2.8v-9.9zm14 3 3 3L13.8 42c1.2 1.6 2.7 3 4.2 4.2l22.2-22.3 2.9 2.9v-10h-10m3 14 3 3L23.7 49a20 20 0 0 0 7.4 1l12.1-12.2 2.9 2.9v-10z"/><path stroke="#1a1a1a" stroke-opacity=".6" d="M30 1a29 29 0 1 0 0 58 29 29 0 1 0 0-58zm0 4a25 25 0 0 1 0 50 25 25 0 1 1 0-50z"/></g></svg>',
    type: 'PITCHFORK',
  },
  {
    name: 'Rate Your Music',
    tag: 'RYM',
    prefix: 'https://rateyourmusic.com',
    icon: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="9.98 9.98 180.03 180.03"><g fill="#e6e4e5"><path d="M118.53 64c13.76 5.56 38.12 4.76 53.2 3.44C159.3 40.18 131.77 21.12 100 21.12a77 77 0 0 0-41.56 11.91C84.91 20.59 97.62 55.26 118.53 64z"/><path d="M190 100c0 49.76-40.24 90-90 90s-90-40.24-90-90 40.23-90 90-90 90 40.5 90 90z"/></g><path fill="#55acdb" d="M146.33 95.5c12.17.8 23.29-2.38 31.76-6.09a77.04 77.04 0 0 0-6.35-22.23c-15.1 1.32-39.44 2.11-53.2-3.44C97.61 55 83.84 19.79 58.43 32.77A78.72 78.72 0 0 0 21.12 100a78.7 78.7 0 0 0 2.91 21.18c12.44-11.12 38.65-32.03 62.2-38.38 31.77-8.48 33.89 11.11 60.1 12.7z"/><path fill="#2b6ab2" d="M178.1 89.68a72.4 72.4 0 0 1-31.77 6.08c-26.2-1.58-28.33-21.44-60.36-12.7-23.29 6.35-49.5 27.53-62.2 38.38 2.64 9 6.62 17.47 12.17 25.15 8.47-7.15 18.8-13.77 30.18-16.15 32.56-6.88 32.56 16.41 60.09 13.24 15.09-1.86 35.73-16.42 51.35-29.12.8-4.5 1.33-9.27 1.33-14.03 0-3.97-.27-7.41-.8-10.85z"/><g fill="#1c4282"><path d="M66.12 130.18c-11.39 2.38-21.7 9-30.18 16.14A78.7 78.7 0 0 0 100 179.15c38.91 0 70.94-28.06 77.56-64.86-15.62 12.71-36.27 27.27-51.36 29.12-27.53 3.18-27.53-20.38-60.08-13.23z"/><path d="M133.09 114.82c3.17 7.94.26 16.68-7.15 19.86-7.15 2.9-15.62-1.06-19.06-8.74-3.17-7.94-.26-16.68 7.15-19.85s15.88.8 19.06 8.73z"/></g></svg>',
    type: 'RATEYOURMUSIC',
  },
];



////////////////////////////////////////////////////////////////////////////////
// 'FROM' SITES

const DEFAULT_FROM_SITES = {
  'headline':       function() {
    return document.querySelector('.header h2');
  },
  'linkbox':        function() {
    return document.querySelector('.linkbox');
  },
  'sidebar_before': function(this_page) {
    return document.querySelector(this_page == 'artist'
                                  ? '.sidebar > .box_search'
                                  : '.sidebar > .box_artists');
  },
  'artist': {
    'artist': function(headline, grab) {
      return headline.textContent;
    },
    'title':  function(headline, grab) {
      return undefined;
    },
  },
  'torrents': {
    'artist': function(headline, grab) {
      return grab(headline,
                  'a[href^="artist.php"]');
    },
    'title':  function(headline, grab) {
      return grab(headline,
                  'span:not(.tooltip)');
    },
  },
  'requests': {
    'artist': function(headline, grab) {
      return grab(headline,
                  'a[href^="artist.php"]');
    },
    'title':  function(headline, grab) {
      return grab(headline,
                  'span:not(.tooltip)');
    },
  },
};

// For each 'from' site, create an object with the following general
// structure, then insert it into FROM_SITES.
//
// As the name suggests, this is just an example for the sake of documenting
// how this part of YAETS works.
const example_from_site = {
  // Because Gazelle sites are mostly pretty similar, not every data retrieval
  // function needs to be re-implemented for every site. If a default function
  // suffices (see DEFAULT_FROM_SITES above), simply include it and don't
  // worry about anything else.
  //
  // The headline, linkbox and sidebar_before functions are (mostly) the same
  // site-wide, so we define them here to avoid a bunch of code duplication.
  //
  // The 'headline' function is used to find the page title from which
  // information is retrieved.
  'headline':       DEFAULT_FROM_SITES['headline'],
  // The 'linkbox' function is used to find the horizontal list below the
  // headline to which search links will be added when 'LINKBOX_ENABLED' is
  // true.
  'linkbox':        DEFAULT_FROM_SITES['linkbox'],
  // The 'sidebar_before' function is used to find the element in the sidebar
  // to which search buttons will be added when 'SIDEBAR_ENABLED' is true.
  'sidebar_before': DEFAULT_FROM_SITES['sidebar_before'],
  // Each page (artist, torrents, and requests) has its own artist and title
  // retrieval functions, because those are generally not the same site-wide.
  'artist': {
    // If a default function /almost/ suffices, call it (passing the headline
    // and grab arguments), then amend the result. In this example, we mangle
    // the artist name a bit just to illustrate the principle.
    'artist':       function(headline, grab) {
      return DEFAULT_FROM_SITES['artist']['artist'](headline,
                                                    grab).replace(/[aeiou]/g,
                                                                  'X');
    },
    'title':        DEFAULT_FROM_SITES['artist']['title'],
  },
  'torrents': {
    'artist':       DEFAULT_FROM_SITES['torrents']['artist'],
    'title':        function(headline, grab) {
      // And sometimes, the default version is just plain wrong, so don't even
      // bother calling it. Instead, we implement a site/page-specific version.
      //
      // 'headline' is the headline element on the page, as returned by the
      // function above.
      //
      // 'grab' is a helper function that returns the contents of the first
      // element within the headline that matches the specified selector.
      return grab(headline,
                  'a[href^="torrents.php"]');
    },
  },
  'requests': {
    'artist':       DEFAULT_FROM_SITES['torrents']['artist'],
    'title':        DEFAULT_FROM_SITES['torrents']['title'],
  },
};

const orpheus_from_site = (function() {
  // Helper function to retrieve artist name from any page type.
  const get_artist = function(this_page, headline, grab) {
    // The default function mostly works.
    let artist = DEFAULT_FROM_SITES[this_page]['artist'](headline,
                                                         grab);
    if (artist) {
      // But we still need to remove the disambiguation suffix.
      artist = artist.replace(/ \([0-9]+\)$/,
                              '');
    }
    else {
      // Various Artists.
      artist = '';
    }
    return artist;
  };
  return {
    'headline':       DEFAULT_FROM_SITES['headline'],
    'linkbox':        DEFAULT_FROM_SITES['linkbox'],
    'sidebar_before': DEFAULT_FROM_SITES['sidebar_before'],
    // Artist test page:
    // - https://orpheus.network/artist.php?id=1510 (normal)
    'artist': {
      'artist':       function(headline, grab) {
        return get_artist('artist', headline, grab);
      },
      'title':        DEFAULT_FROM_SITES['artist']['title'],
    },
    // Torrent group test pages:
    // - https://orpheus.network/torrents.php?id=998008 (VA)
    // - https://orpheus.network/torrents.php?id=1356 (normal)
    'torrents': {
      'artist':       function(headline, grab) {
        return get_artist('torrents', headline, grab);
      },
      'title':        function(headline, grab) {
        return grab(headline,
                    'a[href^="torrents.php"]');
      },
    },
    // Request test pages:
    // - https://orpheus.network/requests.php?action=view&id=49043 (normal)
    // - https://orpheus.network/requests.php?action=view&id=49105 (VA)
    // - https://orpheus.network/requests.php?action=view&id=49069 (linked to group)
    'requests': {
      'artist':       function(headline, grab) {
        return get_artist('requests', headline, grab);
      },
      'title':        function(headline, grab) {
        // Requests that are linked to a torrent group.
        let title = grab(headline,
                         'a[href^="torrents.php"]');
        if (!title) {
          // Requests that aren't.
          const matches = headline.textContent.match(/ – (.*) \[/);
          title = (matches
                   ? matches[1]
                   : null);
        }
        return title;
      },
    },
  };
}());

const redacted_from_site = (function () {
  return {
    'headline':       DEFAULT_FROM_SITES['headline'],
    'linkbox':        DEFAULT_FROM_SITES['linkbox'],
    'sidebar_before': DEFAULT_FROM_SITES['sidebar_before'],
    'artist': {
      // Artist test page:
      // - https://redacted.sh/artist.php?id=48866 (normal)
      'artist':       DEFAULT_FROM_SITES['artist']['artist'],
      'title':        DEFAULT_FROM_SITES['artist']['title'],
    },
    'torrents': {
      // Torrent group test pages:
      // - https://redacted.sh/torrents.php?id=1942500 (normal)
      // - https://redacted.sh/torrents.php?id=1606847 (VA)
      'artist':       function(headline, grab) {
        // The default approach works for normal releases. Custom approach is
        // needed for Various Artists.
        let artist = DEFAULT_FROM_SITES['torrents']['artist'](headline,
                                                              grab);
        if (!artist) {
          artist = '';
        }
        return artist;
      },
      'title':        DEFAULT_FROM_SITES['torrents']['title'],
    },
    'requests': {
      // Request test pages:
      // - https://redacted.sh/requests.php?action=view&id=272220 (normal)
      // - https://redacted.sh/requests.php?action=view&id=272377 (VA)
      'artist':       function(headline, grab) {
        // The default approach works for normal releases. Custom approach is
        // needed for Various Artists.
        let artist = DEFAULT_FROM_SITES['requests']['artist'](headline,
                                                              grab);
        if (!artist) {
          artist = '';
        }
        return artist;
      },
      'title':        DEFAULT_FROM_SITES['requests']['title']
    },
  };
}());

const deepbassnine_from_site = {
  'headline':       function() {
    return document.querySelector('.thin h2');
  },
  'linkbox':        DEFAULT_FROM_SITES['linkbox'],
  'sidebar_before': DEFAULT_FROM_SITES['sidebar_before'],
  'artist': {
    'artist':       DEFAULT_FROM_SITES['artist']['artist'],
    'title':        DEFAULT_FROM_SITES['artist']['title'],
  },
  'torrents': {
    // Single artist:
    // <span dir="ltr"><a href="artist.php?id=1">Artist</a> - Album</span> [Catno] [Year] [Type]
    // Main artist with guest:
    // <span dir="ltr"><a href="artist.php?id=1>Artist</a> with <a href="artist.php?id=2">Guest</a> - Album</span> [Catno] [Year] [Type]
    // Dual main artists:
    // <span dir="ltr"><a href="artist.php?id=1>Artist</a> & <a href="artist.php?id=2">Artist</a> - Album</span> [Catno] [Year] [Type]
    // Dual main artists with guest:
    // <span dir="ltr"><a href="artist.php?id=1>Artist</a> & <a href="artist.php?id=2">Artist</a> with <a href="artist.php?id=3">Guest</a> - Album</span> [Catno] [Year] [Type]
    // VA:
    // <span dir="ltr">Various Artists - Album</span> [Catno] [Year] [Type]
    'artist':       function(headline, grab) {
      const artist = DEFAULT_FROM_SITES['torrents']['artist'](headline,
                                                              grab);
      return artist || '';
    },
    'title':        function(headline, grab) {
      // Works for single, dual, single with guest and dual with guest torrent
      // groups. If it fails, assume it's a VA group.
      const artist = headline.querySelector('a[href^="artist.php"]:last-of-type');
      if (artist) {
        return artist.nextSibling.textContent.replace(/^ *- */,
                                                      '');
      }
      else {
        return headline.firstChild.textContent.replace(/^Various Artists *- */,
                                                       '');
      }
    },
  },
  'requests': {
    // Single artist linked to group:
    // <a href="requests.php">Requests</a> > Music > <a href="artist.php?id=1">Artist</a> - <a href="torrents.php?torrentid=1">Album</a> [1900]
    // Main artist with guest not linked to group:
    // <a href="requests.php">Requests</a> > Music > <a href="artist.php?id=1">Artist</a> with <a href="artist.php?id=2">Guest</a> - Album [1900]
    // Dual main artists linked to group:
    // <a href="requests.php">Requests</a> > Music > <a href="artist.php?id=1">Artist</a> & <a href="artist.php?id=2">Artist</a> - <a href="torrents.php?torrentid=1">Album</a> [1900]
    // VA linked to group:
    // <a href="requests.php">Requests</a> > Music > Various Artists - <a href="torrents.php?torrentid=1">Album</a> [Year]
    // VA not linked to group(???):
    // <a href="requests.php">Requests</a> > Music > Various Artists - Album [Year]
    'artist':       function(headline, grab) {
      const artist = DEFAULT_FROM_SITES['requests']['artist'](headline,
                                                              grab);
      return artist || '';
    },
    'title':        function(headline, grab) {
      // Works for requests that are linked to a torrent group.
      const group = headline.querySelector('a[href^="torrents.php?]');
      if (group) {
        return group.textContent;
      }
      else {
        // Works for non-VA requests that are not linked to a torrent group.
        const artists = headline.querySelectorAll('a[href^="artist.php"]');
        if (artists.length > 0) {
          const artist = artists[artists.length - 1];
          return artist.nextSibling.textContent.replace(/^ *- */,
                                                        '').replace(/ *\[[0-9]+\]$/,
                                                                    '');
        }
        else {
          // Works for VA requests that are not linked to a torrent group.
          return headline.textContent.replace(/^ *Requests *> *Music *> *Various Artists *- */,
                                              '').replace(/ *\[[0-9]+\]$/,
                                                          '');
        }
      }
    },
  },
};

const animebytes_from_site = {
  // NOTE: AB support is untested. Support welcome!
  'headline':       function() {
    return document.querySelector('.thin h2');
  },
  'linkbox':        function() {
    let linkbox = DEFAULT_FROM_SITES['linkbox']();
    if (!linkbox) {
      console.error(`There is no linkbox on request pages on AnimeBytes!`);
      // TODO: create one?
    }
    return linkbox;
  },
  'sidebar_before': function(this_page) {
    let before = DEFAULT_FROM_SITES['sidebar_before'](this_page);
    if (!before) {
      console.error(`There is no sidebar on request pages on AnimeBytes!`);
      // TODO: create one?
    }
    return before;
  },
  'artist': {
    'artist':       function(headline, grab) {
      return grab(headline,
                  '[href^="/artist.php"]');
    },
    'title':        DEFAULT_FROM_SITES['artist']['title'],
  },
  // The AB torrent group page has a different name.
  'torrents2': {
    'artist':       function(headline, grab) {
      return grab(headline,
                  'a[href^="/artist.php"]');
    },
    'title':        DEFAULT_FROM_SITES['torrents']['title'],
  },
  'requests': {
    'artist':       function(headline, grab) {
      return grab(headline,
                  'a[href^="/artist.php"]');
    },
    'title':        function(headline, grab) {
      const lastIndex = headline.childNodes.length - 1;
      const matches = headline.childNodes[lastIndex].textContent.match(/-\n\s*(.*) \[/);
      return (matches
              ? matches[1]
              : null);
    },
  },
};

// Functions from this object are used to extract data from the site you're
// browsing from, to build URLs of places to search on.
const FROM_SITES = {
  // Always use the second level domain name as the key, ie. 'example.com',
  // not 'foo.example.com'.
  'orpheus.network':       orpheus_from_site,
  'redacted.sh':          redacted_from_site,
  'deepbassnine.com': deepbassnine_from_site,
  'animebytes.tv':      animebytes_from_site,
  // 'example.com':        example_from_site,
};



////////////////////////////////////////////////////////////////////////////////
// CODE

const show_configuration_window = function(event) {
  alert('Sneaky sneaky, messing around with the code like this!\n\nWIP, stay tuned...');
  // TODO: Implement configuration window.
};

if (!document.querySelector('style.com.yaets')) {
  // Gather data.
  const this_domain = window.location.hostname.match(/[^.]+\.[^.]+$/)[0];
  const this_prefix = `${window.location.protocol}//${this_domain}`;
  const this_page   = window.location.pathname.match(/\/(.*)\.php/)[1];

  const get_from_site = function(key,
                                 ...arguments) {
    try {
      return FROM_SITES[this_domain][key](...arguments);
    }
    catch (error) {
      console.error(`Failed to retrieve value of ${key} on site ${this_domain}: ${error}`);
      return undefined;
    }
  };
  const headline       = get_from_site('headline');
  const linkbox        = get_from_site('linkbox');
  const sidebar_before = get_from_site('sidebar_before',
                                       this_page);

  const encode = function(text) {
    return encodeURIComponent(text);
  };
  const get_from_page = function(key) {
    const grab = function(headline,
                          selector) {
      const el = headline.querySelector(selector);
      return (el
              ? el.textContent
              : null);
    };
    try {
      return FROM_SITES[this_domain][this_page][key](headline,
                                                     grab);
    }
    catch (error) {
      console.error(`Failed to retrieve value of ${key} on page ${this_page}: ${error}`);
      return '';
    }
  };
  const data = {
    artist:    encode(get_from_page('artist')),
    title:     encode(get_from_page('title')),
    artist_id: `${discogs_artist_id}`,
  };

  // Create links.
  const buildUrl = function(site) {
    const paths = (this_page === 'artist'
                   ? ARTIST_PATHS
                   :  ALBUM_PATHS);
    const template = `${site.prefix}${paths[site.type]}`;
    const transform = site.transform_function || function(data) {
      return data.replace(/%20/g,
                          '+');
    };
    return template.replace(/\{([^}]+)\}/g,
                            function(match,
                                     key) {
                              return transform(data[key]);
    });
  };
  const my_search_sites = ENABLED.map(function(site_name) {
    return SEARCH_SITES.find(function(site) {
      return site.name === site_name;
    });
  }).map(function(site) {
    // 2023-04-19: attempt to construct prefix from domain. Deprecated.
    if (!site.prefix && site.domain) {
      site.prefix = `https://${site.domain}`;
    }
    return site;
  }).filter(function(site) {
    return this_prefix !== site.prefix;
  });
  if (LINKBOX_ENABLED) {
    if (linkbox) {
      if (REFLOW_LINKBOX) {
        linkbox.classList.add('com',
                              'reflow');
      }
      my_search_sites.forEach(function(site) {
        if (site[this_page] !== false) {
          const a = document.createElement('a');
          a.href = buildUrl(site);
          a.target = '_blank';
          a.title = `Search on ${site.name}`;
          a.classList.add('brackets',
                          'com',
                          'yaets',
                          'linkbox-link');
          a.innerHTML = site.tag;
          linkbox.appendChild(a);
        }
      });

      const a = document.createElement('a');
      a.title = 'YAETS configuration';
      a.innerHTML = '⚙';
      a.classList.add('brackets',
                      'com',
                      'yaets',
                      'linkbox-link',
                      'config-button');
      a.addEventListener('click',
                         show_configuration_window);
      linkbox.appendChild(a);
    }
    else {
      console.error(`Linkbox not found! Can't add YAETS entries to it.`);
    }
  }

  if (SIDEBAR_ENABLED) {
    if (sidebar_before) {
      const abbr = document.createElement('abbr');
      abbr.innerHTML = 'YAETS';
      abbr.title = 'Yet Another External Tracker Searcher';

      const strong = document.createElement('strong');
      strong.appendChild(abbr);

      const a = document.createElement('a');
      a.classList.add('com',
                      'yaets',
                      'config-button');
      a.innerHTML = '⚙';
      a.title = 'YAETS configuration';
      a.addEventListener('click',
                         show_configuration_window);

      const head = document.createElement('div');
      head.classList.add('head',
                         'com',
                         'yaets',
                         'sidebar-header');
      head.appendChild(strong);
      head.appendChild(a);

      const body = document.createElement('div');
      body.classList.add('body',
                         'com',
                         'yaets',
                         'sidebar-body');

      const box = document.createElement('div');
      box.classList.add('box',
                        'com',
                        'yaets',
                        'sidebar-box');
      box.appendChild(head);
      box.appendChild(body);

      my_search_sites.forEach(function(site) {
        if (site[this_page] !== false) {
          const a = document.createElement('a');
          a.href = buildUrl(site);
          a.classList.add('com',
                          'yaets',
                          'sidebar-link');
          a.target = '_blank';
          a.title = `Search on ${site.name}`;

          const img = (function() {
            if (site.icon.startsWith('<svg')) {
              a.innerHTML = site.icon;
              return a.firstChild;
            }
            else {
              const img = document.createElement('img');
              img.src = site.icon;
              a.appendChild(img);
              return img;
            }
          }());
          img.alt = `Search on ${site.name}`;
          img.classList.add('com',
                            'yaets',
                            'sidebar-icon');

          body.appendChild(a);
        }
      });
      sidebar_before.parentNode.insertBefore(box,
                                             sidebar_before);
    }
    else {
      console.error(`Sidebar not found! If this is a non-music page, this is expected behaviour. Otherwise, it's a bug.`);
    }
  }

  const style = document.createElement('style');
  style.classList.add('com',
                      'yaets');
  style.innerHTML = `
  /* Styles for Orpheus & Redacted: External Tracker Search. */
.com.yaets.sidebar-header {
  display: flex;
}
.com.yaets.sidebar-header > strong {
  flex: 1 0 auto;
}
.com.yaets.config-button {
  display: none;
}
.com.yaets.config-button {
  cursor: pointer;
}
.header.linkbox.com.reflow,
.com.yaets.sidebar-body {
  display: flex;
  justify-content: space-around;
  flex-wrap: wrap;
}
.com.yaets.sidebar-link {
  width: calc(${100 / Math.min(ENABLED.length,
                               SIDEBAR_ICONS_PER_LINE)}% - 5px);
  padding-bottom: 5px;
}
.com.yaets.sidebar-icon {
  border: none;
}
/* Not all Gazelle sites include the next 3 rules in their default CSS. */
.brackets {
  text-indent: 0;
  white-space: nowrap;
}
.brackets::after {
  content: "]";
}
.brackets::before {
  content: "[";
}
`;
  document.querySelector('title').insertAdjacentElement('afterend',
                                                        style);
}