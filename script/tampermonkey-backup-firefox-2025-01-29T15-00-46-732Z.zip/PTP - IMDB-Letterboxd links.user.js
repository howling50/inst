// ==UserScript==
// @name         PTP - IMDB/Letterboxd links
// @version      2023-12-20
// @description  Add links for imdb & letterboxd to top of page
// @match        https://passthepopcorn.me/torrents.php?*
// ==/UserScript==

(function() {
    'use strict';

    const imdbLink = document.querySelector('#imdb-title-link');
    const imdbMatch = (imdbLink.href || '').match('/(tt[0-9]+)/');
    if ( imdbMatch ) {
        const titleEl = document.querySelector('.page__title');
        const spanEl = document.createElement('span');
        titleEl.insertBefore(spanEl, titleEl.firstChild);

        const linkStyle = 'font-size: 8pt; font-weight: normal; margin-right: 3px;';

        spanEl.innerHTML = ''
            +`<a href="https://imdb.com/title/${imdbMatch[1]}" noreferer="true" style="${linkStyle}">[IMDb]</a>`
            +`<a href="https://letterboxd.com/imdb/${imdbMatch[1]}" noreferer="true" style="${linkStyle}">[Letterboxd]</a>`;
    }
})();