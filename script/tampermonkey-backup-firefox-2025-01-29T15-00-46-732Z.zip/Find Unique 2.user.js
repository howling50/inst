// ==UserScript==
// @name         Find Unique 2
// @namespace    http://tampermonkey.net/
// @version      3.31
// @description  Find unique titles from other trackers
// @author       passthepopcorn_cc
// @match        https://cinemageddon.net/browse.php*
// @match        https://karagarga.in/browse.php*
// @match        https://hdbits.org/browse.php*
// @match        https://passthepopcorn.me/torrents.php*
// @match        https://passthepopcorn.me/torrents.php?type=seeding
// @match        https://filelist.io/internal.php*
// @match        https://filelist.io/browse.php*
// @match        https://beyond-hd.me/library/movies*
// @match        https://beyond-hd.me/meta*
// @match        https://beyond-hd.me/torrents*
// @match        https://cinemaz.to/movies*
// @match        https://avistaz.to/movies*
// @match        https://blutopia.cc/torrents*
// @match        https://www.torrentleech.org/torrents/browse*
// @match        https://tntracker.org/moviewall*
// @match        https://anthelion.me/torrents.php*
// @icon         https://www.google.com/s2/favicons?domain=karagarga.in
// @grant        GM_xmlhttpRequest
// ==/UserScript==

(function() {
    'use strict';


    /******************************************************************************/

    let only_show_unique_titles = false // change to true if you wish
    let better_constant = 1.15 // you can change this too.. wouldn't recommend going below 1.05






    /******************************************************************************/



    const URL = window.location.href


    function insertBefore(newNode, existingNode) {
        try {
            existingNode.parentNode.insertBefore(newNode, existingNode);
        } catch(e) {
            // console.log("Error adding node")
        }
    }


    const query_and_filter = (tracker, mov, i) => {

        const myTimeout = setTimeout(() => {


            // No IMDB ID case
            if (mov.imdb_id === "") {

                if (mov.dom_path != undefined) mov.dom_path.style.display = "none"
                else mov.dom_paths.forEach(d => { d.style.display = "none" })

                if ((i+1) > parseInt(document.querySelector(".checked_count").textContent)) document.querySelector(".checked_count").textContent = i+1
                return false
            }


            let query_url

            if (tracker === "PTP") {
                query_url = "https://passthepopcorn.me/torrents.php?imdb=" + mov.imdb_id
            }

            else if (tracker === "ANT") {
                query_url = "https://anthelion.me/torrents.php?imdb=" + mov.imdb_id
            }

            else if (tracker === "HDB") {
                //query_url = "https://hdbits.org/browse.php?c3=1&c1=1&c2=1&tagsearchtype=or&imdb=" + mov.imdb_id + "&sort=size&h=8&d=DESC"
                query_url = "https://hdbits.org/browse.php?c3=1&c8=1&c1=1&c4=1&c5=1&c2=1&c7=1&descriptions=0&season_packs=0&from=&to=&imdbgt=0&imdblt=10&imdb=" + mov.imdb_id + "&sort=size&h=8&d=DESC"
            }

            else if (tracker === "BHD") {
                query_url = "https://beyond-hd.me/library/movies?activity=&q=" + mov.imdb_id
            }

            else if (tracker === "BLU") {
                query_url = "https://blutopia.cc/torrents?perPage=25&imdbId=" + mov.imdb_id + "&sortField=size"
            }

            else if (tracker === "AvistaZ") {
                query_url = "https://avistaz.to/movies?search=&imdb=" + mov.imdb_id
            }

            else if (tracker === "CinemaZ") {
                query_url = "https://cinemaz.to/movies?search=&imdb=" + mov.imdb_id
            }

            else if (tracker === "FL") {
                query_url = "https://filelist.io/browse.php?search=" + mov.imdb_id + "&cat=0&searchin=1&sort=3"
            }

            else if (tracker === "CG") {
                query_url = "https://cinemageddon.net/browse.php?search=" + mov.imdb_id + "&orderby=size&dir=DESC"
            }

            else if (tracker === "KG") {
                query_url = "https://karagarga.in/browse.php?sort=size&search=" + mov.imdb_id + "&search_type=imdb&d=DESC"
            }



            GM_xmlhttpRequest({
                url : query_url,
                method : "GET",
                timeout: 10000,
                onload : function(response) {
                    if (response.status == 200) {

                        if ((i+1) > parseInt(document.querySelector(".checked_count").textContent)) document.querySelector(".checked_count").textContent = i+1

                        const parser = new DOMParser();
                        const result = parser.parseFromString(response.responseText, "text/html").body; /******* HTML FILE *******/

                        let movie_exist = is_movie_exist(tracker, result)


                        if (movie_exist === false) {
                            document.querySelector(".new_content_count").textContent = parseInt(document.querySelector(".new_content_count").textContent)+1
                            return true // don't hide, can be uploaded
                        }

                        else { // movie exist (not sure about exact size yet)
                            if (only_show_unique_titles === true) {
                                mov.dom_path.style.display = "none"
                                return false
                            }

                            let highest_size = get_highest_size(tracker, result)
                            if (mov.size < (highest_size * better_constant)) { // size is not 'much' bigger
                                if (mov.dom_path != undefined) mov.dom_path.style.display = "none"
                                else mov.dom_paths.forEach(d => { d.style.display = "none" })
                                return false
                            }

                            else {
                                document.querySelector(".new_content_count").textContent = parseInt(document.querySelector(".new_content_count").textContent)+1
                                return true // torrent exist, but its bad quality in PTP
                            }
                        }


                    } else {
                        console.log(" Error: HTTP " +response.status+ " Error.");
                    }
                },
                onerror: function() {
                    console.log("Error: Request Error.");
                },
                onabort: function() {
                    console.log("Error: Request is aborted.");
                },
                ontimeout: function() {
                    console.log("Error: Request timed out.");
                }
            });
        }
                                     , 2500 * i);
    }


    const is_movie_exist = (tracker, html) => { // true or false

        if (tracker === "PTP") {
            if (html.querySelector("#no_results_message > div") === null) return true
            else return false
        }

        else if (tracker === "ANT") {
            if (html.querySelector(".torrents_nomatch")) return false
            else return true
        }

        else if (tracker === "HDB") {
            if (html.querySelector("#resultsarea").textContent.includes("Nothing here!")) return false
            else return true
        }

        else if (tracker === "BHD") {
            if (html.querySelectorAll(".bhd-meta-box").length === 0) return false
            else return true
        }

        else if (tracker === "BLU") {
            if (html.querySelector(".torrent-listings-no-result") === null) return true
            else return false
        }

        else if (tracker === "AvistaZ") {
            if (html.querySelector("#content-area > div.block > p") === null) return true
            else return false
        }

        else if (tracker === "CinemaZ") {
            if (html.querySelector("#content-area > div.block > p") === null) return true
            else return false
        }

        else if (tracker === "FL") {
            if (html.querySelectorAll(".torrentrow").length === 0) return false
            else return true
        }

        else if (tracker === "CG") {
            let ar1 = [...html.querySelectorAll("tr.prim")]
            let ar2 = [...html.querySelectorAll("tr.sec")]
            let ar3 = [...html.querySelectorAll("tr.torrenttable_usersnatched")]

            let combined_arr = ar1.concat(ar2).concat(ar3)

            if (combined_arr.length > 0) return true // might update later
            else return false
        }

        else if (tracker === "KG") {
            if (html.querySelector("tr.oddrow") === null) return false // might update later
            else return true
        }

    }


    const get_highest_size = (tracker, html) => {

        if (tracker === "PTP") {

            let sizes = []

            html.querySelectorAll(".group_torrent").forEach((d) => {

                let text = [...d.querySelectorAll("span")].find(s => s.title.includes(" bytes"))
                try {

                    let size = Math.floor(parseInt(text.title.split(" bytes")[0].replace(/,/g, ""))/1024/1024)
                    sizes.push(size)
                }
                catch(e) {}

            })

            let max_size = sizes.sort((a,b) => a<b ? 1 : -1 )[0] // MB

            return max_size
        }

        else if (tracker === "ANT") {
            let sizes = []

            html.querySelectorAll(".group_torrent").forEach((d) => {

                let text = d.querySelector(".number_column.nobr").textContent

                try {
                    let size
                    if (text.includes("GiB")) {
                        size = Math.floor(parseInt(text.split(" ")[0])*1024)
                    } else if (text.includes("MiB")) {
                        size = Math.floor(parseInt(text.split(" ")[0]))
                    } else if (text.includes("KiB")) {
                        size = Math.floor(parseInt(text.split(" ")[0])/1024)
                    } else if (text.includes("TiB")) {
                        size = Math.floor(parseInt(text.split(" ")[0])*1024*1024)
                    }
                    sizes.push(size) // Float MiB value
                }
                catch(e) {}

            })

            let max_size = sizes.sort((a,b) => a<b ? 1 : -1 )[0] // MB
            return max_size
        }

        else if (tracker === "HDB") {

            let max_size

            let size = html.querySelector("#torrent-list > tbody > tr").querySelectorAll("td")[5].textContent

            if (size.includes("GiB")) {
                max_size = parseInt(parseFloat(size.split("GiB")[0])*1024) // MB
            }

            else if (size.includes("MiB")) max_size = parseInt(parseFloat(size.split("MiB")[0]))

            return max_size

        }

        else if (tracker === "BHD") {

            const get_beyond_size = (d) => {

                if (d === undefined) return 0

                let size = [...d.querySelectorAll("tr.bhd-sub-header-compact")].map((tr) => {

                    if ([...tr.querySelectorAll("td")].length === 1) return "0 MiB"
                    else return [...tr.querySelectorAll("td")].find(e => e.textContent.includes(" GiB") || e.textContent.includes(" MiB")).textContent

                }).map((e) => {

                    if (e.includes(" GiB")) {
                        return parseInt(parseFloat(e.split("GiB")[0])*1024) // MB
                    }

                    else if (e.includes(" MiB")) {
                        return parseInt(parseFloat(e.split("MiB")[0]))
                    }

                }).sort((a,b) => a < b ? 1 : -1)[0]

                return size

            }

            return get_beyond_size(html.querySelectorAll(".bhd-meta-box")[0])

        }

        else if (tracker === "BLU") {

            let max_size
            let size = html.querySelector(".torrent-search--list__results > tbody > tr").querySelectorAll("td")[5].textContent.trim()

            if (size.includes("GiB")) {
                max_size = parseInt(parseFloat(size.split(" ")[0])*1024) // MB
            }

            else if (size.includes("MiB")) max_size = parseInt(parseFloat(size.split(" ")[0]))

            return max_size


        }

        else if (tracker === "AvistaZ") {
            return 999999
        }

        else if (tracker === "CinemaZ") {
            return 999999
        }

        else if (tracker === "FL") {

            let max_size

            let size = [...html.querySelector(".torrentrow").querySelectorAll("font")].find((d) => {
                return (d.textContent.includes("[") === false) && (d.textContent.includes("GB") || d.textContent.includes("MB"))
            }).textContent


            if (size.includes("GB")) {
                max_size = parseInt(parseFloat(size.split("GB")[0])*1024) // MB
            }

            else if (size.includes("MB")) max_size = parseInt(parseFloat(size.split("MB")[0]))

            return max_size


        }

        else if (tracker === "CG") {

            let max_size

            let current_torrent_row = html.querySelector("tr.prim")

            let size = current_torrent_row.querySelector("td:nth-child(5)").textContent

            if (size.includes("GB")) {
                max_size = parseInt(parseFloat(size.split(" ")[0])*1024) // MB
            }

            else if (size.includes("MB")) max_size = parseInt(parseFloat(size.split(" ")[0]))

            return max_size

        }

        else if (tracker === "KG") {

            let max_size
            let size = html.querySelector("#browse > tbody").querySelectorAll("tr")[1].querySelector("td:nth-child(11)").textContent.replace(",","")

            if (size.includes("GB")) {
                max_size = parseInt(parseFloat(size.split("GB")[0])*1024) // MB
            }
            else if (size.includes("MB")) max_size = parseInt(parseFloat(size.split("MB")[0]))

            return max_size


        }

    }


    const add_counter = () => {
        let div = document.createElement("div")
        div.className = "counter_div"
        div.innerHTML = "Checked: <span class=\"checked_count\">0</span>/<span class=\"total_torrents_count\">0</span> | New content: <span class=\"new_content_count\">0</span>"
        div.style.padding = "9px 26px"
        div.style.position = "fixed"
        div.style.top = "50px"
        div.style.right = "50px"
        div.style.background = "#eaeaea"
        div.style.borderRadius = "9px"
        div.style.fontSize = "17px"
        div.style.color = "#111"
        div.style.cursor = "pointer"
        div.style.border = "2px solid #111"
        div.style.display = "none"
        div.style.zIndex = "4591363"

        div.addEventListener("click", () => { div.style.display="none" })
        document.body.appendChild(div)
    }

    add_counter()


    let select_trackers = ["Find unique for...", "ANT", "AvistaZ", "BHD", "BLU", "CG", "CinemaZ", "FL", "HDB", "KG", "PTP"]


    if (URL.includes("hdbits.org")) {

        let movie_objects = []

        const add_select_options = () => {

            select_trackers = select_trackers.filter(e => e != "HDB")

            let select_dom = document.createElement("select")
            for (var i = 0; i<select_trackers.length; i++){
                var opt = document.createElement('option');
                opt.value = select_trackers[i]
                opt.innerHTML = select_trackers[i];
                select_dom.appendChild(opt);
            }

            select_dom.addEventListener("change", () => {
                let answer = confirm("Start searching new content for:  " + select_dom.value)
                if (answer) {
                    document.querySelector(".counter_div").style.display = "block"
                    generateMovieObjects(select_dom.value)
                }

            })

            document.querySelector("#moresearch3 > td:nth-child(2)").innerHTML += "<br><br>Find unique for:<br>"
            document.querySelector("#moresearch3 > td:nth-child(2)").appendChild(select_dom)

        }

        const generateMovieObjects = (tracker) => {

            // target
            // {"dom_path":"", "imdb_id":"", "size":""}

            document.querySelector("#torrent-list > tbody").querySelectorAll("tr").forEach((tr) => {
                let dom_path = tr
                let imdb_id = ""
                try {
                    let id_text = [...tr.querySelectorAll("a")].find(a => a.textContent.includes("IMDB:")).href.split("?id=")[1].trim()
                    if (id_text.length === 5) id_text = "00" + id_text
                    else if (id_text.length === 6) id_text = "0" + id_text
                    imdb_id = "tt" + id_text
                } catch(e) {}

                let size = tr.querySelector("td:nth-child(6)").textContent

                if (size.includes("GiB")) {
                    size = parseInt(parseFloat(size.split("GiB")[0])*1024) // MB
                }
                else if (size.includes("MiB")) size = parseInt(parseFloat(size.split("MiB")[0]))


                movie_objects.push({dom_path, imdb_id, size})


            })

            document.querySelector(".total_torrents_count").textContent = movie_objects.length
            for (let i=0; i<movie_objects.length;i++) query_and_filter(tracker, movie_objects[i], i)

        }


        add_select_options()

    }

    else if (URL.includes("passthepopcorn.me")) {

        let movie_objects = []

        const add_select_options = () => {

            select_trackers = select_trackers.filter(e => e != "PTP")

            let select_dom = document.createElement("select")
            select_dom.style.margin = "0 5px"

            for (var i = 0; i<select_trackers.length; i++){
                var opt = document.createElement('option');
                opt.value = select_trackers[i]
                opt.innerHTML = select_trackers[i];
                select_dom.appendChild(opt);
            }

            select_dom.addEventListener("change", () => {
                let answer = confirm("Start searching new content for:  " + select_dom.value)
                if (answer) {
                    document.querySelector(".counter_div").style.display = "block"
                    generateMovieObjects(select_dom.value)
                }
            })


            insertBefore(select_dom, document.querySelector(".search-form__footer__buttons"))

        }

        const generateMovieObjects = (tracker) => {

            // hedef
            // {"dom_path":"", "imdb_id":"", "size":""}


            // for user seeding page
            if (URL.includes("type=seeding")) {

                document.querySelector("tbody.js-basic-movie-list__table-body").querySelectorAll("tr.basic-movie-list__details-row").forEach((d, idx) => {


                    let imdb_id = ""

                    try {
                        imdb_id = [...d.querySelector(".basic-movie-list__movie__ratings-and-tags").querySelectorAll("a")].find(a => a.href.includes("imdb.com")).href.split("/title/")[1].replace("/","")
                    } catch(e) {}


                    let size = document.querySelectorAll("tr.basic-movie-list__torrent-row")[idx].querySelectorAll("td")[2].textContent.trim()

                    if (size.includes("GiB")) {
                        size = parseInt(parseFloat(size.split(" ")[0])*1024) // MB
                    }
                    else if (size.includes("MiB")) size = parseInt(parseFloat(size.split(" ")[0]))


                    let dom_paths = [d, document.querySelectorAll(".basic-movie-list__torrent-row--user-seeding")[idx]] // 1 movie için 2 dom var

                    movie_objects.push({dom_paths, imdb_id, size})

                })

            }

            // for browse page
            else {
                let sc = [...document.querySelectorAll("script")].find(s => s.textContent.includes("PtpGlobalData") || s.textContent.includes("ungroupedCoverViewJsonData") || s.textContent.includes("coverViewJsonData"))
                let str = sc.textContent.split("PageData = ")[1].split("\"AuthKey\":")[0]
                var pos = str.lastIndexOf(',');
                str = str.substring(0,pos) + "}" + str.substring(pos+1)
                let movies = JSON.parse(str).Movies;
                //document.querySelector(".torrent_table").querySelectorAll("tbody").forEach((d) => { --> Old HTML selector
                document.querySelectorAll("#torrents-movie-view .cover-movie-list__container .cover-movie-list__movie").forEach((d,i) => {

                    let dom_path = d
                    let imdb_id = ""

                    try {
                        //imdb_id = [...d.querySelector(".basic-movie-list__movie__ratings-and-tags").querySelectorAll("a")].find(a => a.href.includes("imdb.com")).href.split("/title/")[1].replace("/","") --> Old HTML selector
                        imdb_id = [...d.querySelector(".cover-movie-list__movie__rating-and-tags").querySelectorAll("a")].find(a => a.href.includes("imdb.com")).href.split("/title/")[1].replace("/","")
                    } catch(e) {}

                    // let size = [...d.querySelectorAll("td")].find(e => e.textContent.includes(" (Max)")).textContent --> Old HTML selector
                    let size = movies[i].MaxSize

                    if (size.includes("GiB")) {
                        size = parseInt(parseFloat(size.split(" ")[0])*1024) // MB
                    }
                    else if (size.includes("MiB")) size = parseInt(parseFloat(size.split(" ")[0]))
                    movie_objects.push({dom_path, imdb_id, size})
                })
            }
            document.querySelector(".total_torrents_count").textContent = movie_objects.length
            for (let i=0; i<movie_objects.length;i++) query_and_filter(tracker, movie_objects[i], i)
        }

        add_select_options()

    }

    else if (URL.includes("beyond-hd.me")) {


        let movie_objects = []

        const add_select_options = () => {

            select_trackers = select_trackers.filter(e => e != "BHD")

            let select_dom = document.createElement("select")
            select_dom.style.width = "163px"
            select_dom.style.color = "#eaeaea"
            select_dom.style.padding = "4px"
            select_dom.style.fontSize = "15px"
            select_dom.style.borderRadius = "2px"

            for (var i = 0; i<select_trackers.length; i++){
                var opt = document.createElement('option');
                opt.value = select_trackers[i]
                opt.innerHTML = select_trackers[i];
                select_dom.appendChild(opt);
            }

            select_dom.addEventListener("change", () => {
                let answer = confirm("Start searching new content for:  " + select_dom.value)
                if (answer) {
                    document.querySelector(".counter_div").style.display = "block"
                    generateMovieObjects(select_dom.value)
                }
            })

            insertBefore(select_dom, document.querySelector(".button-center"))

        }

        const generateMovieObjects = (tracker) => {

            // target
            // {"dom_path":"", "imdb_id":"", "size":""}

            // /movies page
            if (window.location.href.includes("/movies")) {
                document.querySelectorAll(".bhd-meta-box").forEach((d) => {

                    let dom_path = d
                    let imdb_id = ""

                    try {
                        imdb_id = [...d.querySelectorAll("a")].find(a => a.href.includes("imdb")).href.split("/title/")[1].trim()
                    } catch(e) {}

                    let size = get_beyond_size(d)

                    movie_objects.push({dom_path, imdb_id, size})

                })
            }

            // /torrents page
            else if (window.location.href.includes("/torrents")) {
                [...document.querySelector(".table-torrents tbody").querySelectorAll("tr")].filter(e=>!e.id.includes("hidden")).forEach((d,i) => {
                    let dom_path = d
                    let library = d.getAttribute("library")
                    let imdb_id = ""
                    try {
                        let found_library = [...document.querySelectorAll(".librarydiv")].find(e=>e.getAttribute("library")===library)
                        if (found_library) {
                            imdb_id = [...found_library.querySelectorAll("a")].find(a => a.href.includes("imdb")).href.split("/title/")[1].trim()
                        } else {
                            // console.log("No library/IMDB found")
                        }
                    } catch(e) {}

                    let size = null
                    let size_text = d.querySelector("span.text-size").textContent.trim()

                    if (size_text.includes(" GiB")) {
                        size = parseInt(parseFloat(size_text.split("GiB")[0])*1024) // MB
                    }

                    else if (size_text.includes(" MiB")) {
                        size = parseInt(parseFloat(size_text.split("MiB")[0]))
                    }

                    movie_objects.push({dom_path, imdb_id, size})

                })

            }

            // console.log("Movie objects are created.")
            // console.log(movie_objects)

            document.querySelector(".total_torrents_count").textContent = movie_objects.length
            for (let i=0; i<movie_objects.length;i++) query_and_filter(tracker, movie_objects[i], i)

        }


        const get_beyond_size = (d) => {

            let size = [...d.querySelectorAll("tr.bhd-sub-header-compact")].map((tr) => {

                if ([...tr.querySelectorAll("td")].length === 1) return "0 MiB"
                else return [...tr.querySelectorAll("td")].find(e => e.textContent.includes(" GiB") || e.textContent.includes(" MiB")).textContent

            }).map((e) => {

                if (e.includes(" GiB")) {
                    return parseInt(parseFloat(e.split("GiB")[0])*1024) // MB
                }

                else if (e.includes(" MiB")) {
                    return parseInt(parseFloat(e.split("MiB")[0]))
                }

            }).sort((a,b) => a < b ? 1 : -1)[0]

            return size
        }

        add_select_options()
    }

    else if (URL.includes("karagarga.in")) {

        let movie_objects = []

        const add_select_options = () => {

            select_trackers = select_trackers.filter(e => e != "KG")

            let select_dom = document.createElement("select")
            for (var i = 0; i<select_trackers.length; i++){
                var opt = document.createElement('option');
                opt.value = select_trackers[i]
                opt.innerHTML = select_trackers[i];
                select_dom.appendChild(opt);
            }

            select_dom.addEventListener("change", () => {
                let answer = confirm("Start searching new content for:  " + select_dom.value)
                if (answer) {
                    document.querySelector(".counter_div").style.display = "block"
                    generateMovieObjects(select_dom.value)
                }
            })

            insertBefore(select_dom, document.getElementById("showdead"))

        }

        const generateMovieObjects = (tracker) => {

            // target
            // {"dom_path":"", "imdb_id":"", "size":""}

            document.querySelector("#browse > tbody").querySelectorAll("tr").forEach((d) => {

                let dom_path = d
                let imdb_id = ""

                let links_container = d.querySelector("td:nth-child(2) > div > span:nth-child(1)")
                if (links_container === null) return

                try {
                    imdb_id = "tt" + links_container.querySelector("a").href.split("/tt")[1].replace("/", "").trim()
                } catch(e) {}


                let size = d.querySelector("td:nth-child(11)").textContent.replace(",","")

                if (size.includes("GB")) {
                    size = parseInt(parseFloat(size.split("GB")[0])*1024) // MB
                }
                else if (size.includes("MB")) size = parseInt(parseFloat(size.split("MB")[0]))

                movie_objects.push({size, imdb_id, dom_path})
            })
            document.querySelector(".total_torrents_count").textContent = movie_objects.length
            for (let i=0; i<movie_objects.length;i++) query_and_filter(tracker, movie_objects[i], i)
        }


        add_select_options()

    }

    else if (URL.includes("cinemaz.to")) {


        let movie_objects = []

        const add_select_options = () => {

            select_trackers = select_trackers.filter(e => e != "CinemaZ")

            let select_dom = document.createElement("select")
            select_dom.style.marginLeft = "16px"
            select_dom.style.padding = "2px 2px 3px 2px"

            for (var i = 0; i<select_trackers.length; i++){
                var opt = document.createElement('option');
                opt.value = select_trackers[i]
                opt.innerHTML = select_trackers[i];
                select_dom.appendChild(opt);
            }

            select_dom.addEventListener("change", () => {
                let answer = confirm("Start searching new content for:  " + select_dom.value)
                if (answer) {
                    document.querySelector(".counter_div").style.display = "block"
                    generateMovieObjects(select_dom.value)
                }
            })

            document.querySelector("#content-area > div.well.well-sm").appendChild(select_dom)

        }


        const generateMovieObjects = (tracker) => {

            // target
            // {"dom_path":"", "imdb_id":"", "size":""}


            document.querySelectorAll("#content-area > div.block > .row").forEach((d) => {

                let dom_path = d
                let imdb_id = ""
                let size = -1 // not possible yet.

                try {
                    imdb_id = [...d.querySelectorAll("a")].find(a => a.href.includes("imdb")).href.split("/title/")[1]
                } catch(e) {}

                movie_objects.push({dom_path, imdb_id, size})

            })

            document.querySelector(".total_torrents_count").textContent = movie_objects.length
            for (let i=0; i<movie_objects.length;i++) query_and_filter(tracker, movie_objects[i], i)

        }


        add_select_options()
    }

    else if (URL.includes("avistaz.to")) {

        let movie_objects = []

        const add_select_options = () => {

            select_trackers = select_trackers.filter(e => e != "AvistaZ")

            let select_dom = document.createElement("select")
            select_dom.style.marginLeft = "16px"
            select_dom.style.padding = "2px 2px 3px 2px"

            for (var i = 0; i<select_trackers.length; i++){
                var opt = document.createElement('option');
                opt.value = select_trackers[i]
                opt.innerHTML = select_trackers[i];
                select_dom.appendChild(opt);
            }

            select_dom.addEventListener("change", () => {
                let answer = confirm("Start searching new content for:  " + select_dom.value)
                if (answer) {
                    document.querySelector(".counter_div").style.display = "block"
                    generateMovieObjects(select_dom.value)
                }
            })


            document.querySelector("#content-area > div.well.well-sm").appendChild(select_dom)

        }


        const generateMovieObjects = (tracker) => {

            // target
            // {"dom_path":"", "imdb_id":"", "size":""}


            document.querySelectorAll("#content-area > div.block > .row").forEach((d) => {

                let dom_path = d
                let imdb_id = ""
                let size = -1 // not possible yet.

                try {
                    imdb_id = [...d.querySelectorAll("a")].find(a => a.href.includes("imdb")).href.split("/title/")[1]
                } catch(e) {}

                movie_objects.push({dom_path, imdb_id, size})

            })

            document.querySelector(".total_torrents_count").textContent = movie_objects.length
            for (let i=0; i<movie_objects.length;i++) query_and_filter(tracker, movie_objects[i], i)

        }

        add_select_options()

    }

    else if (URL.includes("cinemageddon.net")) {


        let movie_objects = []

        const add_select_options = () => {

            select_trackers = select_trackers.filter(e => e != "CG")

            let select_dom = document.createElement("select")
            select_dom.style.marginLeft = "16px"
            select_dom.style.padding = "2px 2px 3px 2px"

            for (var i = 0; i<select_trackers.length; i++){
                var opt = document.createElement('option');
                opt.value = select_trackers[i]
                opt.innerHTML = select_trackers[i];
                select_dom.appendChild(opt);
            }

            select_dom.addEventListener("change", () => {
                let answer = confirm("Start searching new content for:  " + select_dom.value)
                if (answer) {
                    document.querySelector(".counter_div").style.display = "block"
                    generateMovieObjects(select_dom.value)
                }
            })

            document.querySelector(".embedded > p").appendChild(select_dom)

        }


        const generateMovieObjects = (tracker) => {

            // target
            // {"dom_path":"", "imdb_id":"", "size":""}


            let count = document.querySelectorAll(".torrenttable")[document.querySelectorAll(".torrenttable").length-1].querySelector("tbody").querySelectorAll("tr").length

            for (let i=0; i<count; i++) {
                let current_torrent_row = document.querySelectorAll(".torrenttable")[document.querySelectorAll(".torrenttable").length-1].querySelector("tbody").querySelectorAll("tr")[i]
                let dom_path = current_torrent_row
                let imdb_id = ""

                try {
                    imdb_id = current_torrent_row.querySelector(".sc-imdb").href.split("/tt")[1].split("%")[0]
                }
                catch(e) {

                }

                let size = current_torrent_row.querySelector("td:nth-child(5)").textContent

                if (size.includes("GB")) {
                    size = parseInt(parseFloat(size.split(" ")[0])*1024) // MB
                }
                else if (size.includes("MB")) size = parseInt(parseFloat(size.split(" ")[0]))

                movie_objects.push({dom_path, imdb_id, size})

            }

            document.querySelector(".total_torrents_count").textContent = movie_objects.length
            for (let i=0; i<movie_objects.length;i++) query_and_filter(tracker, movie_objects[i], i)

        }

        add_select_options()

    }

    else if (URL.includes("blutopia.cc")) {


        let movie_objects = []

        const add_select_options = () => {

            select_trackers = select_trackers.filter(e => e != "BLU")

            let select_dom = document.createElement("select")
            select_dom.style.margin = "20px 0"
            select_dom.style.padding = "2px 2px 3px 2px"
            select_dom.style.color = "#111"

            for (var i = 0; i<select_trackers.length; i++){
                var opt = document.createElement('option');
                opt.value = select_trackers[i]
                opt.innerHTML = select_trackers[i];
                select_dom.appendChild(opt);
            }

            select_dom.addEventListener("change", () => {
                let answer = confirm("Start searching new content for:  " + select_dom.value)
                if (answer) {
                    document.querySelector(".counter_div").style.display = "block"
                    generateMovieObjects(select_dom.value)
                }
            })

            document.querySelector("form.form").appendChild(select_dom)
        }


        const generateMovieObjects = (tracker) => {

            // hedef
            // {"dom_path":"", "imdb_id":"", "size":""}

            document.querySelector(".torrent-search--list__results tbody").querySelectorAll("tr").forEach((d) => {

                let dom_path = d
                let imdb_id = ""


                try {
                    imdb_id = d.querySelector("#imdb_id").textContent
                } catch(e) {}

                let size = d.querySelector(".torrent-search--list__size").textContent.trim()
                if (size.includes("GiB")) {
                    size = parseInt(parseFloat(size.split(" ")[0])*1024) // MB
                }
                else if (size.includes("MiB")) size = parseInt(parseFloat(size.split(" ")[0]))


                //console.log({dom_path, imdb_id, size})

                movie_objects.push({dom_path, imdb_id, size})

            })

            document.querySelector(".total_torrents_count").textContent = movie_objects.length
            for (let i=0; i<movie_objects.length;i++) query_and_filter(tracker, movie_objects[i], i)

        }


        add_select_options()

    }

    else if (URL.includes("torrentleech.org")) {


        let movie_objects = []

        const add_select_options = () => {

            select_trackers = select_trackers.filter(e => e != "TL")

            let select_dom = document.createElement("select")
            select_dom.style.margin = "20px 0"
            select_dom.style.padding = "2px 2px 3px 2px"
            select_dom.style.color = "#111"

            for (var i = 0; i<select_trackers.length; i++){
                var opt = document.createElement('option');
                opt.value = select_trackers[i]
                opt.innerHTML = select_trackers[i];
                select_dom.appendChild(opt);
            }

            select_dom.addEventListener("change", () => {
                let answer = confirm("Start searching new content for:  " + select_dom.value)
                if (answer) {
                    document.querySelector(".counter_div").style.display = "block"
                    generateMovieObjects(select_dom.value)
                }
            })


            document.querySelector(".sub-navbar").appendChild(select_dom)

        }


        const generateMovieObjects = (tracker) => {

            // target
            // {"dom_path":"", "imdb_id":"", "size":""}


            document.querySelectorAll(".torrent").forEach((d) => {

                let dom_path = d
                let imdb_id = ""

                try {
                    imdb_id = d.querySelector("a.imdb-link").href.split("/title/")[1]
                } catch(e) {}


                let size = d.querySelector(".td-size").textContent.trim()

                if (size.includes("GiB")) {
                    size = parseInt(parseFloat(size.split(" ")[0])*1024) // MB
                }
                else if (size.includes("MiB")) size = parseInt(parseFloat(size.split(" ")[0]))

                //console.log({dom_path, imdb_id, size})
                movie_objects.push({dom_path, imdb_id, size})

            })

            document.querySelector(".total_torrents_count").textContent = movie_objects.length
            for (let i=0; i<movie_objects.length;i++) query_and_filter(tracker, movie_objects[i], i)

        }


        add_select_options()
    }

    else if (URL.includes("anthelion.me")) {

        let movie_objects = []

        const add_select_options = () => {

            select_trackers = select_trackers.filter(e => e != "ANT")

            let select_dom = document.createElement("select")
            select_dom.style.margin = "0 5px"

            for (var i = 0; i<select_trackers.length; i++){
                var opt = document.createElement('option');
                opt.value = select_trackers[i]
                opt.innerHTML = select_trackers[i];
                select_dom.appendChild(opt);
            }

            select_dom.addEventListener("change", () => {
                let answer = confirm("Start searching new content for:  " + select_dom.value)
                if (answer) {
                    document.querySelector(".counter_div").style.display = "block"
                    generateMovieObjects(select_dom.value)
                }
            })

            document.querySelector("#ft_container").appendChild(select_dom)

        }

        const generateMovieObjects = (tracker) => {

            // hedef
            // {"dom_path":"", "imdb_id":"", "size":""}

            document.querySelector(".torrent_table").querySelectorAll("tbody > tr.group").forEach((d,i) => { // --> Old HTML selector

                let dom_path = d
                let imdb_id = ""

                try {
                    imdb_id = [...d.querySelector("td.big_info").querySelectorAll("a")].find(a => a.href.includes("imdb.com")).href.split("/title/")[1].replace("/","") // --> Old HTML selector
                } catch(e) {}


                let size = [...d.querySelectorAll("td")].find(e => e.textContent.includes(" (Max)")).textContent // --> Old HTML selector
                // let size = movies[i].MaxSize

                if (size.includes("GiB")) {
                    size = parseInt(parseFloat(size.split(" ")[0])*1024) // MB
                }
                else if (size.includes("MiB")) size = parseInt(parseFloat(size.split(" ")[0]))

                movie_objects.push({dom_path, imdb_id, size})
            })

            document.querySelector(".total_torrents_count").textContent = movie_objects.length
            for (let i=0; i<movie_objects.length;i++) query_and_filter(tracker, movie_objects[i], i)
        }

        add_select_options()

    }


})();