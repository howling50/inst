// ==UserScript==
// @name        copy images from HD-T
// @description copies comparison image urls to clipboard
// @namespace   all
// @match       https://hd-torrents.org/details.php?id=*
// @version     1
// @grant       none
// ==/UserScript==

(function(){
    'use strict'

    document.addEventListener('readystatechange', e => {
        if(document.readyState === "complete"){
            addButton('Copy Image URLs', copyImageUrls);
        }
    });

    function addButton(text, onclick, cssObj) {
        let reportTorrentButton = document.querySelector("[href^='report.php?torrent=']");
        let button = document.createElement('button'), btnStyle = button.style
        button.innerHTML = text;
        button.onclick = onclick;
        reportTorrentButton.parentNode.insertBefore(button, reportTorrentButton.nextSibling);
        return button;
    }

    function copyImageUrls() {
        let techInfoSection = document.getElementById("technicalInfoHideShowTR").childNodes;
        let sources = "[color=#FF0000]&#9733;[/color] [comparison=";
        let comparisonImages = [];
        let releaseGroup = "";
        techInfoSection.forEach((info, i) => {
            if (info.innerText != undefined && info.innerText.includes("Source     -")) {
                releaseGroup = "HiDt";
                return true;
            }
            else if (info.innerText != undefined && info.innerText.includes("SOURCE<<<<<<<<")) {
                releaseGroup = "SPHD";
                return true;
            }
        });

        for (const match of document.getElementById("technicalInfoHideShowTR").innerHTML.matchAll(/https:\/\/thumbs.*?png/g)) {
            comparisonImages.push(match[0].replace("thumbs2", "images2").replace('_t', "_o"));
        }

        techInfoSection.forEach((info, i) => {
            if(releaseGroup == "HiDt") {
                if (info.innerText != undefined && info.innerText.includes("Source     -")) {
                    sources += info.innerText.replace(/     -     /g, ", ") + "]";
                    return true;
                }
            }
            else if (releaseGroup == "SPHD") {
                info.childNodes.forEach((subInfo, j) => {
                    if (subInfo.innerText != undefined && subInfo.innerText.includes("SOURCE<<<<<<<<")) {
                        subInfo.childNodes.forEach((subSubInfo, k) => {
                            if (subSubInfo.innerText != undefined && subSubInfo.innerText.includes("SOURCE<<<<<<<<")) {
                                sources += subSubInfo.innerText.replace(/[<>-]+/g, ", ").replace(",  VS ,", ",").replace(/\s\s/g, "").replace("\n", "") + "]";
                                return true;
                            }
                        });
                    }
                });
            }
        });

        let clipboardText = sources + "\n";
        comparisonImages.forEach((x, y) => {
            console.log("image found: " + x);
            clipboardText += x + "\n";
        });
        clipboardText += "[/comparison]";
        navigator.clipboard.writeText(clipboardText);
    }
}())