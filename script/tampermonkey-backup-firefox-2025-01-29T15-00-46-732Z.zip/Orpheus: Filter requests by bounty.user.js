// -*- js2-additional-externs: ("GM"); -*-
// ==UserScript==
// @name        Orpheus: Filter requests by bounty
// @namespace   commoner@orpheus.network
// @description Filter requests by bounty size.
// @match       https://orpheus.network/requests.php
// @match       https://orpheus.network/requests.php?*&page=*
// @match       https://orpheus.network/requests.php?page=*
// @match       https://orpheus.network/requests.php?submit=true&*
// @match       https://*.orpheus.network/requests.php
// @match       https://*.orpheus.network/requests.php?*&page=*
// @match       https://*.orpheus.network/requests.php?page=*
// @match       https://*.orpheus.network/requests.php?submit=true&*
// @match       https://redacted.sh/requests.php
// @match       https://redacted.sh/requests.php?*&page=*
// @match       https://redacted.sh/requests.php?page=*
// @match       https://redacted.sh/requests.php?submit=true&*
// @match       https://*.redacted.sh/requests.php
// @match       https://*.redacted.sh/requests.php?*&page=*
// @match       https://*.redacted.sh/requests.php?page=*
// @match       https://*.redacted.sh/requests.php?submit=true&*
// @grant       GM.setValue
// @grant       GM.getValue
// @grant       GM_setValue
// @grant       GM_getValue
// ==/UserScript==

const getValue = async function(name,
                                defaultValue) {
  if (GM) {
    // GreaseMonkey.
    return await GM.getValue(name,
                             defaultValue);
  }
  else {
    // TamperMonkey.
    return GM_getValue(name,
                       defaultValue);
  }
};

const setValue = function(name,
                          value) {
  if (GM) {
    // GreaseMonkey.
    return GM.setValue(name,
                       value);
  }
  else {
    // TamperMonkey.
    return GM_setValue(name,
                       value);
  }
};

const parseBounty = function(text) {
  let number = -1;
  let success = false;
  const match = text.match(/([1-9][0-9,]*\.[0-9]+) +([MGTP]i?B)/);
  if (match) {
    number = Number.parseFloat(match[1].replace(',', ''));
    const multiplier = match[2].replace(/i/, '');
    const index = ['MB', 'GB', 'TB', 'PB'].indexOf(multiplier);
    number *= 1024 ** Math.max(0, index);
    success = true;
  }
  return {
    'success': success,
    'bounty': number
  };
};

const filter = function(bounty, multiplierIndex) {
  const minimumBounty = bounty * 1024 ** multiplierIndex;

  // Filter requests.
  Array.from(document.querySelectorAll('table#request_table > tbody > tr:not(.colhead):not(.colhead_dark) > td.number_column')).forEach(function(bountyField) {
    const bountyText = bountyField.innerHTML;
    const { success: parseSuccess, bounty: bountyAmount } = parseBounty(bountyText);
    if (parseSuccess) {
      const bountyRow = bountyField.parentNode;
      if (bountyAmount >= minimumBounty) {
        //console.log(`bounty ${bountyAmount} >= minimum ${minimumBounty}`);
        bountyRow.classList.remove('hidden');
      }
      else {
        bountyRow.classList.add('hidden');
      }
    }
    else {
      console.error(`Failed to parse bounty: ${bountyText}`);
    }
  })
};

const storeAndFilter = function(event) {
  const bounty = document.querySelector('#bountyValue').value;
  const multiplierIndex = document.querySelector('#bountyMultiplier').selectedIndex;

  // Update storage.
  setValue('bounty', bounty);
  setValue('multiplier', multiplierIndex);

  filter(bounty, multiplierIndex);
};

const element = function(tag, properties, ...children) {
  const el = document.createElement(tag);
  if (properties) {
    Object.keys(properties).forEach(function(name) {
      el[name] = properties[name];
    });
    children.forEach(function(child) {
      if (child && typeof child === 'object') {
        if (Array.isArray(child)) {
          child.forEach(function(grandchild) {
            el.appendChild(grandchild);
          });
        }
        else {
          el.appendChild(child);
        }
      }
    });
  }
  return el;
};

const addUi = function(bounty, multiplierIndex) {
  if (!document.querySelector('tr.com#bounty')) {
    document.querySelector('.layout > tbody').appendChild(
      element('tr',
              { 'id': 'bounty', 'className': 'com' },
              element('td', { 'className': 'label', 'innerHTML': 'Minimum bounty:' }),
              element('td', {},
                      element('input', { 'id': 'bountyValue', 'type': 'text', 'size': 4, 'value': bounty }),
                      element('select', { 'id': 'bountyMultiplier' },
                              element('option', { 'innerHTML': 'MiB', selected: multiplierIndex == 0 }),
                              element('option', { 'innerHTML': 'GiB', selected: multiplierIndex == 1 }),
                              element('option', { 'innerHTML': 'TiB', selected: multiplierIndex == 2 }),
                              element('option', { 'innerHTML': 'PiB', selected: multiplierIndex == 3 })),
                      element('input', { 'type': 'button', 'value': 'Update', 'onclick': storeAndFilter }))));
    return true;
  }
  else {
    return false;
  }
};

const main = async function() {
  const bounty = await getValue('bounty',
                                0);
  const multiplierIndex = await getValue('multiplier',
                                         0);
  if (addUi(bounty, multiplierIndex)) {
    filter(bounty, multiplierIndex);
  }
}

main();