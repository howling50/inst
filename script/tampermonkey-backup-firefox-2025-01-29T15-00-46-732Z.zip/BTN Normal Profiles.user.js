// ==UserScript==
// @name         BTN Normal Profiles
// @namespace    http://tampermonkey.net/
// @version      0.1.1
// @description  Remove the multiple tabs present on a BTN profile.
// @author       1526742
// @match        https://broadcasthe.net/user.php?id=*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=broadcasthe.net
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    var panelList = document.querySelectorAll("div.scrollContainer > div.panel");
    var panelListArray = [...panelList];

    panelListArray.forEach(div => {
        div.style.cssText = "height:auto;";
    });

    // hide the buttons.
    document.getElementsByClassName("box usermenu")[0].remove();
})();