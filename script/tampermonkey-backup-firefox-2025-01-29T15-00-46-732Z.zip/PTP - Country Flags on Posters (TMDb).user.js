// ==UserScript==
// @name        PTP - Country Flags on Posters (TMDb)
// @author      Perilune
// @namespace   https://github.com/soranosita
// @match       https://passthepopcorn.me/torrents.php*
// @match       https://passthepopcorn.me/collages.php?id=*
// @match       https://passthepopcorn.me/artist.php?id=*
// @match       https://passthepopcorn.me/top10.php*
// @icon        https://passthepopcorn.me/favicon.ico
// @grant       GM.xmlHttpRequest
// @grant       GM_addStyle
// @version     0.2
// ==/UserScript==


const LOG_LEVEL = "DEBUG";
const TMDB_API_KEY = "4b76b226a8e2428b478767e3f81be4f0";


/* -------------------------------
 * LOGGING
 * ------------------------------- */
switch (LOG_LEVEL) {
  case 'ERROR':
    console.warn = function () { };
  // Falls through
  case 'WARN':
    console.info = function () { };
  // Falls through
  case 'INFO':
    console.log = function () { };
  // Falls through
  case 'LOG':
    console.debug = function () { };
    console.dir = function () { };
}


/* -------------------------------
 * STYLES
 * ------------------------------- */
GM_addStyle(`
.poster-container {
  position: relative;
  display: inline-block;
}

.flags-container {
  position: absolute;
  top: 5px;
  left: 5px;
}

.flags-container span {
  margin-right: 5px;
  margin-bottom: 5px;
  width: 40px;
  height: 30px;
  box-shadow: 5px 5px 4px rgba(0, 0, 0, 0.4);
  border: 1px solid rgba(0, 0, 0, 0.5);
}
`)


function importFlagsStylesheet() {
  const link = document.createElement("link");
  link.rel = "stylesheet";
  link.href = "https://cdn.jsdelivr.net/gh/lipis/flag-icons@6.6.6/css/flag-icons.min.css";
  document.head.append(link);
}


/* -------------------------------
 * PATHS
 * ------------------------------- */
importFlagsStylesheet();
initializeDatabase();

if (!TMDB_API_KEY) {
  console.error("Please set the TMDb API key.");
} else {
  if (/torrents.php/.test(location.pathname) && new URLSearchParams(location.search).get("id")) {
    addFlagsToTorrentGroup();
  } else {
    addFlagsToCoverViews();
  }
}

/* -------------------------------
 * DATABASE
 * ------------------------------- */
async function retrieveData(imdbId) {
  return await retrieveFromDatabase("ptpFlags", imdbId);
}


async function retrieveFromDatabase(dbName, id) {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(dbName, 1);

    request.onsuccess = (event) => {
      const db = event.target.result;
      const transaction = db.transaction('movies', 'readonly');
      const objectStore = transaction.objectStore('movies');
      const getRequest = objectStore.get(id);

      getRequest.onsuccess = (event) => {
        const movie = event.target.result;
        if (movie) {
          console.debug(`[${dbName}] Data found:`, movie);
          resolve(movie);
        } else {
          console.debug(`[${dbName}] Data not found for ID:`, id);
          resolve(null);
        }
      };
      getRequest.onerror = (event) => {
        console.error(`[${dbName}] Error retrieving data (request):`, event.target.error);
        reject(event.target.error);
      };
      transaction.oncomplete = () => { db.close(); };
      transaction.onerror = (event) => {
        console.error(`[${dbName}] Error retrieving data (transaction):`, event.target.error);
        reject(event.target.error);
      };
    };
    request.onerror = (event) => {
      console.error(`Error opening ${dbName} database:`, event.target.error);
      reject(event.target.error);
    };
  });
}


async function storeData(data) {
  return await storeInDatabase("ptpFlags", data);
}


async function storeInDatabase(dbName, movie) {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(dbName, 1);

    request.onsuccess = (event) => {
      const db = event.target.result;
      const transaction = db.transaction('movies', 'readwrite');
      const objectStore = transaction.objectStore('movies');

      const putRequest = objectStore.put(movie);

      putRequest.onsuccess = () => {
        console.debug(`[${dbName}] Data stored successfully.`, movie);
        resolve();
      };
      putRequest.onerror = (event) => {
        console.error(`[${dbName}] Error storing data (request):`, event.target.error);
        reject(event.target.error);
      };
      transaction.oncomplete = () => { db.close(); };
      transaction.onerror = (event) => {
        console.error(`[${dbName}] Error storing data (transaction):`, event.target.error);
        reject(event.target.error);
      };
    };
    request.onerror = (event) => {
      console.error(`Error opening ${dbName} database:`, event.target.error);
      reject(event.target.error);
    };
  });
}


function initializeDatabase() {
  const dbName = "ptpFlags";
  const dbId = "imdbId";

  const request = indexedDB.open(dbName, 1);

  request.onupgradeneeded = (event) => {
    const db = event.target.result;
    db.createObjectStore('movies', { keyPath: dbId });
    console.info(`[${dbName}] Database created.`);
  };
}


/* -------------------------------
 * TMDB
 * ------------------------------- */
async function getDocument(url, isJson = true) {
  console.debug(`New request to: ${url}`);

  return new Promise((resolve, reject) => {
    GM.xmlHttpRequest({
      method: "GET",
      url: url,
      onload: function (response) {
        if (isJson) {
          const data = JSON.parse(response.responseText);
          resolve(data);
        } else {
          const html = response.responseText;
          const parser = new DOMParser();
          const doc = parser.parseFromString(html, "text/html");
          resolve(doc);
        }
      },
      onerror: function (error) {
        reject(error);
      }
    });
  });
}


async function getCountriesViaTmdb(imdbId) {
  const tmdbTypes = ["movie", "tv"];

  for (const tmdbType of tmdbTypes) {
    const data = await getDocument(`https://api.themoviedb.org/3/${tmdbType}/${imdbId}?api_key=${TMDB_API_KEY}`);
    if (data.production_countries !== undefined) {
      console.debug(`${imdbId} is: ${tmdbType}.`)
      return data.production_countries;
    }
  }
  return [];
}


/* -------------------------------
 * FLAGS
 * ------------------------------- */
function createFlagElement(country) {
  const span = document.createElement("span");
  span.title = country.name;
  span.className = `fi fi-${country.alpha2.toLowerCase()}`;

  const link = document.createElement("a");
  link.append(span);

  return link;
}


async function getCountries(imdbId) {
  const storedData = await retrieveData(imdbId);
  var data;

  if (!storedData) {
    const tmdbCountries = await getCountriesViaTmdb(imdbId);
    const countries = tmdbCountries.map((country) => {
      return { name: country.name, alpha2: country.iso_3166_1 };
    });
    data = { imdbId: imdbId, countries: countries };
    await storeData(data);
  } else {
    data = storedData;
  }

  return data;
}


function createBox(poster, parent) {
  const targetDiv = document.createElement("div");
  targetDiv.className = "poster-container";
  targetDiv.append(poster);
  const flagsDiv = document.createElement("div");
  flagsDiv.className = "flags-container";
  targetDiv.append(flagsDiv);
  parent.prepend(targetDiv);

  return flagsDiv;
}


async function addFlags(imdbId, poster, movieDiv) {
  const flagsDiv = createBox(poster, movieDiv);
  const data = await getCountries(imdbId);

  data.countries.forEach(country => {
    const flagElement = createFlagElement(country);
    flagsDiv.append(flagElement);
  });

  console.debug(`${imdbId}: ${data.countries.length} posters.`)
}


/* -------------------------------
 * MAIN
 * ------------------------------- */
async function addFlagsToTorrentGroup() {
  const movieDiv = document.querySelector("div.box_albumart > div.panel__body");
  const posterImage = document.querySelector(".sidebar-cover-image");

  const imdbRating = document.querySelector("#imdb-title-link");
  const imdbId = imdbRating ? imdbRating.href.match(/\/title\/(tt\d+)\//)[1] : null;
  if (imdbId) {
    await addFlags(imdbId, posterImage, movieDiv);
  }
}


async function addFlagsToCoverViews() {
  const movieDivs = document.querySelectorAll(".cover-movie-list__movie");

  for (const movieDiv of movieDivs) {
    const posterLink = movieDiv.querySelector("a.cover-movie-list__movie__cover-link");
    const imdbRating = movieDiv.querySelector("a.cover-movie-list__movie__rating");
    const imdbId = imdbRating ? imdbRating.href.match(/\/title\/(tt\d+)\//)[1] : null;

    if (imdbId) {
      await addFlags(imdbId, posterLink, movieDiv);
    }
  }
}
