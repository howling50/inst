// ==UserScript==
// @name         MTeam
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       风雪夜归人
// @match        https://kp.m-team.cc/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=m-team.cc
// @grant        none
// @require      https://code.jquery.com/jquery-2.1.4.min.js
// ==/UserScript==
this.$ = this.jQuery = jQuery.noConflict(true);

(function() {
  'use strict';
  $('body').on('DOMNodeInserted',function() {
      console.log('新增了一个元素')
      $('body').children('div').each((idx,element) => {
          //console.log(element);
          const ref = $(element);
          const element_id = ref.attr('id');
          //console.log(element_id);
          if (element_id === undefined) {
              return;
          }
          if (element_id.startsWith('tid_')) {
              ref.css('left', '50%');
              ref.css('top', '50%');
              ref.css('position', 'fixed');
              ref.css('transform','translate(-50%, -50%)');
              ref.find('img').css('max-width', '100%');
              ref.find('img').css('max-height', '100%');
              ref.find('img').css('object-fit', 'contain');
              ref.find('img').css('object-position', 'center');
          }
      });

  });

})();