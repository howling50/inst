// ==UserScript==
// @name        copy fl play-hd images
// @description copies comparison image urls to clipboard with ".md" removal
// @namespace   all
// @match       https://filelist.io/details.php?id=*
// @version     1
// @grant       none
// ==/UserScript==

(function(){
    'use strict'

    window.addEventListener('load', () => {
        addButton('Copy Image URLs', copyImageUrls)
    })

    function addButton(text, onclick, cssObj) {
        let descriptionToggleButton = document.querySelector("[id='descrhide']");
        let button = document.createElement('button'), btnStyle = button.style
        button.innerHTML = text;
        button.onclick = onclick;
        descriptionToggleButton.parentNode.insertBefore(button, descriptionToggleButton.nextSibling);
        return button;
    }

    function copyImageUrls() {
        var imageUrls = document.querySelectorAll("[style='max-width: 700px;overflow: hidden;']");
        var clipboardText = "[comparison=Source, playHD]\n";
        imageUrls.forEach((imageUrl) => {
            if (!imageUrl.currentSrc.includes("play-HD")) {
                // Remove ".md" part from the URL
                var modifiedUrl = imageUrl.currentSrc.replace("thumbs2", 'images2').replace("_t", "_o").replace(".md", "");
                clipboardText += modifiedUrl + "\n";
            }
        });
        clipboardText += "[/comparison]"
        navigator.clipboard.writeText(clipboardText);
    }
}());
