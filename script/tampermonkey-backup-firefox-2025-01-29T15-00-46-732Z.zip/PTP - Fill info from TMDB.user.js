// ==UserScript==
// @name         PTP - Fill info from TMDB
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  fill info from TMDB
// @author       passthepopcorn_cc
// @match        https://passthepopcorn.me/upload.php*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    /****************************************************************/

    let api_key = "4b76b226a8e2428b478767e3f81be4f0" /* your TMDB API key.
              get your API Key here: https://developers.themoviedb.org/3/getting-started/introduction (you need an account, its free) */


    /****************************************************************/




    let tmdb_url = ""
    let movie_id = ""
    let tmdb_api_url = ""

    function insertAfter(newNode, referenceNode) {
        referenceNode.parentNode.insertBefore(newNode, referenceNode.nextSibling);
    }


    function numberWithCommas(x) {
        var parts = x.toString().split(".");
        parts[0]=parts[0].replace(/\B(?=(\d{3})+(?!\d))/g,".");
        return parts.join(",");
    }


    const get_tmdb_trailer = async() => {

        return new Promise((resolve, reject) => {

            let api_url = "https://api.themoviedb.org/3/movie/" + movie_id + "/videos?api_key=" + api_key

            fetch(api_url).then((res) => {
                res.json().then((data) => {

                    let trailer = ""

                    try {
                        trailer = "https://www.youtube.com/watch?v=" + data.results.find(e => e.type==="Trailer").key
                    } catch(e) {}

                    resolve(trailer)

                })
            })
        })


    }


    const get_tmdb_cast = async() => {

        return new Promise((resolve, reject) => {

            let api_url = "https://api.themoviedb.org/3/movie/" + movie_id + "/credits?api_key=" + api_key

            fetch(api_url).then((res) => {
                res.json().then((data) => {
                    resolve(data)
                })
            })
        })


    }


    const get_ptp_movie_obj = async(data) => {

        let imdb_id = (function() { try { return data.imdb_id } catch (e) { return undefined } })();
        let title = (function() { try { return data.title } catch (e) { return undefined } })();
        let year = (function() { try { return parseInt(data.release_date.split("-")[0]) } catch (e) { return undefined } })();
        let cover_art = (function() { try { return "https://www.themoviedb.org/t/p/original" + data.poster_path } catch (e) { return undefined } })();
        let genres = (function() { try { return data.genres.map(e => e.name.toLowerCase()) } catch (e) { return undefined } })();

        let trailer = await get_tmdb_trailer()

        let tagline = (function() { try { return data.tagline } catch (e) { return undefined } })();
        let overview = (function() { try { return data.overview } catch (e) { return undefined } })();

        let cast = await get_tmdb_cast()

        let director = (function() { try { return cast.crew.find(e => e.job === "Director").name } catch (e) { return undefined } })();
        let actors = (function() { try { return cast.cast } catch (e) { return undefined } })(); // objects

        /* synopsis */
        let tmdb_link = tmdb_url
        let original_title = (function() { try { return data.original_title } catch (e) { return undefined } })();
        let original_language = (function() { try { return data.original_language } catch (e) { return undefined } })();
        let runtime = (function() { try { return data.runtime } catch (e) { return undefined } })();
        let exact_release_date = (function() { try { return data.release_date } catch (e) { return undefined } })();
        let country = (function() { try { return data.production_countries[0].name } catch (e) { return undefined } })();
        let budget = (function() { try { return data.budget } catch (e) { return undefined } })();
        let revenue = (function() { try { return data.revenue } catch (e) { return undefined } })();

        let all_directors = (function() { try { return cast.crew.filter(e => e.job === "Director") } catch (e) { return [] } })(); // objects
        let all_producers = (function() { try { return cast.crew.filter(e => e.job === "Producer") } catch (e) { return [] } })(); // objects
        let all_writers = (function() { try { return cast.crew.filter(e => e.job === "Writer") } catch (e) { return [] } })(); // objects


        let non_actor_crew = all_directors.concat(all_producers).concat(all_writers)

        // console.log(non_actor_crew)


        let original_music_composer = (function() { try { return cast.crew.filter(e=>e.department === "Sound").filter((a => a.job === "Original Music Composer")) } catch (e) { return [] } })(); // objects
        let director_of_photography = (function() { try { return cast.crew.filter(e=>e.department === "Camera").filter((a => a.job === "Director of Photography")) } catch (e) { return [] } })();


        non_actor_crew = non_actor_crew.concat(original_music_composer).concat(director_of_photography)


        let keywords = (function() { try { return data.keywords.keywords } catch (e) { return undefined } })(); // objects



        /* custom */
        let synopsis_text = ""

        if (tagline != undefined) synopsis_text += "[i]\"" + tagline + "\"[/i]"
        if (overview != undefined) synopsis_text += "\n\n[i]"+ overview + "[/i]"

        if (synopsis_text != "") synopsis_text+="\n\n[hr]"

        synopsis_text += "\nTMDB: " + tmdb_link + "\n"
        if (original_title != undefined) synopsis_text += "\n[b]Original title: [/b]" + original_title
        if (original_language != undefined) synopsis_text += "\n[b]Original language: [/b]" + original_language.toUpperCase()
        if (runtime != undefined) synopsis_text += "\n[b]Runtime: [/b]" + runtime + " minutes"
        if (exact_release_date != undefined) synopsis_text += "\n[b]Release date: [/b]" + exact_release_date
        if (country != undefined) synopsis_text += "\n[b]Country: [/b]" + country
        if (budget != 0) synopsis_text += "\n[b]Budget: [/b]$" + numberWithCommas(budget)
        if (revenue != 0) synopsis_text += "\n[b]Revenue: [/b]$" + numberWithCommas(revenue)

        if (keywords.length > 0) {

            let base = `\n\n[b]Keywords: [/b]\n[hide]`

            keywords.forEach(k => {
                base+= `[url=https://www.themoviedb.org/keyword/${k.id}/movie]${k.name}[/url] - `
            })

            base=base.slice(0,base.length-2)

            base+="[/hide]"

            synopsis_text+=base

        }


        return ({
            imdb_id, non_actor_crew, synopsis_text, title, year, cover_art, genres, trailer, tagline, overview, director, actors, tmdb_link, original_title, original_language, runtime, exact_release_date, country, budget, revenue, all_directors, all_producers, all_writers, original_music_composer, director_of_photography, keywords
        })


    }


    const get_tmdb_movie = async() => {

        return new Promise((resolve, reject) => {

            fetch(tmdb_api_url).then((res) => {
                res.json().then((data) => {

                    get_ptp_movie_obj(data).then((movie) => {
                        resolve(movie)
                    })

                })
            })

        })


    }

    const get_actor_imdb_id = async(api_url) => {

        return new Promise((resolve, reject) => {

            setTimeout(function () {

                fetch(api_url).then((res) => {
                    res.json().then((data) => {
                        resolve(data.imdb_id)
                    })
                })

            }, 510);

        })
    }

    const insert_one_actor = async(actor_imdb_id) => {

        return new Promise((resolve, reject) => {

            document.querySelector("#AddArtistName").value = actor_imdb_id
            document.querySelector("#AddArtistRow > td > input[type=button]:nth-child(2)").click()

            resolve(true);

        })

    }

    const insert_one_role = async(role, idx) => {

        return new Promise((resolve, reject) => {

            let myInterval = setInterval(() => {

                try {
                    document.querySelector(`#artistlist > tbody > tr:nth-child(${idx+2}) > td:nth-child(3) > input[type=text]`).value = role
                    clearInterval(myInterval);
                    resolve(true)
                } catch(e) {
                    // backend process didnt finish yet, no worries
                }

            }, 50);



        })






    }

    const get_job_id = (actor) => {

        if (actor.job === "Producer") return "3"
        else if (actor.job === "Writer") return "2"
        else if (actor.job === "Director") return "1"
        else if (actor.job === "Original Music Composer") return "4"
        else if (actor.job === "Director of Photography") return "6"
        else if (actor.character != undefined ) return "5"
        else return "0" // ?

    }

    const set_one_job = (job_id, idx) => {
        document.querySelector(`#artistlist > tbody > tr:nth-child(${idx+2}) > td:nth-child(2) > select`).value = job_id
        return true
    }


    const fixStyle = () => {

        document.querySelector("#artistlist > tbody").querySelectorAll("select").forEach((d) => {
            d.style.margin = "4px 5px"
        })

        try {
            let count = document.querySelectorAll(`#artistlist > tbody > tr`).length
            for (let j=0; j<count; j++) {
                document.querySelector(`#artistlist > tbody > tr:nth-child(${j+2}) > td:nth-child(4) > a`).style.margin = "5px"
            }
        } catch(e) {}

    }


    const toggle_cast_display = () => {

        let display = document.querySelector("#artistlist").style.display

        if (display != "none") {

            document.querySelector("#artistlist").style.display = "none"
            document.querySelector("#artist_tr > div.grid__item.grid-u-2-10").style.marginBottom = "16px"

            let eElement = document.querySelector("#artist_tr > div.grid__item.grid-u-8-10")
            let newFirstElement;

            newFirstElement = document.createElement("div")
            newFirstElement.className = "artists-info"
            newFirstElement.textContent = "Importing cast [...]"
            eElement.insertBefore(newFirstElement, eElement.firstChild);

            // document.querySelector("#artist_tr > div.grid__item.grid-u-8-10 > div").style.display= "block"

        }

        else {
            document.querySelector(".artists-info").style.display = "none"
            document.querySelector("#artistlist").style.display = "block"
        }


    }


    let cumulative = 0
    let inserted = 0
    const insert_cast = async(cast) => {

        cast = cast.filter(e => ["Acting", "Production","Writing", "Directing"].includes(e.known_for_department) || ["Original Music Composer", "Director of Photography"].includes(e.job))

        // cast=cast.slice(0,8)

        cumulative += cast.length

        for (let j=0; j<cast.length; j++) {

            let current_actor = cast[j]
            let actor_id = cast[j].id
            let api_url = "https://api.themoviedb.org/3/person/" + actor_id + "?api_key=" + api_key
            let actor_imdb = await get_actor_imdb_id(api_url)

            let actor_job_id = get_job_id(current_actor)

            let role = current_actor.character
            if (role === undefined) role = current_actor.job // for non-actors

            if (actor_imdb != undefined && actor_imdb != null) {
                await insert_one_actor(actor_imdb)
                await insert_one_role(role, inserted)

                set_one_job(actor_job_id, inserted)

                inserted++

                document.querySelector(".artists-info").textContent = `Importing cast [${inserted} / ${cumulative}]`

            }

        }


    }




    const fill_ptp_form = async(movie) => {

        if (movie.imdb_id != undefined) document.getElementById("imdb").value = movie.imdb_id
        if (movie.title != undefined) document.getElementById("title").value = movie.title
        if (movie.year != undefined) document.getElementById("year").value = movie.year
        if (movie.cover_art != undefined) document.getElementById("image").value = movie.cover_art;
        if (movie.trailer != undefined) [...document.querySelectorAll("input")].find(e => e.getAttribute("name") === "trailer").value = movie.trailer
        if (movie.genres != undefined) document.getElementById("tags").value = movie.genres.join(", ")


        if (movie.synopsis_text != "") document.getElementById("album_desc").value = movie.synopsis_text
        // document.getElementById("release_desc").value = "release desc here...."

        toggle_cast_display()
        insert_cast(movie.non_actor_crew).then(d => {
            insert_cast(movie.actors).then(v => {
                fixStyle()
                toggle_cast_display()
            })
        })


    }


    const create_fill_input = () => {
        let div = document.createElement("div")
        div.className = "grid"

        div.innerHTML = `

        					<div class="grid__item grid-u-2-10">
						<label class="form__label">TMDB link:</label>
					</div>
					<div class="grid__item grid-u-8-10">
						<input type="text" id="tmdb" name="tmdb" title="TMDb link (e.g.: https://www.themoviedb.org/movie/414906-the-batman) or ID (e.g.: 414906)" size="60" class="form__input" >
					</div>

        `

        insertAfter(div, [...document.querySelectorAll(".grid")].find(e => e.textContent.includes("IMDb link:")))

    }


    const fetch_movie_and_start = async() => {
        let movie = await get_tmdb_movie()
        fill_ptp_form(movie)
    }



    const main = async() => {

        create_fill_input()

        document.getElementById("autofill").addEventListener("click", () => {

            let imdb_input = document.getElementById("imdb").value
            let tmdb_input = document.getElementById("tmdb").value

            if (imdb_input != "" || tmdb_input === "") return false


            tmdb_url = tmdb_input
            movie_id = tmdb_url.split("/movie/")[1].split("-")[0]
            tmdb_api_url = "https://api.themoviedb.org/3/movie/" + movie_id + "?api_key=" + api_key + "&language=en-US&append_to_response=keywords"

            fetch_movie_and_start()

        })

    }






    main()





})();